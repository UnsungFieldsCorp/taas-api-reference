export declare function isAbortError(err: unknown): boolean;
export declare const castToError: (err: any) => Error;
//# sourceMappingURL=errors.d.ts.map