export declare const VERSION = "0.0.1";
//# sourceMappingURL=version.d.ts.map