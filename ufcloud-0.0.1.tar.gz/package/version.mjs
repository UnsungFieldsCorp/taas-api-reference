export const VERSION = '0.0.1';
//# sourceMappingURL=version.mjs.map