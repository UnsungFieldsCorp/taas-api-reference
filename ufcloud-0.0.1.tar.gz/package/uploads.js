"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("./internal/tslib.js");
/** @deprecated Import from ./core/uploads instead */
tslib_1.__exportStar(require("./core/uploads.js"), exports);
//# sourceMappingURL=uploads.js.map