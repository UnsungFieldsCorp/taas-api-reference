import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Embeddings extends APIResource {
    /**
     * Creates embeddings for a single text chunk or a list of text chunks.
     */
    create(body: EmbeddingCreateParams, options?: RequestOptions): APIPromise<EmbeddingCreateResponse>;
}
/**
 * Response schema for generated embeddings.
 */
export interface EmbeddingCreateResponse {
    /**
     * Unique identifier for the embedding response.
     */
    id: string;
    /**
     * List of embedding results.
     */
    data: Array<EmbeddingCreateResponse.Data>;
    /**
     * ID of the embedding model used.
     */
    model: string;
    /**
     * The object type, which is always "list".
     */
    object: string;
    /**
     * Usage statistics for the completion request.
     */
    usage: EmbeddingCreateResponse.Usage;
    /**
     * Timestamp of when the embeddings were created.
     */
    created?: number | null;
}
export declare namespace EmbeddingCreateResponse {
    /**
     * Schema for a single embedding result.
     */
    interface Data {
        /**
         * List of embedding values or a base64 encoded string.
         */
        embedding: Array<number> | string;
        /**
         * Index of the input chunk.
         */
        index: number;
        /**
         * The object type, which is always "embedding".
         */
        object?: 'embedding';
    }
    /**
     * Usage statistics for the completion request.
     */
    interface Usage {
        /**
         * Number of tokens in the prompt.
         */
        prompt_tokens: number;
        /**
         * Total number of tokens used in the request (prompt + completion).
         */
        total_tokens: number;
        /**
         * Number of tokens in the generated completion.
         */
        completion_tokens?: number | null;
        /**
         * Breakdown of tokens in the prompt.
         */
        prompt_tokens_details?: Usage.PromptTokensDetails | null;
    }
    namespace Usage {
        /**
         * Breakdown of tokens in the prompt.
         */
        interface PromptTokensDetails {
            /**
             * Number of tokens that were cached and reused.
             */
            cached_tokens?: number | null;
        }
    }
}
export interface EmbeddingCreateParams {
    /**
     * Single text chunk or a list of text chunks to embed.
     */
    input: string | Array<string>;
    /**
     * ID of the embedding model to use.
     */
    model: string;
    /**
     * The format to return the embeddings in. Can be either float or base64.
     */
    encoding_format?: 'float' | 'base64' | null;
    /**
     * Number of tokens to truncate from the prompt if it exceeds model limits.
     */
    truncate_prompt_tokens?: number | null;
    /**
     * A unique identifier representing your end-user.
     */
    user?: string | null;
}
export declare namespace Embeddings {
    export { type EmbeddingCreateResponse as EmbeddingCreateResponse, type EmbeddingCreateParams as EmbeddingCreateParams, };
}
//# sourceMappingURL=embeddings.d.ts.map