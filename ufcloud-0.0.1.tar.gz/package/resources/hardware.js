"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Hardware = void 0;
const resource_1 = require("../core/resource.js");
const path_1 = require("../internal/utils/path.js");
class Hardware extends resource_1.APIResource {
    /**
     * Retrieve details for a specific hardware configuration by its ID.
     */
    retrieve(id, options) {
        return this._client.get((0, path_1.path) `/v1/hardware/${id}`, options);
    }
    /**
     * List available GPU hardware configurations. Optionally filter by model
     * compatibility.
     */
    list(query = {}, options) {
        return this._client.get('/v1/hardware', { query, ...options });
    }
}
exports.Hardware = Hardware;
//# sourceMappingURL=hardware.js.map