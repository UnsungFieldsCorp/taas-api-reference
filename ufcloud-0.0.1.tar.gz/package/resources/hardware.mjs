// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { path } from "../internal/utils/path.mjs";
export class Hardware extends APIResource {
    /**
     * Retrieve details for a specific hardware configuration by its ID.
     */
    retrieve(id, options) {
        return this._client.get(path `/v1/hardware/${id}`, options);
    }
    /**
     * List available GPU hardware configurations. Optionally filter by model
     * compatibility.
     */
    list(query = {}, options) {
        return this._client.get('/v1/hardware', { query, ...options });
    }
}
//# sourceMappingURL=hardware.mjs.map