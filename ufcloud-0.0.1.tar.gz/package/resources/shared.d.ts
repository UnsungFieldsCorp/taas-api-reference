/**
 * Combine multiple filters using `and` or `or`.
 */
export interface CompoundFilter {
    /**
     * Array of filters to combine. Items can be `ComparisonFilter` or
     * `CompoundFilter`.
     */
    filters: Array<CompoundFilter.ComparisonFilter | CompoundFilter>;
    /**
     * Type of operation: `and` or `or`.
     */
    type: 'and' | 'or';
}
export declare namespace CompoundFilter {
    /**
     * A filter used to compare a specified attribute key to a given value using a
     * defined comparison operation.
     */
    interface ComparisonFilter {
        /**
         * The key to compare against the value.
         */
        key: string;
        /**
         * Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`,
         * `nin`.
         */
        type: 'eq' | 'ne' | 'gt' | 'gte' | 'lt' | 'lte';
        /**
         * The value to compare against the attribute key; supports string, number, or
         * boolean types.
         */
        value: string | number | boolean | Array<string | number>;
    }
}
//# sourceMappingURL=shared.d.ts.map