// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class Embeddings extends APIResource {
    /**
     * Creates embeddings for a single text chunk or a list of text chunks.
     */
    create(body, options) {
        return this._client.post('/openai/v1/embeddings', { body, ...options });
    }
}
//# sourceMappingURL=embeddings.mjs.map