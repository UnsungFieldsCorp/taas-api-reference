"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Endpoints = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
const path_1 = require("../internal/utils/path.js");
class Endpoints extends resource_1.APIResource {
    /**
     * Deploy a fine-tuned model on dedicated GPU hardware.
     *
     * @example
     * ```ts
     * const dedicatedEndpointResponse =
     *   await client.endpoints.create({
     *     display_name: 'My Llama Endpoint',
     *     model: 'org_abc/llama-3.1-8b-ft-xyz',
     *   });
     * ```
     */
    create(body, options) {
        return this._client.post('/v1/endpoints', { body, ...options });
    }
    /**
     * Retrieve details of a specific dedicated endpoint.
     *
     * @example
     * ```ts
     * const dedicatedEndpointResponse =
     *   await client.endpoints.retrieve('endpoint_id');
     * ```
     */
    retrieve(endpointID, options) {
        return this._client.get((0, path_1.path) `/v1/endpoints/${endpointID}`, options);
    }
    /**
     * Update endpoint configuration or control lifecycle (stop/start).
     *
     * @example
     * ```ts
     * const dedicatedEndpointResponse =
     *   await client.endpoints.update('endpoint_id');
     * ```
     */
    update(endpointID, body, options) {
        return this._client.patch((0, path_1.path) `/v1/endpoints/${endpointID}`, { body, ...options });
    }
    /**
     * List dedicated endpoints for the authenticated organization.
     *
     * @example
     * ```ts
     * const endpoints = await client.endpoints.list();
     * ```
     */
    list(query = {}, options) {
        return this._client.get('/v1/endpoints', { query, ...options });
    }
    /**
     * Permanently delete a dedicated endpoint. Only allowed from STOPPED or FAILED
     * state.
     *
     * @example
     * ```ts
     * await client.endpoints.delete('endpoint_id');
     * ```
     */
    delete(endpointID, options) {
        return this._client.delete((0, path_1.path) `/v1/endpoints/${endpointID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: '*/*' }, options?.headers]),
        });
    }
}
exports.Endpoints = Endpoints;
//# sourceMappingURL=endpoints.js.map