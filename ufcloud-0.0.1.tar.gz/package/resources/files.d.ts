import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { type Uploadable } from "../core/uploads.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Files extends APIResource {
    /**
     * Uploads a file to external storage (S3) and creates corresponding metadata in
     * MongoDB.
     */
    create(body: FileCreateParams, options?: RequestOptions): APIPromise<FileCreateResponse>;
    /**
     * Returns a list of files that belong to the user, optionally filtered by purpose.
     */
    retrieve(fileID: string, options?: RequestOptions): APIPromise<FileRetrieveResponse>;
    /**
     * Returns a list of files that belong to the user, optionally filtered by purpose.
     */
    list(query?: FileListParams | null | undefined, options?: RequestOptions): APIPromise<FileListResponse>;
    /**
     * Delete a file and remove it from all vector stores.
     */
    delete(fileID: string, options?: RequestOptions): APIPromise<FileDeleteResponse>;
    /**
     * Returns the contents of the specified file.
     */
    content(fileID: string, options?: RequestOptions): APIPromise<Response>;
    /**
     * Trigger JSONL file validation/preprocessing.
     */
    preprocess(fileID: string, options?: RequestOptions): APIPromise<FilePreprocessResponse>;
    /**
     * Generates a presigned POST request for securely uploading files directly to S3
     * from a client.
     */
    presignedPost(params: FilePresignedPostParams, options?: RequestOptions): APIPromise<FilePresignedPostResponse>;
}
export interface FileCreateResponse {
    /**
     * The file identifier, which can be referenced in the API endpoints.
     */
    id: string;
    /**
     * The size of the file, in bytes.
     */
    bytes: number;
    /**
     * The Unix timestamp (in seconds) for when the file was created.
     */
    created_at: number;
    /**
     * The name of the file.
     */
    filename: string;
    /**
     * The object type, which is always file.
     */
    object: 'file';
    /**
     * The intended purpose of the uploaded file.
     */
    purpose: string;
}
export interface FileRetrieveResponse {
    /**
     * The file identifier, which can be referenced in the API endpoints.
     */
    id: string;
    /**
     * The size of the file, in bytes.
     */
    bytes: number;
    /**
     * The Unix timestamp (in seconds) for when the file was created.
     */
    created_at: number;
    /**
     * The name of the file.
     */
    filename: string;
    /**
     * The object type, which is always file.
     */
    object: 'file';
    /**
     * The intended purpose of the uploaded file.
     */
    purpose: string;
}
export interface FileListResponse {
    /**
     * The list of files.
     */
    data: Array<FileListResponse.Data>;
    /**
     * The object type, which is always list.
     */
    object: 'list';
}
export declare namespace FileListResponse {
    interface Data {
        /**
         * The file identifier, which can be referenced in the API endpoints.
         */
        id: string;
        /**
         * The size of the file, in bytes.
         */
        bytes: number;
        /**
         * The Unix timestamp (in seconds) for when the file was created.
         */
        created_at: number;
        /**
         * The name of the file.
         */
        filename: string;
        /**
         * The object type, which is always file.
         */
        object: 'file';
        /**
         * The intended purpose of the uploaded file.
         */
        purpose: string;
    }
}
export interface FileDeleteResponse {
    /**
     * The ID of the file that was deleted.
     */
    id: string;
    /**
     * Whether the file was deleted successfully.
     */
    deleted: true;
    /**
     * The object type, which is always file.
     */
    object: 'file';
}
export interface FilePreprocessResponse {
    file: FilePreprocessResponse.File;
}
export declare namespace FilePreprocessResponse {
    interface File {
        created_at: string;
        file_id: string;
        filename: string;
        purpose: string;
        status: 'pending' | 'processed';
        updated_at: string;
        line_count?: number | null;
        schema_type?: 'messages' | 'instruction' | null;
        size_bytes?: number | null;
    }
}
export type FilePresignedPostResponse = FilePresignedPostResponse.FineTunePresignedPostResponse | FilePresignedPostResponse.GenericPresignedPostResponse;
export declare namespace FilePresignedPostResponse {
    interface FineTunePresignedPostResponse {
        file: FineTunePresignedPostResponse.File;
        upload: FineTunePresignedPostResponse.Upload;
    }
    namespace FineTunePresignedPostResponse {
        interface File {
            created_at: string;
            file_id: string;
            filename: string;
            purpose: string;
            status: 'pending' | 'processed';
            updated_at: string;
            line_count?: number | null;
            schema_type?: 'messages' | 'instruction' | null;
            size_bytes?: number | null;
        }
        interface Upload {
            fields: Upload.Fields;
            headers: Upload.Headers;
            method: 'POST';
            url: string;
        }
        namespace Upload {
            interface Fields {
                AWSAccessKeyId?: string;
                'Content-Type'?: string;
                key?: string;
                policy?: string;
                signature?: string;
                'x-amz-security-token'?: string | null;
                [k: string]: unknown;
            }
            interface Headers {
                'Content-Type'?: string;
            }
        }
    }
    interface GenericPresignedPostResponse {
        content_type: string;
        expires_in: 3600;
        fields: {
            [key: string]: unknown;
        };
        filename: string;
        requested_at: string;
        status: 'PresignedPostGenerated';
        purpose?: string | null;
    }
}
export interface FileCreateParams {
    /**
     * The File object to be uploaded.
     */
    file: Uploadable;
    /**
     * The intended purpose of the uploaded file.
     */
    purpose: string;
}
export interface FileListParams {
    purpose?: string;
}
export interface FilePresignedPostParams {
    content_type: string;
    file_name: string;
    purpose?: string | null;
}
export declare namespace Files {
    export { type FileCreateResponse as FileCreateResponse, type FileRetrieveResponse as FileRetrieveResponse, type FileListResponse as FileListResponse, type FileDeleteResponse as FileDeleteResponse, type FilePreprocessResponse as FilePreprocessResponse, type FilePresignedPostResponse as FilePresignedPostResponse, type FileCreateParams as FileCreateParams, type FileListParams as FileListParams, type FilePresignedPostParams as FilePresignedPostParams, };
}
//# sourceMappingURL=files.d.ts.map