"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Rerank = void 0;
const resource_1 = require("../core/resource.js");
class Rerank extends resource_1.APIResource {
    /**
     * Reranks a list of documents based on a query.
     */
    create(body, options) {
        return this._client.post('/v1/rerank', { body, ...options });
    }
}
exports.Rerank = Rerank;
//# sourceMappingURL=rerank.js.map