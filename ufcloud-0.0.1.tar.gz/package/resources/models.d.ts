import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Models extends APIResource {
    /**
     * Retrieves a model instance.
     */
    retrieve(modelID: string, options?: RequestOptions): APIPromise<ModelRetrieveResponse>;
    /**
     * Lists the currently available models, and provides basic information about each
     * one.
     */
    list(options?: RequestOptions): APIPromise<ModelListResponse>;
}
export interface ModelRetrieveResponse {
    /**
     * The model ID.
     */
    id: string;
    /**
     * Whether the model is active.
     */
    active: boolean;
    /**
     * The capabilities of the model.
     */
    capabilities: Array<string>;
    /**
     * The object type, which is always model.
     */
    object: string;
}
export interface ModelListResponse {
    data: Array<ModelListResponse.Data>;
    /**
     * The object type, which is always list.
     */
    object: string;
}
export declare namespace ModelListResponse {
    /**
     * A model object.
     */
    interface Data {
        /**
         * The model ID.
         */
        id: string;
        /**
         * Whether the model is active.
         */
        active: boolean;
        /**
         * The capabilities of the model.
         */
        capabilities: Array<string>;
        /**
         * The object type, which is always model.
         */
        object: string;
    }
}
export declare namespace Models {
    export { type ModelRetrieveResponse as ModelRetrieveResponse, type ModelListResponse as ModelListResponse };
}
//# sourceMappingURL=models.d.ts.map