import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Rerank extends APIResource {
    /**
     * Reranks a list of documents based on a query.
     */
    create(body: RerankCreateParams, options?: RequestOptions): APIPromise<RerankCreateResponse>;
}
/**
 * Response schema for reranked documents.
 */
export interface RerankCreateResponse {
    /**
     * Unique identifier for the reranking response.
     */
    id: string;
    /**
     * ID of the reranking model used.
     */
    model: string;
    /**
     * A list of reranking results.
     */
    results: Array<RerankCreateResponse.Result>;
    /**
     * Token usage information.
     */
    usage: RerankCreateResponse.Usage;
}
export declare namespace RerankCreateResponse {
    /**
     * Schema for a single reranking result.
     */
    interface Result {
        /**
         * Schema for a document in reranking responses.
         */
        document: Result.Document;
        /**
         * The original index of the document in the request.
         */
        index: number;
        /**
         * The relevance score assigned by the reranking model.
         */
        relevance_score: number;
    }
    namespace Result {
        /**
         * Schema for a document in reranking responses.
         */
        interface Document {
            /**
             * A specialized parameter type for scoring multimodal content.
             */
            multi_modal?: Document.MultiModal | null;
            /**
             * The content of the document.
             */
            text?: string | null;
        }
        namespace Document {
            /**
             * A specialized parameter type for scoring multimodal content.
             */
            interface MultiModal {
                content: Array<MultiModal.ChatCompletionContentPartImageParam | MultiModal.ChatCompletionContentPartImageEmbedsParam>;
                [k: string]: unknown;
            }
            namespace MultiModal {
                interface ChatCompletionContentPartImageParam {
                    image_url: ChatCompletionContentPartImageParam.ImageURL;
                    type: 'image_url';
                }
                namespace ChatCompletionContentPartImageParam {
                    interface ImageURL {
                        url: string;
                        detail?: 'auto' | 'low' | 'high';
                    }
                }
                interface ChatCompletionContentPartImageEmbedsParam {
                    type: 'image_embeds';
                    image_embeds?: string | {
                        [key: string]: string;
                    } | null;
                    uuid?: string | null;
                    [k: string]: unknown;
                }
            }
        }
    }
    /**
     * Token usage information.
     */
    interface Usage {
        /**
         * Total tokens consumed.
         */
        total_tokens: number;
    }
}
export interface RerankCreateParams {
    /**
     * A list of document texts to be reranked.
     */
    documents: Array<string>;
    /**
     * ID of the reranking model to use.
     */
    model: string;
    /**
     * The query string to rerank documents against.
     */
    query: string;
    /**
     * Optional multi-modal processor parameters.
     */
    mm_processor_kwargs?: {
        [key: string]: unknown;
    } | null;
    /**
     * Priority of the request.
     */
    priority?: number | null;
    /**
     * The number of top results to return.
     */
    top_n?: number | null;
    /**
     * Number of tokens to truncate from the prompt if it exceeds model limits.
     */
    truncate_prompt_tokens?: number | null;
}
export declare namespace Rerank {
    export { type RerankCreateResponse as RerankCreateResponse, type RerankCreateParams as RerankCreateParams };
}
//# sourceMappingURL=rerank.d.ts.map