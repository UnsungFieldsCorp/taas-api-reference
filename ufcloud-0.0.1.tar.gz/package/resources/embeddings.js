"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Embeddings = void 0;
const resource_1 = require("../core/resource.js");
class Embeddings extends resource_1.APIResource {
    /**
     * Creates embeddings for a single text chunk or a list of text chunks.
     */
    create(body, options) {
        return this._client.post('/openai/v1/embeddings', { body, ...options });
    }
}
exports.Embeddings = Embeddings;
//# sourceMappingURL=embeddings.js.map