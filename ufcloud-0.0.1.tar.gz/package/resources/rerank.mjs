// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class Rerank extends APIResource {
    /**
     * Reranks a list of documents based on a query.
     */
    create(body, options) {
        return this._client.post('/v1/rerank', { body, ...options });
    }
}
//# sourceMappingURL=rerank.mjs.map