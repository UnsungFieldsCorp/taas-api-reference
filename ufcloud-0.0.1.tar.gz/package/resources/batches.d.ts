import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Batches extends APIResource {
    /**
     * Creates and executes a batch from an uploaded file of requests.
     */
    create(body: BatchCreateParams, options?: RequestOptions): APIPromise<BatchCreateResponse>;
    /**
     * Retrieves a batch.
     */
    retrieve(batchID: string, options?: RequestOptions): APIPromise<BatchRetrieveResponse>;
    /**
     * Returns a paginated list of batches.
     */
    list(query?: BatchListParams | null | undefined, options?: RequestOptions): APIPromise<BatchListResponse>;
    /**
     * Initiates the cancellation of a running batch job.
     */
    cancel(batchID: string, options?: RequestOptions): APIPromise<BatchCancelResponse>;
}
export interface BatchCreateResponse {
    /**
     * The batch ID.
     */
    id: string;
    /**
     * The time frame for the batch completion.
     */
    completion_window: string;
    /**
     * The creation timestamp in Unix format.
     */
    created_at: number;
    /**
     * The endpoint for the batch requests.
     */
    endpoint: string;
    /**
     * The expiration timestamp in Unix format.
     */
    expires_at: number;
    /**
     * The ID of the input file.
     */
    input_file_id: string;
    cancelled_at?: string;
    cancelling_at?: string;
    completed_at?: string;
    /**
     * The ID of the file containing the outputs of requests with errors.
     */
    error_file_id?: string;
    errors?: string;
    expired_at?: string;
    failed_at?: string;
    finalizing_at?: string;
    in_progress_at?: string;
    /**
     * Key-value pairs that can be attached to an object. This can be useful for
     * storing additional information about the object in a structured format, and
     * querying for objects via API or the dashboard.
     */
    metadata?: {
        [key: string]: unknown;
    };
    /**
     * The object type, always 'batch'.
     */
    object?: 'batch';
    /**
     * The ID of the file containing the outputs of successfully executed requests.
     */
    output_file_id?: string;
    /**
     * A model to track the total, completed, and failed requests within a batch job.
     */
    request_counts?: BatchCreateResponse.RequestCounts;
    /**
     * The status of the batch job.
     */
    status?: string;
}
export declare namespace BatchCreateResponse {
    /**
     * A model to track the total, completed, and failed requests within a batch job.
     */
    interface RequestCounts {
        /**
         * Number of requests that have been completed successfully.
         */
        completed?: number;
        /**
         * Number of requests that have failed.
         */
        failed?: number;
        /**
         * Total number of requests in the batch.
         */
        total?: number;
    }
}
export interface BatchRetrieveResponse {
    /**
     * The batch ID.
     */
    id: string;
    /**
     * The time frame for the batch completion.
     */
    completion_window: string;
    /**
     * The creation timestamp in Unix format.
     */
    created_at: number;
    /**
     * The endpoint for the batch requests.
     */
    endpoint: string;
    /**
     * A model to track the total, completed, and failed requests within a batch job.
     */
    execution_results: BatchRetrieveResponse.ExecutionResults;
    /**
     * The expiration timestamp in Unix format.
     */
    expires_at: number;
    /**
     * The ID of the input file.
     */
    input_file_id: string;
    /**
     * A model to track the total, completed, and failed requests within a batch job.
     */
    request_counts: BatchRetrieveResponse.RequestCounts;
    /**
     * The status of the batch job.
     */
    status: string;
    cancelled_at?: number;
    completed_at?: number;
    /**
     * The ID of the file containing the outputs of requests with errors.
     */
    error_file_id?: string;
    failed_at?: number;
    /**
     * Key-value pairs that can be attached to an object. This can be useful for
     * storing additional information about the object in a structured format, and
     * querying for objects via API or the dashboard.
     */
    metadata?: {
        [key: string]: unknown;
    };
    /**
     * The object type, always 'batch'.
     */
    object?: 'batch';
    /**
     * The ID of the file containing the outputs of successfully executed requests.
     */
    output_file_id?: string;
}
export declare namespace BatchRetrieveResponse {
    /**
     * A model to track the total, completed, and failed requests within a batch job.
     */
    interface ExecutionResults {
        /**
         * Number of requests that have been cancelled.
         */
        cancelled?: number;
        /**
         * Number of requests that have been processed unsuccessfully.
         */
        failed?: number;
        /**
         * Number of requests that have been processed.
         */
        processed?: number;
        /**
         * Number of requests that have been processed successfully.
         */
        successful?: number;
        /**
         * Total number of requests in the batch.
         */
        total_requests?: number;
    }
    /**
     * A model to track the total, completed, and failed requests within a batch job.
     */
    interface RequestCounts {
        /**
         * Number of requests that have been completed successfully.
         */
        completed?: number;
        /**
         * Number of requests that have failed.
         */
        failed?: number;
        /**
         * Total number of requests in the batch.
         */
        total?: number;
    }
}
export interface BatchListResponse {
    /**
     * The list of batches.
     */
    data: Array<BatchListResponse.Data>;
    /**
     * Whether there are more batches to fetch.
     */
    has_more: boolean;
    /**
     * The object type, always 'list'.
     */
    object: 'list';
}
export declare namespace BatchListResponse {
    /**
     * The batch object.
     */
    interface Data {
        /**
         * The batch ID.
         */
        id: string;
        /**
         * The time frame for the batch completion.
         */
        completion_window: string;
        /**
         * The creation timestamp in Unix format.
         */
        created_at: number;
        /**
         * The endpoint for the batch requests.
         */
        endpoint: string;
        /**
         * The expiration timestamp in Unix format.
         */
        expires_at: number;
        /**
         * The ID of the input file.
         */
        input_file_id: string;
        /**
         * A model to track the total, completed, and failed requests within a batch job.
         */
        request_counts: Data.RequestCounts;
        /**
         * The status of the batch job.
         */
        status: string;
        cancelled_at?: number;
        completed_at?: number;
        /**
         * The ID of the file containing the outputs of requests with errors.
         */
        error_file_id?: string;
        failed_at?: number;
        /**
         * Key-value pairs that can be attached to an object. This can be useful for
         * storing additional information about the object in a structured format, and
         * querying for objects via API or the dashboard.
         */
        metadata?: {
            [key: string]: unknown;
        };
        /**
         * The object type, always 'batch'.
         */
        object?: 'batch';
        /**
         * The ID of the file containing the outputs of successfully executed requests.
         */
        output_file_id?: string;
    }
    namespace Data {
        /**
         * A model to track the total, completed, and failed requests within a batch job.
         */
        interface RequestCounts {
            /**
             * Number of requests that have been completed successfully.
             */
            completed?: number;
            /**
             * Number of requests that have failed.
             */
            failed?: number;
            /**
             * Total number of requests in the batch.
             */
            total?: number;
        }
    }
}
export interface BatchCancelResponse {
    /**
     * The batch ID.
     */
    batch_id: string;
    /**
     * Cancellation status message.
     */
    message: string;
    /**
     * The status before cancellation.
     */
    previous_status: string;
    /**
     * The new status of the batch.
     */
    status: string;
    /**
     * Whether task cancellation was attempted.
     */
    task_cancellation_attempted: boolean;
}
export interface BatchCreateParams {
    /**
     * The time frame within which the batch should be processed, e.g., '24h'.
     */
    completion_window: string;
    /**
     * The endpoint to be used for all requests in the batch. Currently
     * /v1/chat/completions is supported.
     */
    endpoint: string;
    /**
     * The ID of an uploaded file that contains requests for the new batch.
     */
    input_file_id: string;
    /**
     * Key-value pairs that can be attached to an object. This can be useful for
     * storing additional information about the object in a structured format, and
     * querying for objects via API or the dashboard.
     */
    metadata?: {
        [key: string]: unknown;
    };
}
export interface BatchListParams {
    after?: string;
    limit?: number;
}
export declare namespace Batches {
    export { type BatchCreateResponse as BatchCreateResponse, type BatchRetrieveResponse as BatchRetrieveResponse, type BatchListResponse as BatchListResponse, type BatchCancelResponse as BatchCancelResponse, type BatchCreateParams as BatchCreateParams, type BatchListParams as BatchListParams, };
}
//# sourceMappingURL=batches.d.ts.map