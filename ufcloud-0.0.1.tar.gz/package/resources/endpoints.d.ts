import { APIResource } from "../core/resource.js";
import { APIPromise } from "../core/api-promise.js";
import { RequestOptions } from "../internal/request-options.js";
export declare class Endpoints extends APIResource {
    /**
     * Deploy a fine-tuned model on dedicated GPU hardware.
     *
     * @example
     * ```ts
     * const dedicatedEndpointResponse =
     *   await client.endpoints.create({
     *     display_name: 'My Llama Endpoint',
     *     model: 'org_abc/llama-3.1-8b-ft-xyz',
     *   });
     * ```
     */
    create(body: EndpointCreateParams, options?: RequestOptions): APIPromise<DedicatedEndpointResponse>;
    /**
     * Retrieve details of a specific dedicated endpoint.
     *
     * @example
     * ```ts
     * const dedicatedEndpointResponse =
     *   await client.endpoints.retrieve('endpoint_id');
     * ```
     */
    retrieve(endpointID: string, options?: RequestOptions): APIPromise<DedicatedEndpointResponse>;
    /**
     * Update endpoint configuration or control lifecycle (stop/start).
     *
     * @example
     * ```ts
     * const dedicatedEndpointResponse =
     *   await client.endpoints.update('endpoint_id');
     * ```
     */
    update(endpointID: string, body: EndpointUpdateParams, options?: RequestOptions): APIPromise<DedicatedEndpointResponse>;
    /**
     * List dedicated endpoints for the authenticated organization.
     *
     * @example
     * ```ts
     * const endpoints = await client.endpoints.list();
     * ```
     */
    list(query?: EndpointListParams | null | undefined, options?: RequestOptions): APIPromise<EndpointListResponse>;
    /**
     * Permanently delete a dedicated endpoint. Only allowed from STOPPED or FAILED
     * state.
     *
     * @example
     * ```ts
     * await client.endpoints.delete('endpoint_id');
     * ```
     */
    delete(endpointID: string, options?: RequestOptions): APIPromise<void>;
}
/**
 * Full dedicated endpoint object as returned by the API.
 */
export interface DedicatedEndpointResponse {
    /**
     * S3 location of LoRA adapter archive.
     */
    adapter_s3_uri: string;
    /**
     * Endpoint creation timestamp.
     */
    created_at: string;
    /**
     * User ID or API key ID that created this endpoint.
     */
    created_by: string;
    /**
     * User-provided descriptive name.
     */
    display_name: string;
    /**
     * Unique public identifier, format: dep-{nanoid(11)}.
     */
    endpoint_id: string;
    /**
     * Hardware configuration ID (e.g., '4x_nvidia_h200_140gb_sxm').
     */
    hardware: string;
    /**
     * Snapshot of hardware configuration parameters for the dedicated endpoint.
     */
    hardware_config: EndpointHardwareConfig;
    /**
     * Source fine-tuning job identifier.
     */
    job_id: string;
    /**
     * Full model name.
     */
    model: string;
    /**
     * Object type identifier.
     */
    object: string;
    /**
     * Owner organization identifier.
     */
    org_id: string;
    /**
     * Base model identifier (references inference_base_models.model_id).
     */
    parent_model: string;
    /**
     * Lifecycle state of the endpoint.
     */
    state: 'PENDING' | 'PROVISIONING' | 'ACTIVE' | 'FAILED' | 'STOPPING' | 'STOPPED';
    /**
     * Endpoint type.
     */
    type: string;
    /**
     * Last modification timestamp.
     */
    updated_at: string;
    /**
     * Cumulative usage statistics for a dedicated endpoint.
     */
    usage: EndpointUsage;
    /**
     * First ACTIVE state timestamp.
     */
    activated_at?: string | null;
    /**
     * Reference to dedicated pool in inference_pools collection.
     */
    dedicated_pool_id?: string | null;
    /**
     * Error details, present only when endpoint state is FAILED.
     */
    error?: EndpointError | null;
    /**
     * Minutes of inactivity before auto-shutdown. Null if disabled.
     */
    inactive_timeout?: number | null;
}
/**
 * Error details, present only when endpoint state is FAILED.
 */
export interface EndpointError {
    /**
     * Error code (e.g., 'ADAPTER_NOT_FOUND', 'K8S_API_ERROR', 'DEPLOYMENT_TIMEOUT').
     */
    code: string;
    /**
     * Human-readable error description.
     */
    message: string;
    /**
     * Error type (e.g., 'provision_error', 'adapter_error', 'k8s_error').
     */
    type: string;
}
/**
 * Snapshot of hardware configuration parameters for the dedicated endpoint.
 */
export interface EndpointHardwareConfig {
    /**
     * GPUs allocated, user-selected (snapshot from hardware.specs).
     */
    gpu_count: number;
    /**
     * Minimum GPUs required by the model for this GPU type.
     */
    gpu_count_min: number;
    /**
     * Interconnect type (snapshot from hardware.specs).
     */
    gpu_link: string;
    /**
     * GPU VRAM in GB (snapshot from hardware.specs).
     */
    gpu_memory: number;
    /**
     * GPU model (snapshot from hardware.specs).
     */
    gpu_type: string;
    /**
     * Maximum context length for this GPU type.
     */
    max_model_len: number;
    /**
     * Tensor parallelism degree for this GPU type.
     */
    tensor_parallel: number;
}
/**
 * Cumulative usage statistics for a dedicated endpoint.
 */
export interface EndpointUsage {
    /**
     * Cumulative GPU hours consumed.
     */
    gpu_hours_total?: number;
    /**
     * Timestamp of most recent request.
     */
    last_request_at?: string | null;
    /**
     * Total inference requests.
     */
    requests_total?: number;
    /**
     * Total input tokens processed.
     */
    tokens_in_total?: number;
    /**
     * Total output tokens generated.
     */
    tokens_out_total?: number;
}
export interface EndpointListResponse {
    data: Array<DedicatedEndpointResponse>;
    /**
     * True if more pages exist
     */
    has_more: boolean;
    /**
     * Items per page
     */
    limit: number;
    /**
     * Current page number (1-based)
     */
    page: number;
    /**
     * Count of items returned so far
     */
    count?: number;
    /**
     * Total count of items
     */
    total?: number;
}
export interface EndpointCreateParams {
    /**
     * User-friendly identifier (1-64 chars, alphanumeric with spaces and hyphens).
     */
    display_name: string;
    /**
     * Full model name (output_model_name from a completed fine-tuning job).
     */
    model: string;
    /**
     * Hardware configuration ID from GET /v1/hardware (e.g.,
     * '4x_nvidia_h200_140gb_sxm'). Defaults to minimum compatible hardware if omitted.
     */
    hardware?: string | null;
    /**
     * Minutes of inactivity before auto-shutdown. Null to disable (default: null).
     */
    inactive_timeout?: number | null;
}
export interface EndpointUpdateParams {
    /**
     * New display name (1-64 chars, alphanumeric with spaces and hyphens). Only when
     * ACTIVE.
     */
    display_name?: string | null;
    /**
     * Minutes of inactivity before auto-shutdown. Null to disable. Only when ACTIVE.
     */
    inactive_timeout?: number | null;
    /**
     * Lifecycle control: 'STOPPED' (from ACTIVE) or 'STARTED' (from STOPPED).
     */
    state?: 'STOPPED' | 'STARTED' | null;
}
export interface EndpointListParams {
    /**
     * Items per page, max 100
     */
    limit?: number;
    /**
     * Page number, 1-based
     */
    page?: number;
    /**
     * Filter by endpoint state
     */
    state?: 'PENDING' | 'PROVISIONING' | 'ACTIVE' | 'FAILED' | 'STOPPING' | 'STOPPED';
}
export declare namespace Endpoints {
    export { type DedicatedEndpointResponse as DedicatedEndpointResponse, type EndpointError as EndpointError, type EndpointHardwareConfig as EndpointHardwareConfig, type EndpointUsage as EndpointUsage, type EndpointListResponse as EndpointListResponse, type EndpointCreateParams as EndpointCreateParams, type EndpointUpdateParams as EndpointUpdateParams, type EndpointListParams as EndpointListParams, };
}
//# sourceMappingURL=endpoints.d.ts.map