import { APIResource } from "../../core/resource.js";
import { APIPromise } from "../../core/api-promise.js";
import { OffsetPagination, type OffsetPaginationParams, PagePromise } from "../../core/pagination.js";
import { RequestOptions } from "../../internal/request-options.js";
import * as ModelsAPI from "./models.js";
import { ModelListParams, ModelListResponse, Models } from "./models.js";
export declare class FineTuning extends APIResource {
    models: ModelsAPI.Models;
    /**
     * Create a new Fine-Tuning Job.
     */
    create(params: FineTuningCreateParams, options?: RequestOptions): APIPromise<FineTuningCreateResponse>;
    /**
     * Get details for a specific Fine-Tuning Job including associated events and
     * artifacts.
     */
    retrieve(jobID: string, options?: RequestOptions): APIPromise<FineTuningRetrieveResponse>;
    /**
     * List all Fine-Tuning Jobs for the organization.
     */
    list(query?: FineTuningListParams | null | undefined, options?: RequestOptions): PagePromise<FineTuningListResponsesOffsetPagination, FineTuningListResponse>;
    /**
     * Download the final adapter artifact for a specific Fine-Tuning Job.
     */
    downloadAdapter(jobID: string, query: FineTuningDownloadAdapterParams, options?: RequestOptions): APIPromise<Response>;
}
export type FineTuningListResponsesOffsetPagination = OffsetPagination<FineTuningListResponse>;
export interface FineTuningCreateResponse {
    /**
     * A lean summary of a fine-tuning job, returned upon creation.
     */
    job?: FineTuningCreateResponse.Job;
}
export declare namespace FineTuningCreateResponse {
    /**
     * A lean summary of a fine-tuning job, returned upon creation.
     */
    interface Job {
        created_at: string;
        job_id: string;
        model: string;
        /**
         * Enum for the status of a fine-tuning job.
         */
        status: 'PENDING' | 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'INVALID_INPUT';
        type: string;
        suffix?: string | null;
    }
}
export interface FineTuningRetrieveResponse {
    /**
     * Schema representing a fine-tuning job as stored in the database. org_id is
     * re-declared here as non-optional to enforce its presence in the database.
     */
    job?: FineTuningRetrieveResponse.Job;
}
export declare namespace FineTuningRetrieveResponse {
    /**
     * Schema representing a fine-tuning job as stored in the database. org_id is
     * re-declared here as non-optional to enforce its presence in the database.
     */
    interface Job {
        id: string;
        created_at: string;
        job_id: string;
        org_id: string;
        /**
         * Enum for the status of a fine-tuning job.
         */
        status: 'PENDING' | 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'INVALID_INPUT';
        training_file_id: string;
        updated_at: string;
        /**
         * Schema for the artifacts of a fine-tuning job.
         */
        artifacts?: Job.Artifacts | null;
        error_code?: string | null;
        error_message?: string | null;
        /**
         * Enum for the type of error in a fine-tuning job.
         */
        error_type?: 'user_error' | 'system_error' | null;
        /**
         * Schema for the errors of a fine-tuning job.
         */
        errors?: Job.Errors | null;
        /**
         * Schema representing a fine-tuning event as stored in the database.
         */
        events?: Array<Job.Event> | null;
        finished_at?: string | null;
        /**
         * Schema for the hyperparameters of a fine-tuning job.
         */
        hyperparams?: Job.Hyperparams;
        /**
         * Schema for the metrics of a fine-tuning job.
         */
        metrics?: Job.Metrics | null;
        model?: string | null;
        runtime_seconds?: number | null;
        started_at?: string | null;
        suffix?: string | null;
        type?: string | null;
        /**
         * Schema for the canonical usage telemetry block of a fine-tuning job.
         */
        usage?: Job.Usage | null;
        validation_file_id?: string | null;
    }
    namespace Job {
        /**
         * Schema for the artifacts of a fine-tuning job.
         */
        interface Artifacts {
            checkpoints?: Array<Artifacts.Checkpoint>;
            /**
             * Schema for the final adapter artifact.
             */
            final_adapter?: Artifacts.FinalAdapter | null;
        }
        namespace Artifacts {
            /**
             * Schema for a checkpoint artifact.
             */
            interface Checkpoint {
                artifact_type: string;
                created_at: string;
                download_url: string;
                name: string;
            }
            /**
             * Schema for the final adapter artifact.
             */
            interface FinalAdapter {
                artifact_type: 'adapter';
                created_at: string;
                download_url: string;
            }
        }
        /**
         * Schema for the errors of a fine-tuning job.
         */
        interface Errors {
            message?: string | null;
            stack?: string | null;
            type?: 'user_error' | 'system_error' | 'none' | null;
        }
        interface Event {
            id: string;
            event_type: 'JOB_PENDING' | 'JOB_START' | 'MODEL_DOWNLOADING' | 'MODEL_DOWNLOAD_COMPLETE' | 'TRAINING_DATA_DOWNLOADING' | 'TRAINING_DATA_READY' | 'PRECHECK_COMPLETE' | 'TRAINING_START' | 'EPOCH_COMPLETE' | 'EVAL_COMPLETE' | 'TRAINING_COMPLETE' | 'COMPRESSING_ADAPTER' | 'ADAPTER_COMPRESSION_COMPLETE' | 'MODEL_UPLOADING' | 'MODEL_UPLOAD_COMPLETE' | 'JOB_COMPLETE' | 'JOB_USER_ERROR' | 'JOB_SYSTEM_ERROR';
            job_id: string;
            message: string;
            org_id: string;
            /**
             * Schema for the metadata of a fine-tuning event.
             */
            metadata?: Event.FineTuneEventMetadata | {
                [key: string]: unknown;
            } | null;
            timestamp?: string;
        }
        namespace Event {
            /**
             * Schema for the metadata of a fine-tuning event.
             */
            interface FineTuneEventMetadata {
                epoch?: number | null;
                global_step?: number | null;
                model_name?: string | null;
            }
        }
        /**
         * Schema for the hyperparameters of a fine-tuning job.
         */
        interface Hyperparams {
            batch_size?: number;
            epochs?: number;
            gradient_accumulation_steps?: number;
            learning_rate?: number;
            lora_alpha?: number;
            lora_dropout?: number;
            lora_rank?: number;
            lora_target_modules?: Array<string>;
            lr_scheduler_args?: {
                [key: string]: unknown;
            };
            lr_scheduler_type?: string;
            max_grad_norm?: number;
            max_seq_len?: number;
            n_checkpoints?: number;
            n_evals?: number;
            train_on_inputs?: string;
            training_method?: string;
            warmup_ratio?: number;
            weight_decay?: number;
        }
        /**
         * Schema for the metrics of a fine-tuning job.
         */
        interface Metrics {
            epochs_completed?: number | null;
            eval_loss?: number | null;
            eval_tokens?: number | null;
            final_train_loss?: number | null;
            steps_completed?: number | null;
            train_tokens?: number | null;
        }
        /**
         * Schema for the canonical usage telemetry block of a fine-tuning job.
         */
        interface Usage {
            /**
             * Schema for the artifact usage of a fine-tuning job.
             */
            artifacts?: Usage.Artifacts | null;
            /**
             * Schema for the dataset usage of a fine-tuning job.
             */
            dataset?: Usage.Dataset | null;
            /**
             * Schema for the errors in the usage block of a fine-tuning job.
             */
            errors?: Usage.Errors | null;
            eval_tokens?: number | null;
            gpu_count?: number | null;
            gpu_end_at?: string | null;
            gpu_hours?: number | null;
            gpu_seconds?: number | null;
            gpu_start_at?: string | null;
            gpu_type?: string | null;
            max_seq_len?: number | null;
            runtime_seconds?: number | null;
            tokens_per_step?: number | null;
            total_steps?: number | null;
            train_tokens?: number | null;
        }
        namespace Usage {
            /**
             * Schema for the artifact usage of a fine-tuning job.
             */
            interface Artifacts {
                adapter_size_bytes?: number | null;
                checkpoint_sizes?: Array<number> | null;
                num_checkpoints?: number | null;
            }
            /**
             * Schema for the dataset usage of a fine-tuning job.
             */
            interface Dataset {
                line_count?: number | null;
                schema_type?: 'instruction' | 'messages' | null;
                size_bytes?: number | null;
                tokens_estimated?: number | null;
            }
            /**
             * Schema for the errors in the usage block of a fine-tuning job.
             */
            interface Errors {
                message?: string | null;
                stack?: string | null;
                type?: 'user_error' | 'system_error' | 'none' | null;
            }
        }
    }
}
/**
 * A concise summary of a fine-tuning job, used for list views.
 */
export interface FineTuningListResponse {
    created_at: string;
    job_id: string;
    model: string;
    /**
     * Enum for the status of a fine-tuning job.
     */
    status: 'PENDING' | 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'INVALID_INPUT';
    type: string;
    updated_at: string;
    runtime_seconds?: number | null;
    suffix?: string | null;
}
export interface FineTuningCreateParams {
    /**
     * Body param
     */
    model: string;
    /**
     * Body param
     */
    training_file_id: string;
    /**
     * Body param: Schema for the hyperparameters of a fine-tuning job.
     */
    hyperparams?: FineTuningCreateParams.Hyperparams;
    /**
     * Body param
     */
    org_id?: string | null;
    /**
     * Body param: Enum for the status of a fine-tuning job.
     */
    status?: 'PENDING' | 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'INVALID_INPUT' | null;
    /**
     * Body param
     */
    suffix?: string | null;
    /**
     * Body param
     */
    type?: string | null;
    /**
     * Body param
     */
    validation_file_id?: string | null;
    /**
     * Header param
     */
    'Idempotency-Key'?: string;
}
export declare namespace FineTuningCreateParams {
    /**
     * Schema for the hyperparameters of a fine-tuning job.
     */
    interface Hyperparams {
        batch_size?: number;
        epochs?: number;
        gradient_accumulation_steps?: number;
        learning_rate?: number;
        lora_alpha?: number;
        lora_dropout?: number;
        lora_rank?: number;
        lora_target_modules?: Array<string>;
        lr_scheduler_args?: {
            [key: string]: unknown;
        };
        lr_scheduler_type?: string;
        max_grad_norm?: number;
        max_seq_len?: number;
        n_checkpoints?: number;
        n_evals?: number;
        train_on_inputs?: string;
        training_method?: string;
        warmup_ratio?: number;
        weight_decay?: number;
    }
}
export interface FineTuningListParams extends OffsetPaginationParams {
    /**
     * Filter by model name
     */
    model?: string;
    /**
     * Page number, 1-based
     */
    page?: number;
    /**
     * Filter by job status
     */
    status?: 'PENDING' | 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'INVALID_INPUT';
}
export interface FineTuningDownloadAdapterParams {
    output_path: string;
}
export declare namespace FineTuning {
    export { type FineTuningCreateResponse as FineTuningCreateResponse, type FineTuningRetrieveResponse as FineTuningRetrieveResponse, type FineTuningListResponse as FineTuningListResponse, type FineTuningListResponsesOffsetPagination as FineTuningListResponsesOffsetPagination, type FineTuningCreateParams as FineTuningCreateParams, type FineTuningListParams as FineTuningListParams, type FineTuningDownloadAdapterParams as FineTuningDownloadAdapterParams, };
    export { Models as Models, type ModelListResponse as ModelListResponse, type ModelListParams as ModelListParams, };
}
//# sourceMappingURL=fine-tuning.d.ts.map