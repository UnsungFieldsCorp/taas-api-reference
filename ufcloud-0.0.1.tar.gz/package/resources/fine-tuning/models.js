"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Models = void 0;
const resource_1 = require("../../core/resource.js");
class Models extends resource_1.APIResource {
    /**
     * Returns a list of models available for fine-tuning.
     */
    list(query = {}, options) {
        return this._client.get('/v1/finetune/models/supported', { query, ...options });
    }
}
exports.Models = Models;
//# sourceMappingURL=models.js.map