import { APIResource } from "../../core/resource.js";
import { APIPromise } from "../../core/api-promise.js";
import { RequestOptions } from "../../internal/request-options.js";
export declare class Models extends APIResource {
    /**
     * Returns a list of models available for fine-tuning.
     */
    list(query?: ModelListParams | null | undefined, options?: RequestOptions): APIPromise<ModelListResponse>;
}
export interface ModelListResponse {
    models: Array<ModelListResponse.Model>;
}
export declare namespace ModelListResponse {
    /**
     * Response for a single fine-tuning model.
     */
    interface Model {
        default_gpu_count: number;
        default_gpu_type: string;
        family: string;
        max_lora_rank: number;
        max_seq_len: number;
        name: string;
        parameters_billion: number;
    }
}
export interface ModelListParams {
    family?: string;
}
export declare namespace Models {
    export { type ModelListResponse as ModelListResponse, type ModelListParams as ModelListParams };
}
//# sourceMappingURL=models.d.ts.map