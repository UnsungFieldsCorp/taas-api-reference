// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import * as fs from 'fs';
import * as os from 'os';
import * as nodePath from 'path';
import { UfcloudError } from "../../core/error.mjs";
import { APIResource } from "../../core/resource.mjs";
import { OffsetPagination } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
import { uuid4 } from "../../internal/utils/uuid.mjs";
import * as ModelsAPI from "./models.mjs";
import { Models } from "./models.mjs";
export class FineTuning extends APIResource {
    constructor() {
        super(...arguments);
        this.models = new ModelsAPI.Models(this._client);
    }
    /**
     * Create a new Fine-Tuning Job.
     */
    create(params, options) {
        const { 'Idempotency-Key': idempotencyKey, ...body } = params;
        const finalIdempotencyKey = idempotencyKey ?? uuid4();
        return this._client.post('/v1/fine-tuning/jobs', {
            body,
            ...options,
            headers: buildHeaders([{ 'Idempotency-Key': finalIdempotencyKey }, options?.headers]),
        });
    }
    /**
     * Get details for a specific Fine-Tuning Job including associated events and
     * artifacts.
     */
    retrieve(jobID, options) {
        return this._client.get(path `/v1/fine-tuning/jobs/${jobID}`, options);
    }
    /**
     * List all Fine-Tuning Jobs for the organization.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v1/fine-tuning/jobs', (OffsetPagination), {
            query,
            ...options,
        });
    }
    /**
     * Download the final adapter artifact for a specific Fine-Tuning Job.
     */
    downloadAdapter(jobID, query, options) {
        if (!jobID) {
            throw new UfcloudError(`Expected a non-empty value for \`job_id\` but received ${jobID}`);
        }
        const outputPath = query?.output_path;
        if (!outputPath) {
            throw new UfcloudError(`Expected a non-empty value for \`output_path\` but received ${String(outputPath)}`);
        }
        const expandedOutputPath = outputPath.startsWith('~') && (outputPath === '~' || /^~[\\/]/.test(outputPath)) ?
            nodePath.join(os.homedir(), outputPath.slice(1))
            : outputPath;
        let resolvedOutputPath;
        try {
            resolvedOutputPath = nodePath.resolve(expandedOutputPath);
        }
        catch (error) {
            throw new UfcloudError(`Invalid output path: ${outputPath} - ${String(error)}`);
        }
        const outputDir = nodePath.dirname(resolvedOutputPath);
        if (outputDir && !fs.existsSync(outputDir)) {
            try {
                fs.mkdirSync(outputDir, { recursive: true });
            }
            catch (error) {
                throw new UfcloudError(`Cannot create output directory: ${outputDir} - ${String(error)}`);
            }
        }
        return this._client
            .get(path `/v1/fine-tuning/jobs/${jobID}/artifacts`, {
            query,
            ...options,
            headers: buildHeaders([options?.headers]),
        })
            .then(async (adapterResponse) => {
            const finalAdapter = adapterResponse?.final_adapter;
            if (!finalAdapter || typeof finalAdapter !== 'object') {
                throw new UfcloudError('Invalid `final_adapter` in artifacts response');
            }
            const downloadURL = finalAdapter.download_url;
            if (typeof downloadURL !== 'string' || !downloadURL) {
                throw new UfcloudError('No `final_adapter.download_url` returned for this job');
            }
            const downloadResponse = await this._client.get(downloadURL, {
                ...options,
                headers: buildHeaders([{ Accept: 'application/octet-stream', Authorization: null }]),
                __binaryResponse: true,
            });
            const buffer = Buffer.from(await downloadResponse.arrayBuffer());
            await fs.promises.writeFile(resolvedOutputPath, buffer);
            return downloadResponse;
        });
    }
}
FineTuning.Models = Models;
//# sourceMappingURL=fine-tuning.mjs.map