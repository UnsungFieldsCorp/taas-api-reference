"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.FineTuning = void 0;
const tslib_1 = require("../../internal/tslib.js");
const fs = tslib_1.__importStar(require("fs"));
const os = tslib_1.__importStar(require("os"));
const nodePath = tslib_1.__importStar(require("path"));
const error_1 = require("../../core/error.js");
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const headers_1 = require("../../internal/headers.js");
const path_1 = require("../../internal/utils/path.js");
const uuid_1 = require("../../internal/utils/uuid.js");
const ModelsAPI = tslib_1.__importStar(require("./models.js"));
const models_1 = require("./models.js");
class FineTuning extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.models = new ModelsAPI.Models(this._client);
    }
    /**
     * Create a new Fine-Tuning Job.
     */
    create(params, options) {
        const { 'Idempotency-Key': idempotencyKey, ...body } = params;
        const finalIdempotencyKey = idempotencyKey ?? (0, uuid_1.uuid4)();
        return this._client.post('/v1/fine-tuning/jobs', {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([{ 'Idempotency-Key': finalIdempotencyKey }, options?.headers]),
        });
    }
    /**
     * Get details for a specific Fine-Tuning Job including associated events and
     * artifacts.
     */
    retrieve(jobID, options) {
        return this._client.get((0, path_1.path) `/v1/fine-tuning/jobs/${jobID}`, options);
    }
    /**
     * List all Fine-Tuning Jobs for the organization.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v1/fine-tuning/jobs', (pagination_1.OffsetPagination), {
            query,
            ...options,
        });
    }
    /**
     * Download the final adapter artifact for a specific Fine-Tuning Job.
     */
    downloadAdapter(jobID, query, options) {
        if (!jobID) {
            throw new error_1.UfcloudError(`Expected a non-empty value for \`job_id\` but received ${jobID}`);
        }
        const outputPath = query?.output_path;
        if (!outputPath) {
            throw new error_1.UfcloudError(`Expected a non-empty value for \`output_path\` but received ${String(outputPath)}`);
        }
        const expandedOutputPath = outputPath.startsWith('~') && (outputPath === '~' || /^~[\\/]/.test(outputPath)) ?
            nodePath.join(os.homedir(), outputPath.slice(1))
            : outputPath;
        let resolvedOutputPath;
        try {
            resolvedOutputPath = nodePath.resolve(expandedOutputPath);
        }
        catch (error) {
            throw new error_1.UfcloudError(`Invalid output path: ${outputPath} - ${String(error)}`);
        }
        const outputDir = nodePath.dirname(resolvedOutputPath);
        if (outputDir && !fs.existsSync(outputDir)) {
            try {
                fs.mkdirSync(outputDir, { recursive: true });
            }
            catch (error) {
                throw new error_1.UfcloudError(`Cannot create output directory: ${outputDir} - ${String(error)}`);
            }
        }
        return this._client
            .get((0, path_1.path) `/v1/fine-tuning/jobs/${jobID}/artifacts`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([options?.headers]),
        })
            .then(async (adapterResponse) => {
            const finalAdapter = adapterResponse?.final_adapter;
            if (!finalAdapter || typeof finalAdapter !== 'object') {
                throw new error_1.UfcloudError('Invalid `final_adapter` in artifacts response');
            }
            const downloadURL = finalAdapter.download_url;
            if (typeof downloadURL !== 'string' || !downloadURL) {
                throw new error_1.UfcloudError('No `final_adapter.download_url` returned for this job');
            }
            const downloadResponse = await this._client.get(downloadURL, {
                ...options,
                headers: (0, headers_1.buildHeaders)([{ Accept: 'application/octet-stream', Authorization: null }]),
                __binaryResponse: true,
            });
            const buffer = Buffer.from(await downloadResponse.arrayBuffer());
            await fs.promises.writeFile(resolvedOutputPath, buffer);
            return downloadResponse;
        });
    }
}
exports.FineTuning = FineTuning;
FineTuning.Models = models_1.Models;
//# sourceMappingURL=fine-tuning.js.map