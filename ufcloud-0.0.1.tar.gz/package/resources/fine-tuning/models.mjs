// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
export class Models extends APIResource {
    /**
     * Returns a list of models available for fine-tuning.
     */
    list(query = {}, options) {
        return this._client.get('/v1/finetune/models/supported', { query, ...options });
    }
}
//# sourceMappingURL=models.mjs.map