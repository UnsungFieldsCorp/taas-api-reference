"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Files = void 0;
const resource_1 = require("../core/resource.js");
const headers_1 = require("../internal/headers.js");
const uploads_1 = require("../internal/uploads.js");
const path_1 = require("../internal/utils/path.js");
class Files extends resource_1.APIResource {
    /**
     * Uploads a file to external storage (S3) and creates corresponding metadata in
     * MongoDB.
     */
    create(body, options) {
        return this._client.post('/openai/v1/files', (0, uploads_1.multipartFormRequestOptions)({ body, ...options }, this._client));
    }
    /**
     * Returns a list of files that belong to the user, optionally filtered by purpose.
     */
    retrieve(fileID, options) {
        return this._client.get((0, path_1.path) `/openai/v1/files/${fileID}`, options);
    }
    /**
     * Returns a list of files that belong to the user, optionally filtered by purpose.
     */
    list(query = {}, options) {
        return this._client.get('/openai/v1/files', { query, ...options });
    }
    /**
     * Delete a file and remove it from all vector stores.
     */
    delete(fileID, options) {
        return this._client.delete((0, path_1.path) `/openai/v1/files/${fileID}`, options);
    }
    /**
     * Returns the contents of the specified file.
     */
    content(fileID, options) {
        return this._client.get((0, path_1.path) `/openai/v1/files/${fileID}/content`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([{ Accept: 'application/octet-stream' }, options?.headers]),
            __binaryResponse: true,
        });
    }
    /**
     * Trigger JSONL file validation/preprocessing.
     */
    preprocess(fileID, options) {
        return this._client.post((0, path_1.path) `/v1/files/${fileID}/preprocess`, options);
    }
    /**
     * Generates a presigned POST request for securely uploading files directly to S3
     * from a client.
     */
    presignedPost(params, options) {
        const { content_type, file_name, purpose } = params;
        return this._client.post('/v1/files/presigned-post', {
            query: { content_type, file_name, purpose },
            ...options,
        });
    }
}
exports.Files = Files;
//# sourceMappingURL=files.js.map