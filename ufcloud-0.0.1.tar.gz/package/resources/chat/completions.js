"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Completions = void 0;
const resource_1 = require("../../core/resource.js");
const headers_1 = require("../../internal/headers.js");
class Completions extends resource_1.APIResource {
    create(body, options) {
        return this._client.post('/openai/v1/chat/completions', {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([body.stream ? { Accept: 'text/event-stream' } : {}, options?.headers]),
            stream: body.stream ?? false,
        });
    }
}
exports.Completions = Completions;
//# sourceMappingURL=completions.js.map