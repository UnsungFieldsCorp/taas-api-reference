// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
export class Completions extends APIResource {
    create(body, options) {
        return this._client.post('/openai/v1/chat/completions', {
            body,
            ...options,
            headers: buildHeaders([body.stream ? { Accept: 'text/event-stream' } : {}, options?.headers]),
            stream: body.stream ?? false,
        });
    }
}
//# sourceMappingURL=completions.mjs.map