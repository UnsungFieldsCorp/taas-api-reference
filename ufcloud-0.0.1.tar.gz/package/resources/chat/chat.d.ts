import { APIResource } from "../../core/resource.js";
import * as CompletionsAPI from "./completions.js";
import { ChatCompletionContentPartTextParam, ChatCompletionLogProb, CompletionCreateParams, CompletionCreateResponse, Completions, FunctionCall } from "./completions.js";
export declare class Chat extends APIResource {
    completions: CompletionsAPI.Completions;
}
export declare namespace Chat {
    export { Completions as Completions, type ChatCompletionContentPartTextParam as ChatCompletionContentPartTextParam, type ChatCompletionLogProb as ChatCompletionLogProb, type FunctionCall as FunctionCall, type CompletionCreateResponse as CompletionCreateResponse, type CompletionCreateParams as CompletionCreateParams, };
}
//# sourceMappingURL=chat.d.ts.map