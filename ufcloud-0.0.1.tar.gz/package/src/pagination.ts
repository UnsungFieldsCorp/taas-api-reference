/** @deprecated Import from ./core/pagination instead */
export * from './core/pagination';
