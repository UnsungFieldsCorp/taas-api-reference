// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import { APIResource } from '../../core/resource';
import { APIPromise } from '../../core/api-promise';
import { RequestOptions } from '../../internal/request-options';

export class Models extends APIResource {
  /**
   * Returns a list of models available for fine-tuning.
   */
  list(
    query: ModelListParams | null | undefined = {},
    options?: RequestOptions,
  ): APIPromise<ModelListResponse> {
    return this._client.get('/v1/finetune/models/supported', { query, ...options });
  }
}

export interface ModelListResponse {
  models: Array<ModelListResponse.Model>;
}

export namespace ModelListResponse {
  /**
   * Response for a single fine-tuning model.
   */
  export interface Model {
    default_gpu_count: number;

    default_gpu_type: string;

    family: string;

    max_lora_rank: number;

    max_seq_len: number;

    name: string;

    parameters_billion: number;
  }
}

export interface ModelListParams {
  family?: string;
}

export declare namespace Models {
  export { type ModelListResponse as ModelListResponse, type ModelListParams as ModelListParams };
}
