// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import { APIResource } from '../core/resource';
import { APIPromise } from '../core/api-promise';
import { RequestOptions } from '../internal/request-options';
import { path } from '../internal/utils/path';

export class Hardware extends APIResource {
  /**
   * Retrieve details for a specific hardware configuration by its ID.
   */
  retrieve(id: string, options?: RequestOptions): APIPromise<PublicHardwareResponse> {
    return this._client.get(path`/v1/hardware/${id}`, options);
  }

  /**
   * List available GPU hardware configurations. Optionally filter by model
   * compatibility.
   */
  list(
    query: HardwareListParams | null | undefined = {},
    options?: RequestOptions,
  ): APIPromise<HardwareListResponse> {
    return this._client.get('/v1/hardware', { query, ...options });
  }
}

/**
 * Pricing for a hardware configuration.
 */
export interface HardwarePricing {
  /**
   * Cost per minute in cents.
   */
  cents_per_minute: number;
}

/**
 * GPU hardware specifications.
 */
export interface HardwareSpecs {
  /**
   * Number of GPUs (1, 2, 4, or 8).
   */
  gpu_count: 1 | 2 | 4 | 8;

  /**
   * Interconnect type: sxm or pcie.
   */
  gpu_link: 'sxm' | 'pcie';

  /**
   * GPU VRAM in GB.
   */
  gpu_memory: number;

  /**
   * GPU model identifier (e.g. h200-140gb).
   */
  gpu_type: string;
}

/**
 * Hardware configuration as returned by the public API.
 */
export interface PublicHardwareResponse {
  /**
   * Public identifier, format: {gpu*count}x_nvidia*{gpu*type}*{gpu_link}.
   */
  id: string;

  /**
   * Object type identifier.
   */
  object: string;

  /**
   * Pricing for a hardware configuration.
   */
  pricing: HardwarePricing;

  /**
   * GPU hardware specifications.
   */
  specs: HardwareSpecs;

  /**
   * Last modification timestamp.
   */
  updated_at: string;

  /**
   * Availability status for model-specific queries. Present only when model query
   * param is used.
   */
  availability?: { [key: string]: string } | null;
}

export type HardwareListResponse = Array<PublicHardwareResponse>;

export interface HardwareListParams {
  /**
   * Fine-tuned model name to filter compatible hardware. When provided, response
   * includes availability status.
   */
  model?: string | null;
}

export declare namespace Hardware {
  export {
    type HardwarePricing as HardwarePricing,
    type HardwareSpecs as HardwareSpecs,
    type PublicHardwareResponse as PublicHardwareResponse,
    type HardwareListResponse as HardwareListResponse,
    type HardwareListParams as HardwareListParams,
  };
}
