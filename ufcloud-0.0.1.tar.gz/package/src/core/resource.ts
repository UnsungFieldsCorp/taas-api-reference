// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import type { Ufcloud } from '../client';

export abstract class APIResource {
  protected _client: Ufcloud;

  constructor(client: Ufcloud) {
    this._client = client;
  }
}
