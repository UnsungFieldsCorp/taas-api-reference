"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("./internal/tslib.js");
tslib_1.__exportStar(require("./resources/index.js"), exports);
//# sourceMappingURL=resources.js.map