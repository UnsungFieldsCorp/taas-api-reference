"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalServerError = exports.RateLimitError = exports.UnprocessableEntityError = exports.ConflictError = exports.NotFoundError = exports.PermissionDeniedError = exports.AuthenticationError = exports.BadRequestError = exports.APIRateLimitError = exports.APINotFoundError = exports.APIAuthError = exports.APISystemError = exports.APIUserError = exports.APIValidationError = exports.APIMappingError = exports.APIConnectionTimeoutError = exports.APIConnectionError = exports.APIUserAbortError = exports.APIError = exports.UfcloudError = void 0;
const errors_1 = require("../internal/errors.js");
class UfcloudError extends Error {
}
exports.UfcloudError = UfcloudError;
class APIError extends UfcloudError {
    constructor(status, error, message, headers) {
        super(`${APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.error = error;
    }
    static makeMessage(status, error, message) {
        // 1. If we already have a parsed message from the error envelope, use it directly (no status prefix).
        if (message) {
            return message;
        }
        // 2. Otherwise, fall back to error.message or serialized error.
        const fallback = error?.message ?
            typeof error.message === 'string' ?
                error.message
                : JSON.stringify(error.message)
            : error ? JSON.stringify(error)
                : undefined;
        // 3. If we have both status and some fallback text, keep old "status + text" behaviour.
        if (status && fallback) {
            return `${status} ${fallback}`;
        }
        if (status) {
            return `${status} status code (no body)`;
        }
        if (fallback) {
            return fallback;
        }
        return '(no status code or body)';
    }
    static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
            return new APIConnectionError({ message, cause: (0, errors_1.castToError)(errorResponse) });
        }
        const error = errorResponse;
        // if (status === 400) {
        //   return new BadRequestError(status, error, message, headers);
        // }
        // if (status === 401) {
        //   return new AuthenticationError(status, error, message, headers);
        // }
        // if (status === 403) {
        //   return new PermissionDeniedError(status, error, message, headers);
        // }
        // if (status === 404) {
        //   return new NotFoundError(status, error, message, headers);
        // }
        // if (status === 409) {
        //   return new ConflictError(status, error, message, headers);
        // }
        // if (status === 422) {
        //   return new UnprocessableEntityError(status, error, message, headers);
        // }
        // if (status === 429) {
        //   return new RateLimitError(status, error, message, headers);
        // }
        // if (status >= 500) {
        //   return new InternalServerError(status, error, message, headers);
        // }
        // return new APIError(status, error, message, headers);
        // Extract error information from response body
        const errorInfo = extractErrorInfo(error, message, status);
        // Get the appropriate exception class based on error type
        const ExceptionClass = ERROR_TYPE_TO_CLASS[errorInfo.type] || APISystemError;
        return new ExceptionClass(errorInfo.type, errorInfo.code, errorInfo.message, errorInfo.details, status, error, headers);
    }
}
exports.APIError = APIError;
/**
 * Extract error information from response body.
 *
 * Returns error type, code, message, and details.
 */
function extractErrorInfo(body, errMsg, statusCode) {
    // Extract error information from body if available
    // Try to extract from standard format: {"error": {"type": ..., "code": ..., "message": ..., "details": ...}}
    let errorData = {};
    let fallbackMessage = null;
    if (body && typeof body === 'object' && !Array.isArray(body)) {
        const bodyDict = body;
        const errorObj = bodyDict['error'];
        if (errorObj && typeof errorObj === 'object' && !Array.isArray(errorObj)) {
            // Standard format: {"error": {...}}
            errorData = errorObj;
        }
        else {
            // Non-standard format: try to extract from common fields
            // Check for common error message fields: detail, message, error (as string)
            if ('detail' in bodyDict) {
                const detailValue = bodyDict['detail'];
                if (typeof detailValue === 'string') {
                    fallbackMessage = detailValue;
                }
                else {
                    // Convert list, dict, or other types to string representation
                    fallbackMessage = String(detailValue);
                }
            }
            else if ('message' in bodyDict && typeof bodyDict['message'] === 'string') {
                fallbackMessage = bodyDict['message'];
            }
            else if ('error' in bodyDict && typeof bodyDict['error'] === 'string') {
                fallbackMessage = bodyDict['error'];
            }
            else if (Object.keys(bodyDict).length > 0) {
                // If body has other fields, use the whole body as details
                fallbackMessage = JSON.stringify(bodyDict);
            }
        }
    }
    // Extract error type as string
    let errorTypeStr = errorData['type'];
    let errorType;
    if (errorTypeStr &&
        ['validation_error', 'user_error', 'system_error', 'auth_error', 'not_found', 'rate_limit'].includes(errorTypeStr)) {
        errorType = errorTypeStr;
    }
    else {
        errorType = 'unknown_error';
    }
    // Extract error code, message, and details
    // Safely convert code to string if it exists and is not already a string
    const codeValue = errorData['code'];
    const errorCode = codeValue != null ? String(codeValue) : null;
    const errorMessageRaw = errorData['message'];
    const errorDetails = errorData['details'] || null;
    // Use error message from standard format, fallback to extracted message, or use errMsg
    let errorMessage;
    if (errorMessageRaw && typeof errorMessageRaw === 'string' && errorMessageRaw) {
        errorMessage = errorMessageRaw;
    }
    else if (fallbackMessage) {
        errorMessage = fallbackMessage;
    }
    else {
        errorMessage = errMsg || 'Unknown error';
    }
    // Handle special status codes (401/403) - force auth_error type
    if (statusCode === 401 || statusCode === 403) {
        errorType = 'auth_error';
    }
    return {
        type: errorType,
        code: errorCode,
        message: errorMessage,
        details: errorDetails,
    };
}
class APIUserAbortError extends APIError {
    constructor({ message } = {}) {
        super(undefined, undefined, message || 'Request was aborted.', undefined);
    }
}
exports.APIUserAbortError = APIUserAbortError;
class APIConnectionError extends APIError {
    constructor({ message, cause }) {
        super(undefined, undefined, message || 'Connection error.', undefined);
        // in some environments the 'cause' property is already declared
        // @ts-ignore
        if (cause)
            this.cause = cause;
    }
}
exports.APIConnectionError = APIConnectionError;
class APIConnectionTimeoutError extends APIConnectionError {
    constructor({ message } = {}) {
        super({ message: message ?? 'Request timed out.' });
    }
}
exports.APIConnectionTimeoutError = APIConnectionTimeoutError;
/**
 * Base class for API mapping errors that contain error type, code, and details.
 */
class APIMappingError extends APIError {
    constructor(type, code, message, details, status, error, headers) {
        super(status, error, message, headers);
        this.type = type;
        this.code = code;
        this.details = details;
    }
}
exports.APIMappingError = APIMappingError;
class APIValidationError extends APIMappingError {
}
exports.APIValidationError = APIValidationError;
class APIUserError extends APIMappingError {
}
exports.APIUserError = APIUserError;
class APISystemError extends APIMappingError {
}
exports.APISystemError = APISystemError;
class APIAuthError extends APIMappingError {
}
exports.APIAuthError = APIAuthError;
class APINotFoundError extends APIMappingError {
}
exports.APINotFoundError = APINotFoundError;
class APIRateLimitError extends APIMappingError {
}
exports.APIRateLimitError = APIRateLimitError;
/**
 * Map error types to exception classes
 */
const ERROR_TYPE_TO_CLASS = {
    validation_error: APIValidationError,
    user_error: APIUserError,
    system_error: APISystemError,
    auth_error: APIAuthError,
    not_found: APINotFoundError,
    rate_limit: APIRateLimitError,
    unknown_error: APISystemError,
};
class BadRequestError extends APIError {
}
exports.BadRequestError = BadRequestError;
class AuthenticationError extends APIError {
}
exports.AuthenticationError = AuthenticationError;
class PermissionDeniedError extends APIError {
}
exports.PermissionDeniedError = PermissionDeniedError;
class NotFoundError extends APIError {
}
exports.NotFoundError = NotFoundError;
class ConflictError extends APIError {
}
exports.ConflictError = ConflictError;
class UnprocessableEntityError extends APIError {
}
exports.UnprocessableEntityError = UnprocessableEntityError;
class RateLimitError extends APIError {
}
exports.RateLimitError = RateLimitError;
class InternalServerError extends APIError {
}
exports.InternalServerError = InternalServerError;
//# sourceMappingURL=error.js.map