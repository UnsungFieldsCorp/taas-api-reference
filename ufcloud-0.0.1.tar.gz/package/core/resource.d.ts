import type { Ufcloud } from "../client.js";
export declare abstract class APIResource {
    protected _client: Ufcloud;
    constructor(client: Ufcloud);
}
//# sourceMappingURL=resource.d.ts.map