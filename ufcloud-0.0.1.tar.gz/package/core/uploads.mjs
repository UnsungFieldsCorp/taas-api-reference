export { toFile } from "../internal/to-file.mjs";
//# sourceMappingURL=uploads.mjs.map