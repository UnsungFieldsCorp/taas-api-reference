# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Mapping, cast
from typing_extensions import Self, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import is_given, get_async_library
from ._compat import cached_property
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import UfcloudError, APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import chat, files, models, rerank, batches, responses, embeddings, fine_tuning
    from .resources.files import FilesResource, AsyncFilesResource
    from .resources.models import ModelsResource, AsyncModelsResource
    from .resources.rerank import RerankResource, AsyncRerankResource
    from .resources.batches import BatchesResource, AsyncBatchesResource
    from .resources.chat.chat import ChatResource, AsyncChatResource
    from .resources.responses import ResponsesResource, AsyncResponsesResource
    from .resources.embeddings import EmbeddingsResource, AsyncEmbeddingsResource
    from .resources.fine_tuning.fine_tuning import FineTuningResource, AsyncFineTuningResource

__all__ = ["Timeout", "Transport", "ProxiesTypes", "RequestOptions", "Ufcloud", "AsyncUfcloud", "Client", "AsyncClient"]


# Map error types to exception classes
_ERROR_TYPE_TO_CLASS: dict[str, type[_exceptions.APIMappingError]] = {
    "validation_error": _exceptions.APIValidationError,
    "user_error": _exceptions.APIUserError,
    "system_error": _exceptions.APISystemError,
    "auth_error": _exceptions.APIAuthError,
    "not_found": _exceptions.APINotFoundError,
    "rate_limit": _exceptions.APIRateLimitError,
}


def _extract_error_info(
    body: object,
    err_msg: str,
    response: httpx.Response,
) -> tuple[str, str | None, str, object | None, object]:
    """
    Extract error information from response body.

    Returns:
        Tuple of (error_type, error_code, error_message, error_details, body_param)
    """
    # Extract error information from body if available
    # Try to extract from standard format: {"error": {"type": ..., "code": ..., "message": ..., "details": ...}}
    error_data: dict[str, Any] = {}
    fallback_message: str | None = None

    if isinstance(body, dict):
        body_dict = cast(dict[str, Any], body)
        error_obj = body_dict.get("error")

        if isinstance(error_obj, dict):
            # Standard format: {"error": {...}}
            error_data = cast(dict[str, Any], error_obj)
        else:
            # Non-standard format: try to extract from common fields
            # Check for common error message fields: detail, message, error (as string)
            if "detail" in body_dict:
                detail_value: Any = body_dict["detail"]
                if isinstance(detail_value, str):
                    fallback_message = detail_value
                else:
                    # Convert list, dict, or other types to string representation
                    fallback_message = str(detail_value)
            elif "message" in body_dict and isinstance(body_dict["message"], str):
                fallback_message = body_dict["message"]
            elif "error" in body_dict and isinstance(body_dict["error"], str):
                fallback_message = body_dict["error"]
            elif body_dict:
                # If body has other fields, use the whole body as details
                fallback_message = str(body_dict)

    # Explicitly cast body to object to avoid type checker warnings
    # The cast is safe because body is already typed as object in the function signature
    body_param = cast(object, body)

    # Extract error type as string
    error_type_str: str | None = error_data.get("type")
    if error_type_str in ("validation_error", "user_error", "system_error", "auth_error", "not_found", "rate_limit"):
        error_type = error_type_str
    else:
        error_type = "unknown_error"

    # Extract error code, message, and details
    # Safely convert code to string if it exists and is not already a string
    code_value = error_data.get("code")
    if code_value is not None:
        error_code: str | None = str(code_value) if not isinstance(code_value, str) else code_value
    else:
        error_code = None

    error_message_raw: str | None = error_data.get("message")
    error_details: object | None = error_data.get("details")

    # Use error message from standard format, fallback to extracted message, or use err_msg
    if isinstance(error_message_raw, str) and error_message_raw:
        error_message: str = error_message_raw
    elif fallback_message:
        error_message = fallback_message
    else:
        error_message = err_msg

    # Handle special status codes (401/403) - force auth_error type
    if response.status_code in (401, 403):
        error_type = "auth_error"

    return error_type, error_code, error_message, error_details, body_param


class Ufcloud(SyncAPIClient):
    # client options
    api_key: str

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Ufcloud client instance.

        This automatically infers the `api_key` argument from the `UFCLOUD_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("UFCLOUD_API_KEY")
        if api_key is None:
            raise UfcloudError(
                "The api_key client option must be set either by passing api_key to the client or by setting the UFCLOUD_API_KEY environment variable"
            )
        self.api_key = api_key

        if base_url is None:
            base_url = os.environ.get("UFCLOUD_BASE_URL")
        if base_url is None:
            base_url = f"https://api.ufcloud.ai"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def chat(self) -> ChatResource:
        from .resources.chat import ChatResource

        return ChatResource(self)

    @cached_property
    def embeddings(self) -> EmbeddingsResource:
        from .resources.embeddings import EmbeddingsResource

        return EmbeddingsResource(self)

    @cached_property
    def rerank(self) -> RerankResource:
        from .resources.rerank import RerankResource

        return RerankResource(self)

    @cached_property
    def files(self) -> FilesResource:
        from .resources.files import FilesResource

        return FilesResource(self)

    @cached_property
    def fine_tuning(self) -> FineTuningResource:
        from .resources.fine_tuning import FineTuningResource

        return FineTuningResource(self)

    @cached_property
    def responses(self) -> ResponsesResource:
        from .resources.responses import ResponsesResource

        return ResponsesResource(self)

    @cached_property
    def models(self) -> ModelsResource:
        from .resources.models import ModelsResource

        return ModelsResource(self)

    @cached_property
    def batches(self) -> BatchesResource:
        from .resources.batches import BatchesResource

        return BatchesResource(self)

    @cached_property
    def with_raw_response(self) -> UfcloudWithRawResponse:
        return UfcloudWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> UfcloudWithStreamedResponse:
        return UfcloudWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        if not api_key or not api_key.strip():
            return {}
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        # if response.status_code == 400:
        #     return _exceptions.BadRequestError(err_msg, response=response, body=body)

        # if response.status_code == 401:
        #     return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        # if response.status_code == 403:
        #     return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        # if response.status_code == 404:
        #     return _exceptions.NotFoundError(err_msg, response=response, body=body)

        # if response.status_code == 409:
        #     return _exceptions.ConflictError(err_msg, response=response, body=body)

        # if response.status_code == 422:
        #     return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        # if response.status_code == 429:
        #     return _exceptions.RateLimitError(err_msg, response=response, body=body)

        # if response.status_code >= 500:
        #     return _exceptions.InternalServerError(err_msg, response=response, body=body)
        # return APIStatusError(err_msg, response=response, body=body)

        error_type, error_code, error_message, error_details, body_param = _extract_error_info(body, err_msg, response)

        # Get the appropriate exception class, default to APISystemError
        exception_class = _ERROR_TYPE_TO_CLASS.get(error_type, _exceptions.APISystemError)

        return exception_class(error_type, error_code, error_message, error_details, response=response, body=body_param)


class AsyncUfcloud(AsyncAPIClient):
    # client options
    api_key: str

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncUfcloud client instance.

        This automatically infers the `api_key` argument from the `UFCLOUD_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("UFCLOUD_API_KEY")
        if api_key is None:
            raise UfcloudError(
                "The api_key client option must be set either by passing api_key to the client or by setting the UFCLOUD_API_KEY environment variable"
            )
        self.api_key = api_key

        if base_url is None:
            base_url = os.environ.get("UFCLOUD_BASE_URL")
        if base_url is None:
            base_url = f"https://api.ufcloud.ai"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def chat(self) -> AsyncChatResource:
        from .resources.chat import AsyncChatResource

        return AsyncChatResource(self)

    @cached_property
    def embeddings(self) -> AsyncEmbeddingsResource:
        from .resources.embeddings import AsyncEmbeddingsResource

        return AsyncEmbeddingsResource(self)

    @cached_property
    def rerank(self) -> AsyncRerankResource:
        from .resources.rerank import AsyncRerankResource

        return AsyncRerankResource(self)

    @cached_property
    def files(self) -> AsyncFilesResource:
        from .resources.files import AsyncFilesResource

        return AsyncFilesResource(self)

    @cached_property
    def fine_tuning(self) -> AsyncFineTuningResource:
        from .resources.fine_tuning import AsyncFineTuningResource

        return AsyncFineTuningResource(self)

    @cached_property
    def responses(self) -> AsyncResponsesResource:
        from .resources.responses import AsyncResponsesResource

        return AsyncResponsesResource(self)

    @cached_property
    def models(self) -> AsyncModelsResource:
        from .resources.models import AsyncModelsResource

        return AsyncModelsResource(self)

    @cached_property
    def batches(self) -> AsyncBatchesResource:
        from .resources.batches import AsyncBatchesResource

        return AsyncBatchesResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncUfcloudWithRawResponse:
        return AsyncUfcloudWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncUfcloudWithStreamedResponse:
        return AsyncUfcloudWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        if not api_key or not api_key.strip():
            return {}
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        # if response.status_code == 400:
        #     return _exceptions.BadRequestError(err_msg, response=response, body=body)

        # if response.status_code == 401:
        #     return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        # if response.status_code == 403:
        #     return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        # if response.status_code == 404:
        #     return _exceptions.NotFoundError(err_msg, response=response, body=body)

        # if response.status_code == 409:
        #     return _exceptions.ConflictError(err_msg, response=response, body=body)

        # if response.status_code == 422:
        #     return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        # if response.status_code == 429:
        #     return _exceptions.RateLimitError(err_msg, response=response, body=body)

        # if response.status_code >= 500:
        #     return _exceptions.InternalServerError(err_msg, response=response, body=body)
        # return APIStatusError(err_msg, response=response, body=body)

        error_type, error_code, error_message, error_details, body_param = _extract_error_info(body, err_msg, response)

        # Get the appropriate exception class, default to APISystemError
        exception_class = _ERROR_TYPE_TO_CLASS.get(error_type, _exceptions.APISystemError)

        return exception_class(error_type, error_code, error_message, error_details, response=response, body=body_param)


class UfcloudWithRawResponse:
    _client: Ufcloud

    def __init__(self, client: Ufcloud) -> None:
        self._client = client

    @cached_property
    def chat(self) -> chat.ChatResourceWithRawResponse:
        from .resources.chat import ChatResourceWithRawResponse

        return ChatResourceWithRawResponse(self._client.chat)

    @cached_property
    def embeddings(self) -> embeddings.EmbeddingsResourceWithRawResponse:
        from .resources.embeddings import EmbeddingsResourceWithRawResponse

        return EmbeddingsResourceWithRawResponse(self._client.embeddings)

    @cached_property
    def rerank(self) -> rerank.RerankResourceWithRawResponse:
        from .resources.rerank import RerankResourceWithRawResponse

        return RerankResourceWithRawResponse(self._client.rerank)

    @cached_property
    def files(self) -> files.FilesResourceWithRawResponse:
        from .resources.files import FilesResourceWithRawResponse

        return FilesResourceWithRawResponse(self._client.files)

    @cached_property
    def fine_tuning(self) -> fine_tuning.FineTuningResourceWithRawResponse:
        from .resources.fine_tuning import FineTuningResourceWithRawResponse

        return FineTuningResourceWithRawResponse(self._client.fine_tuning)

    @cached_property
    def responses(self) -> responses.ResponsesResourceWithRawResponse:
        from .resources.responses import ResponsesResourceWithRawResponse

        return ResponsesResourceWithRawResponse(self._client.responses)

    @cached_property
    def models(self) -> models.ModelsResourceWithRawResponse:
        from .resources.models import ModelsResourceWithRawResponse

        return ModelsResourceWithRawResponse(self._client.models)

    @cached_property
    def batches(self) -> batches.BatchesResourceWithRawResponse:
        from .resources.batches import BatchesResourceWithRawResponse

        return BatchesResourceWithRawResponse(self._client.batches)


class AsyncUfcloudWithRawResponse:
    _client: AsyncUfcloud

    def __init__(self, client: AsyncUfcloud) -> None:
        self._client = client

    @cached_property
    def chat(self) -> chat.AsyncChatResourceWithRawResponse:
        from .resources.chat import AsyncChatResourceWithRawResponse

        return AsyncChatResourceWithRawResponse(self._client.chat)

    @cached_property
    def embeddings(self) -> embeddings.AsyncEmbeddingsResourceWithRawResponse:
        from .resources.embeddings import AsyncEmbeddingsResourceWithRawResponse

        return AsyncEmbeddingsResourceWithRawResponse(self._client.embeddings)

    @cached_property
    def rerank(self) -> rerank.AsyncRerankResourceWithRawResponse:
        from .resources.rerank import AsyncRerankResourceWithRawResponse

        return AsyncRerankResourceWithRawResponse(self._client.rerank)

    @cached_property
    def files(self) -> files.AsyncFilesResourceWithRawResponse:
        from .resources.files import AsyncFilesResourceWithRawResponse

        return AsyncFilesResourceWithRawResponse(self._client.files)

    @cached_property
    def fine_tuning(self) -> fine_tuning.AsyncFineTuningResourceWithRawResponse:
        from .resources.fine_tuning import AsyncFineTuningResourceWithRawResponse

        return AsyncFineTuningResourceWithRawResponse(self._client.fine_tuning)

    @cached_property
    def responses(self) -> responses.AsyncResponsesResourceWithRawResponse:
        from .resources.responses import AsyncResponsesResourceWithRawResponse

        return AsyncResponsesResourceWithRawResponse(self._client.responses)

    @cached_property
    def models(self) -> models.AsyncModelsResourceWithRawResponse:
        from .resources.models import AsyncModelsResourceWithRawResponse

        return AsyncModelsResourceWithRawResponse(self._client.models)

    @cached_property
    def batches(self) -> batches.AsyncBatchesResourceWithRawResponse:
        from .resources.batches import AsyncBatchesResourceWithRawResponse

        return AsyncBatchesResourceWithRawResponse(self._client.batches)


class UfcloudWithStreamedResponse:
    _client: Ufcloud

    def __init__(self, client: Ufcloud) -> None:
        self._client = client

    @cached_property
    def chat(self) -> chat.ChatResourceWithStreamingResponse:
        from .resources.chat import ChatResourceWithStreamingResponse

        return ChatResourceWithStreamingResponse(self._client.chat)

    @cached_property
    def embeddings(self) -> embeddings.EmbeddingsResourceWithStreamingResponse:
        from .resources.embeddings import EmbeddingsResourceWithStreamingResponse

        return EmbeddingsResourceWithStreamingResponse(self._client.embeddings)

    @cached_property
    def rerank(self) -> rerank.RerankResourceWithStreamingResponse:
        from .resources.rerank import RerankResourceWithStreamingResponse

        return RerankResourceWithStreamingResponse(self._client.rerank)

    @cached_property
    def files(self) -> files.FilesResourceWithStreamingResponse:
        from .resources.files import FilesResourceWithStreamingResponse

        return FilesResourceWithStreamingResponse(self._client.files)

    @cached_property
    def fine_tuning(self) -> fine_tuning.FineTuningResourceWithStreamingResponse:
        from .resources.fine_tuning import FineTuningResourceWithStreamingResponse

        return FineTuningResourceWithStreamingResponse(self._client.fine_tuning)

    @cached_property
    def responses(self) -> responses.ResponsesResourceWithStreamingResponse:
        from .resources.responses import ResponsesResourceWithStreamingResponse

        return ResponsesResourceWithStreamingResponse(self._client.responses)

    @cached_property
    def models(self) -> models.ModelsResourceWithStreamingResponse:
        from .resources.models import ModelsResourceWithStreamingResponse

        return ModelsResourceWithStreamingResponse(self._client.models)

    @cached_property
    def batches(self) -> batches.BatchesResourceWithStreamingResponse:
        from .resources.batches import BatchesResourceWithStreamingResponse

        return BatchesResourceWithStreamingResponse(self._client.batches)


class AsyncUfcloudWithStreamedResponse:
    _client: AsyncUfcloud

    def __init__(self, client: AsyncUfcloud) -> None:
        self._client = client

    @cached_property
    def chat(self) -> chat.AsyncChatResourceWithStreamingResponse:
        from .resources.chat import AsyncChatResourceWithStreamingResponse

        return AsyncChatResourceWithStreamingResponse(self._client.chat)

    @cached_property
    def embeddings(self) -> embeddings.AsyncEmbeddingsResourceWithStreamingResponse:
        from .resources.embeddings import AsyncEmbeddingsResourceWithStreamingResponse

        return AsyncEmbeddingsResourceWithStreamingResponse(self._client.embeddings)

    @cached_property
    def rerank(self) -> rerank.AsyncRerankResourceWithStreamingResponse:
        from .resources.rerank import AsyncRerankResourceWithStreamingResponse

        return AsyncRerankResourceWithStreamingResponse(self._client.rerank)

    @cached_property
    def files(self) -> files.AsyncFilesResourceWithStreamingResponse:
        from .resources.files import AsyncFilesResourceWithStreamingResponse

        return AsyncFilesResourceWithStreamingResponse(self._client.files)

    @cached_property
    def fine_tuning(self) -> fine_tuning.AsyncFineTuningResourceWithStreamingResponse:
        from .resources.fine_tuning import AsyncFineTuningResourceWithStreamingResponse

        return AsyncFineTuningResourceWithStreamingResponse(self._client.fine_tuning)

    @cached_property
    def responses(self) -> responses.AsyncResponsesResourceWithStreamingResponse:
        from .resources.responses import AsyncResponsesResourceWithStreamingResponse

        return AsyncResponsesResourceWithStreamingResponse(self._client.responses)

    @cached_property
    def models(self) -> models.AsyncModelsResourceWithStreamingResponse:
        from .resources.models import AsyncModelsResourceWithStreamingResponse

        return AsyncModelsResourceWithStreamingResponse(self._client.models)

    @cached_property
    def batches(self) -> batches.AsyncBatchesResourceWithStreamingResponse:
        from .resources.batches import AsyncBatchesResourceWithStreamingResponse

        return AsyncBatchesResourceWithStreamingResponse(self._client.batches)


Client = Ufcloud

AsyncClient = AsyncUfcloud
