# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import json
import uuid
from typing import Any, Optional, cast
from pathlib import Path
from typing_extensions import Literal

import httpx

from .models import (
    ModelsResource,
    AsyncModelsResource,
    ModelsResourceWithRawResponse,
    AsyncModelsResourceWithRawResponse,
    ModelsResourceWithStreamingResponse,
    AsyncModelsResourceWithStreamingResponse,
)
from ...types import fine_tuning_list_params, fine_tuning_create_params
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, strip_not_given, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    BaseAPIResponse,
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    to_custom_raw_response_wrapper,
    async_to_streamed_response_wrapper,
    to_custom_streamed_response_wrapper,
    async_to_custom_raw_response_wrapper,
    async_to_custom_streamed_response_wrapper,
)
from ...pagination import SyncOffsetPagination, AsyncOffsetPagination
from ..._exceptions import UfcloudError
from ..._base_client import AsyncPaginator, make_request_options
from ...types.fine_tuning_list_response import FineTuningListResponse
from ...types.fine_tuning_create_response import FineTuningCreateResponse
from ...types.fine_tuning_retrieve_response import FineTuningRetrieveResponse

__all__ = ["FineTuningResource", "AsyncFineTuningResource"]


class FineTuningResource(SyncAPIResource):
    @cached_property
    def models(self) -> ModelsResource:
        return ModelsResource(self._client)

    @cached_property
    def with_raw_response(self) -> FineTuningResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#accessing-raw-response-data-eg-headers
        """
        return FineTuningResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FineTuningResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#with_streaming_response
        """
        return FineTuningResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        model: str,
        training_file_id: str,
        hyperparams: fine_tuning_create_params.Hyperparams | Omit = omit,
        org_id: Optional[str] | Omit = omit,
        status: Optional[Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"]] | Omit = omit,
        suffix: Optional[str] | Omit = omit,
        type: Optional[str] | Omit = omit,
        validation_file_id: Optional[str] | Omit = omit,
        idempotency_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FineTuningCreateResponse:
        """
        Create a new Fine-Tuning Job.

        Args:
          hyperparams: Schema for the hyperparameters of a fine-tuning job.

          status: Enum for the status of a fine-tuning job.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        # Generate UUID v4 if idempotency_key is not provided
        if isinstance(idempotency_key, Omit):
            idempotency_key = str(uuid.uuid4())
        extra_headers = {**strip_not_given({"Idempotency-Key": idempotency_key}), **(extra_headers or {})}
        return self._post(
            "/v1/fine-tuning/jobs",
            body=maybe_transform(
                {
                    "model": model,
                    "training_file_id": training_file_id,
                    "hyperparams": hyperparams,
                    "org_id": org_id,
                    "status": status,
                    "suffix": suffix,
                    "type": type,
                    "validation_file_id": validation_file_id,
                },
                fine_tuning_create_params.FineTuningCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FineTuningCreateResponse,
        )

    def retrieve(
        self,
        job_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FineTuningRetrieveResponse:
        """
        Get details for a specific Fine-Tuning Job including associated events and
        artifacts.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not job_id:
            raise ValueError(f"Expected a non-empty value for `job_id` but received {job_id!r}")
        return self._get(
            f"/v1/fine-tuning/jobs/{job_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FineTuningRetrieveResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        model: str | Omit = omit,
        page: int | Omit = omit,
        status: Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncOffsetPagination[FineTuningListResponse]:
        """
        List all Fine-Tuning Jobs for the organization.

        Args:
          limit: Items per page, max 100

          model: Filter by model name

          page: Page number, 1-based

          status: Filter by job status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v1/fine-tuning/jobs",
            page=SyncOffsetPagination[FineTuningListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "model": model,
                        "page": page,
                        "status": status,
                    },
                    fine_tuning_list_params.FineTuningListParams,
                ),
            ),
            model=FineTuningListResponse,
        )

    def download_adapter(
        self,
        job_id: str,
        *,
        output_path: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BinaryAPIResponse:
        """
        Download the final adapter artifact for a specific Fine-Tuning Job.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not job_id:
            raise ValueError(f"Expected a non-empty value for `job_id` but received {job_id!r}")
        if not output_path:
            raise ValueError(f"Expected a non-empty value for `output_path` but received {output_path!r}")

        try:
            output_path_obj = Path(output_path).expanduser().resolve()
        except (OSError, ValueError) as e:
            raise ValueError(f"Invalid output path: {output_path!r} - {e}") from e

        output_dir = output_path_obj.parent
        if output_dir and not output_dir.exists():
            try:
                output_dir.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                raise ValueError(f"Cannot create output directory: {output_dir} - {e}") from e

        adapter_response_raw = self._get(
            f"/v1/fine-tuning/jobs/{job_id}/artifacts",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )
        # Handle raw/streaming responses
        adapter_response: dict[str, Any]
        if isinstance(adapter_response_raw, BaseAPIResponse):
            # For raw/streaming responses, get JSON from http_response
            # For streaming responses, need to read first
            try:
                adapter_response = adapter_response_raw.http_response.json()
            except httpx.ResponseNotRead:
                adapter_response_raw.http_response.read()
                adapter_response = adapter_response_raw.http_response.json()
        elif isinstance(adapter_response_raw, bytes):
            adapter_response = json.loads(adapter_response_raw.decode("utf-8"))
        else:
            adapter_response = cast(dict[str, Any], adapter_response_raw)
        final_adapter = adapter_response.get("final_adapter")
        if not isinstance(final_adapter, dict):
            raise UfcloudError("Invalid `final_adapter` in artifacts response")

        final_adapter_dict = cast(dict[str, Any], final_adapter)
        download_url = final_adapter_dict.get("download_url")
        if not isinstance(download_url, str) or not download_url:
            raise UfcloudError("No `final_adapter.download_url` returned for this job")

        # For presigned URLs (external URLs), we need to remove the Authorization header
        # Presigned URLs already contain authentication in query parameters
        # Use omit to remove the default Authorization header that would be added by self._get()
        response = self._get(
            download_url,
            options=make_request_options(
                extra_headers={"Accept": "application/octet-stream", "Authorization": omit},
                extra_query=None,
                extra_body=None,
                timeout=timeout,
            ),
            cast_to=BinaryAPIResponse,
        )
        response.write_to_file(output_path_obj)
        return response


class AsyncFineTuningResource(AsyncAPIResource):
    @cached_property
    def models(self) -> AsyncModelsResource:
        return AsyncModelsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncFineTuningResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#accessing-raw-response-data-eg-headers
        """
        return AsyncFineTuningResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFineTuningResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#with_streaming_response
        """
        return AsyncFineTuningResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        model: str,
        training_file_id: str,
        hyperparams: fine_tuning_create_params.Hyperparams | Omit = omit,
        org_id: Optional[str] | Omit = omit,
        status: Optional[Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"]] | Omit = omit,
        suffix: Optional[str] | Omit = omit,
        type: Optional[str] | Omit = omit,
        validation_file_id: Optional[str] | Omit = omit,
        idempotency_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FineTuningCreateResponse:
        """
        Create a new Fine-Tuning Job.

        Args:
          hyperparams: Schema for the hyperparameters of a fine-tuning job.

          status: Enum for the status of a fine-tuning job.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        # Generate UUID v4 if idempotency_key is not provided
        if isinstance(idempotency_key, Omit):
            idempotency_key = str(uuid.uuid4())
        extra_headers = {**strip_not_given({"Idempotency-Key": idempotency_key}), **(extra_headers or {})}
        return await self._post(
            "/v1/fine-tuning/jobs",
            body=await async_maybe_transform(
                {
                    "model": model,
                    "training_file_id": training_file_id,
                    "hyperparams": hyperparams,
                    "org_id": org_id,
                    "status": status,
                    "suffix": suffix,
                    "type": type,
                    "validation_file_id": validation_file_id,
                },
                fine_tuning_create_params.FineTuningCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FineTuningCreateResponse,
        )

    async def retrieve(
        self,
        job_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FineTuningRetrieveResponse:
        """
        Get details for a specific Fine-Tuning Job including associated events and
        artifacts.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not job_id:
            raise ValueError(f"Expected a non-empty value for `job_id` but received {job_id!r}")
        return await self._get(
            f"/v1/fine-tuning/jobs/{job_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FineTuningRetrieveResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        model: str | Omit = omit,
        page: int | Omit = omit,
        status: Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[FineTuningListResponse, AsyncOffsetPagination[FineTuningListResponse]]:
        """
        List all Fine-Tuning Jobs for the organization.

        Args:
          limit: Items per page, max 100

          model: Filter by model name

          page: Page number, 1-based

          status: Filter by job status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/v1/fine-tuning/jobs",
            page=AsyncOffsetPagination[FineTuningListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "model": model,
                        "page": page,
                        "status": status,
                    },
                    fine_tuning_list_params.FineTuningListParams,
                ),
            ),
            model=FineTuningListResponse,
        )

    async def download_adapter(
        self,
        job_id: str,
        *,
        output_path: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncBinaryAPIResponse:
        """
        Download the final adapter artifact for a specific Fine-Tuning Job.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not job_id:
            raise ValueError(f"Expected a non-empty value for `job_id` but received {job_id!r}")
        if not output_path:
            raise ValueError(f"Expected a non-empty value for `output_path` but received {output_path!r}")

        try:
            output_path_obj = Path(output_path).expanduser().resolve()
        except (OSError, ValueError) as e:
            raise ValueError(f"Invalid output path: {output_path!r} - {e}") from e

        output_dir = output_path_obj.parent
        if output_dir and not output_dir.exists():
            try:
                output_dir.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                raise ValueError(f"Cannot create output directory: {output_dir} - {e}") from e

        adapter_response_raw = await self._get(
            f"/v1/fine-tuning/jobs/{job_id}/artifacts",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )
        # Handle raw/streaming responses
        adapter_response: dict[str, Any]
        if isinstance(adapter_response_raw, BaseAPIResponse):
            # For raw/streaming responses, get JSON from http_response
            # For streaming responses, need to read first
            try:
                adapter_response = adapter_response_raw.http_response.json()
            except httpx.ResponseNotRead:
                await adapter_response_raw.http_response.aread()
                adapter_response = adapter_response_raw.http_response.json()
        elif isinstance(adapter_response_raw, bytes):
            adapter_response = json.loads(adapter_response_raw.decode("utf-8"))
        else:
            adapter_response = cast(dict[str, Any], adapter_response_raw)
        final_adapter = adapter_response.get("final_adapter")
        if not isinstance(final_adapter, dict):
            raise UfcloudError("Invalid `final_adapter` in artifacts response")

        final_adapter_dict = cast(dict[str, Any], final_adapter)
        download_url = final_adapter_dict.get("download_url")
        if not isinstance(download_url, str) or not download_url:
            raise UfcloudError("No `final_adapter.download_url` returned for this job")

        response = await self._get(
            download_url,
            options=make_request_options(
                extra_headers={"Accept": "application/octet-stream", "Authorization": omit},
                extra_query=None,
                extra_body=None,
                timeout=timeout,
            ),
            cast_to=AsyncBinaryAPIResponse,
        )
        await response.write_to_file(output_path_obj)
        return response


class FineTuningResourceWithRawResponse:
    def __init__(self, fine_tuning: FineTuningResource) -> None:
        self._fine_tuning = fine_tuning

        self.create = to_raw_response_wrapper(
            fine_tuning.create,
        )
        self.retrieve = to_raw_response_wrapper(
            fine_tuning.retrieve,
        )
        self.list = to_raw_response_wrapper(
            fine_tuning.list,
        )
        self.download_adapter = to_custom_raw_response_wrapper(
            fine_tuning.download_adapter,
            BinaryAPIResponse,
        )

    @cached_property
    def models(self) -> ModelsResourceWithRawResponse:
        return ModelsResourceWithRawResponse(self._fine_tuning.models)


class AsyncFineTuningResourceWithRawResponse:
    def __init__(self, fine_tuning: AsyncFineTuningResource) -> None:
        self._fine_tuning = fine_tuning

        self.create = async_to_raw_response_wrapper(
            fine_tuning.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            fine_tuning.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            fine_tuning.list,
        )
        self.download_adapter = async_to_custom_raw_response_wrapper(
            fine_tuning.download_adapter,
            AsyncBinaryAPIResponse,
        )

    @cached_property
    def models(self) -> AsyncModelsResourceWithRawResponse:
        return AsyncModelsResourceWithRawResponse(self._fine_tuning.models)


class FineTuningResourceWithStreamingResponse:
    def __init__(self, fine_tuning: FineTuningResource) -> None:
        self._fine_tuning = fine_tuning

        self.create = to_streamed_response_wrapper(
            fine_tuning.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            fine_tuning.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            fine_tuning.list,
        )
        self.download_adapter = to_custom_streamed_response_wrapper(
            fine_tuning.download_adapter,
            StreamedBinaryAPIResponse,
        )

    @cached_property
    def models(self) -> ModelsResourceWithStreamingResponse:
        return ModelsResourceWithStreamingResponse(self._fine_tuning.models)


class AsyncFineTuningResourceWithStreamingResponse:
    def __init__(self, fine_tuning: AsyncFineTuningResource) -> None:
        self._fine_tuning = fine_tuning

        self.create = async_to_streamed_response_wrapper(
            fine_tuning.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            fine_tuning.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            fine_tuning.list,
        )
        self.download_adapter = async_to_custom_streamed_response_wrapper(
            fine_tuning.download_adapter,
            AsyncStreamedBinaryAPIResponse,
        )

    @cached_property
    def models(self) -> AsyncModelsResourceWithStreamingResponse:
        return AsyncModelsResourceWithStreamingResponse(self._fine_tuning.models)
