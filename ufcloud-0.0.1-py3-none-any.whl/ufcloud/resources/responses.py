# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Union, Iterable
from typing_extensions import Literal, overload

import httpx

from ufcloud.types.response_stream_event import ResponseStreamEvent

from ..types import response_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._streaming import Stream, AsyncStream
from .._base_client import make_request_options
from ..types.response_create_response import ResponseCreateResponse

__all__ = ["ResponsesResource", "AsyncResponsesResource"]


class ResponsesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ResponsesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#accessing-raw-response-data-eg-headers
        """
        return ResponsesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ResponsesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#with_streaming_response
        """
        return ResponsesResourceWithStreamingResponse(self)

    @overload
    def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ResponseCreateResponse: ...

    @overload
    def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Stream[ResponseStreamEvent]: ...

    @overload
    def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ResponseCreateResponse | Stream[ResponseStreamEvent]: ...

    def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ResponseCreateResponse | Stream[ResponseStreamEvent]:
        """
        OpenAI-compatible responses endpoint.

        Args:
          input: Text, image, or file inputs to the model, used to generate a response.

          model: ID of the model to use.

          background: Whether to run the model response in the background.

          cache_salt: A salt value to add to the prompt cache key. This can be used to create a unique
              cache key for a request.

          include: Specify additional output data to include in the model response.

          instructions: A system (or developer) message inserted into the model's context.

          max_output_tokens: An upper bound for the number of tokens that can be generated for a response,
              including visible output tokens and reasoning tokens.

          max_tool_calls: The maximum number of total calls to built-in tools that can be processed in a
              response. This maximum number applies across all built-in tool calls, not per
              individual tool. Any further attempts to call a tool by the model will be
              ignored.

          metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
              for storing additional information about the object in a structured format, and
              querying for objects via API or the dashboard. Keys are strings with a maximum
              length of 64 characters. Values are strings with a maximum length of 512
              characters.

          mm_processor_kwargs: Additional kwargs to pass to the HF processor.

          parallel_tool_calls: Whether to allow the model to run tool calls in parallel.

          previous_response_id: The unique ID of the previous response to the model. Use this to create
              multi-turn conversations.

          priority: The priority of the request (lower means earlier handling; default: 0). Any
              priority other than 0 will raise an error if the served model does not use
              priority scheduling.

          prompt: Reference to a prompt template and its variables.

          reasoning: Configuration options for reasoning models.

          request_id: The request_id related to this request. If the caller does not set it, a
              random_uuid will be generated. This id is used through out the inference process
              and return in response.

          service_tier: Specifies the processing type used for serving the request.

          store: Whether to store the generated model response for later retrieval via API.

          stream: If set to true, the model response data will be streamed to the client as it is
              generated using server-sent events.

          temperature: What sampling temperature to use, between 0 and 2. Higher values like 0.8 will
              make the output more random, while lower values like 0.2 will make it more
              focused and deterministic. We generally recommend altering this or top_p but not
              both.

          text: Configuration options for a text response from the model. Can be plain text or
              structured JSON data.

          tool_choice: How the model should select which tool (or tools) to use when generating a
              response. See the tools parameter to see how to specify which tools the model
              can call.

          tools: An array of tools the model may call while generating a response. You can
              specify which tool to use by setting the tool_choice parameter.

          top_logprobs: An integer between 0 and 20 specifying the number of most likely tokens to
              return at each token position, each with an associated log probability.

          top_p: An alternative to sampling with temperature, called nucleus sampling, where the
              model considers the results of the tokens with top_p probability mass. So 0.1
              means only the tokens comprising the top 10% probability mass are considered.

          truncation: The truncation strategy to use for the model response.

          user: This field is being replaced by safety_identifier and prompt_cache_key. Use
              prompt_cache_key instead to maintain caching optimizations. A stable identifier
              for your end-users. Used to boost cache hit rates by better bucketing similar
              requests and to help OpenAI detect and prevent abuse.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/openai/v1/responses",
            body=maybe_transform(
                {
                    "input": input,
                    "model": model,
                    "background": background,
                    "cache_salt": cache_salt,
                    "include": include,
                    "instructions": instructions,
                    "max_output_tokens": max_output_tokens,
                    "max_tool_calls": max_tool_calls,
                    "metadata": metadata,
                    "mm_processor_kwargs": mm_processor_kwargs,
                    "parallel_tool_calls": parallel_tool_calls,
                    "previous_response_id": previous_response_id,
                    "priority": priority,
                    "prompt": prompt,
                    "reasoning": reasoning,
                    "request_id": request_id,
                    "service_tier": service_tier,
                    "store": store,
                    "stream": stream,
                    "temperature": temperature,
                    "text": text,
                    "tool_choice": tool_choice,
                    "tools": tools,
                    "top_logprobs": top_logprobs,
                    "top_p": top_p,
                    "truncation": truncation,
                    "user": user,
                },
                response_create_params.ResponseCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ResponseCreateResponse,
            stream=stream or False,
            stream_cls=Stream[ResponseStreamEvent],
        )


class AsyncResponsesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncResponsesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#accessing-raw-response-data-eg-headers
        """
        return AsyncResponsesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncResponsesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/stainless-sdks/ufcloud-python#with_streaming_response
        """
        return AsyncResponsesResourceWithStreamingResponse(self)

    @overload
    async def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ResponseCreateResponse: ...

    @overload
    async def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[ResponseStreamEvent]: ...

    @overload
    async def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ResponseCreateResponse | AsyncStream[ResponseStreamEvent]: ...

    async def create(
        self,
        *,
        input: Union[str, Iterable[response_create_params.InputInputItemList]],
        model: str,
        background: bool | Omit = omit,
        cache_salt: str | Omit = omit,
        include: List[
            Literal[
                "code_interpreter_call.outputs",
                "computer_call_output.output.image_url",
                "file_search_call.results",
                "message.input_image.image_url",
                "message.output_text.logprobs",
                "reasoning.encrypted_content",
            ]
        ]
        | Omit = omit,
        instructions: str | Omit = omit,
        max_output_tokens: int | Omit = omit,
        max_tool_calls: int | Omit = omit,
        metadata: Dict[str, object] | Omit = omit,
        mm_processor_kwargs: Dict[str, object] | Omit = omit,
        parallel_tool_calls: bool | Omit = omit,
        previous_response_id: str | Omit = omit,
        priority: int | Omit = omit,
        prompt: response_create_params.Prompt | Omit = omit,
        reasoning: response_create_params.Reasoning | Omit = omit,
        request_id: str | Omit = omit,
        service_tier: Literal["auto", "default", "flex", "scale", "priority"] | Omit = omit,
        store: bool | Omit = omit,
        stream: bool | Omit = omit,
        temperature: float | Omit = omit,
        text: response_create_params.Text | Omit = omit,
        tool_choice: response_create_params.ToolChoice | Omit = omit,
        tools: Iterable[response_create_params.Tool] | Omit = omit,
        top_logprobs: int | Omit = omit,
        top_p: float | Omit = omit,
        truncation: Literal["auto", "disabled"] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ResponseCreateResponse | AsyncStream[ResponseStreamEvent]:
        """
        OpenAI-compatible responses endpoint.

        Args:
          input: Text, image, or file inputs to the model, used to generate a response.

          model: ID of the model to use.

          background: Whether to run the model response in the background.

          cache_salt: A salt value to add to the prompt cache key. This can be used to create a unique
              cache key for a request.

          include: Specify additional output data to include in the model response.

          instructions: A system (or developer) message inserted into the model's context.

          max_output_tokens: An upper bound for the number of tokens that can be generated for a response,
              including visible output tokens and reasoning tokens.

          max_tool_calls: The maximum number of total calls to built-in tools that can be processed in a
              response. This maximum number applies across all built-in tool calls, not per
              individual tool. Any further attempts to call a tool by the model will be
              ignored.

          metadata: Set of 16 key-value pairs that can be attached to an object. This can be useful
              for storing additional information about the object in a structured format, and
              querying for objects via API or the dashboard. Keys are strings with a maximum
              length of 64 characters. Values are strings with a maximum length of 512
              characters.

          mm_processor_kwargs: Additional kwargs to pass to the HF processor.

          parallel_tool_calls: Whether to allow the model to run tool calls in parallel.

          previous_response_id: The unique ID of the previous response to the model. Use this to create
              multi-turn conversations.

          priority: The priority of the request (lower means earlier handling; default: 0). Any
              priority other than 0 will raise an error if the served model does not use
              priority scheduling.

          prompt: Reference to a prompt template and its variables.

          reasoning: Configuration options for reasoning models.

          request_id: The request_id related to this request. If the caller does not set it, a
              random_uuid will be generated. This id is used through out the inference process
              and return in response.

          service_tier: Specifies the processing type used for serving the request.

          store: Whether to store the generated model response for later retrieval via API.

          stream: If set to true, the model response data will be streamed to the client as it is
              generated using server-sent events.

          temperature: What sampling temperature to use, between 0 and 2. Higher values like 0.8 will
              make the output more random, while lower values like 0.2 will make it more
              focused and deterministic. We generally recommend altering this or top_p but not
              both.

          text: Configuration options for a text response from the model. Can be plain text or
              structured JSON data.

          tool_choice: How the model should select which tool (or tools) to use when generating a
              response. See the tools parameter to see how to specify which tools the model
              can call.

          tools: An array of tools the model may call while generating a response. You can
              specify which tool to use by setting the tool_choice parameter.

          top_logprobs: An integer between 0 and 20 specifying the number of most likely tokens to
              return at each token position, each with an associated log probability.

          top_p: An alternative to sampling with temperature, called nucleus sampling, where the
              model considers the results of the tokens with top_p probability mass. So 0.1
              means only the tokens comprising the top 10% probability mass are considered.

          truncation: The truncation strategy to use for the model response.

          user: This field is being replaced by safety_identifier and prompt_cache_key. Use
              prompt_cache_key instead to maintain caching optimizations. A stable identifier
              for your end-users. Used to boost cache hit rates by better bucketing similar
              requests and to help OpenAI detect and prevent abuse.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/openai/v1/responses",
            body=await async_maybe_transform(
                {
                    "input": input,
                    "model": model,
                    "background": background,
                    "cache_salt": cache_salt,
                    "include": include,
                    "instructions": instructions,
                    "max_output_tokens": max_output_tokens,
                    "max_tool_calls": max_tool_calls,
                    "metadata": metadata,
                    "mm_processor_kwargs": mm_processor_kwargs,
                    "parallel_tool_calls": parallel_tool_calls,
                    "previous_response_id": previous_response_id,
                    "priority": priority,
                    "prompt": prompt,
                    "reasoning": reasoning,
                    "request_id": request_id,
                    "service_tier": service_tier,
                    "store": store,
                    "stream": stream,
                    "temperature": temperature,
                    "text": text,
                    "tool_choice": tool_choice,
                    "tools": tools,
                    "top_logprobs": top_logprobs,
                    "top_p": top_p,
                    "truncation": truncation,
                    "user": user,
                },
                response_create_params.ResponseCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ResponseCreateResponse,
            stream=stream or False,
            stream_cls=AsyncStream[ResponseStreamEvent],
        )


class ResponsesResourceWithRawResponse:
    def __init__(self, responses: ResponsesResource) -> None:
        self._responses = responses

        self.create = to_raw_response_wrapper(
            responses.create,
        )


class AsyncResponsesResourceWithRawResponse:
    def __init__(self, responses: AsyncResponsesResource) -> None:
        self._responses = responses

        self.create = async_to_raw_response_wrapper(
            responses.create,
        )


class ResponsesResourceWithStreamingResponse:
    def __init__(self, responses: ResponsesResource) -> None:
        self._responses = responses

        self.create = to_streamed_response_wrapper(
            responses.create,
        )


class AsyncResponsesResourceWithStreamingResponse:
    def __init__(self, responses: AsyncResponsesResource) -> None:
        self._responses = responses

        self.create = async_to_streamed_response_wrapper(
            responses.create,
        )
