# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Generic, TypeVar, Optional
from typing_extensions import override

from ._base_client import BasePage, PageInfo, BaseSyncPage, BaseAsyncPage

__all__ = ["SyncOffsetPagination", "AsyncOffsetPagination"]

_T = TypeVar("_T")


class SyncOffsetPagination(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    data: List[_T]

    has_next: bool
    """True if more pages exist"""

    limit: int
    """Items per page"""

    page: int
    """Current page number (1-based)"""

    count: Optional[int] = None
    """Count of items returned so far"""

    total: Optional[int] = None
    """Total count of items"""

    @override
    def _get_page_items(self) -> List[_T]:
        data = self.data
        if not data:
            return []
        return data

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        if not self.has_next:
            return None

        return PageInfo(params={"page": self.page + 1})


class AsyncOffsetPagination(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    data: List[_T]

    has_next: bool
    """True if more pages exist"""

    limit: int
    """Items per page"""

    page: int
    """Current page number (1-based)"""

    count: Optional[int] = None
    """Count of items returned so far"""

    total: Optional[int] = None
    """Total count of items"""

    @override
    def _get_page_items(self) -> List[_T]:
        data = self.data
        if not data:
            return []
        return data

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        if not self.has_next:
            return None

        return PageInfo(params={"page": self.page + 1})
