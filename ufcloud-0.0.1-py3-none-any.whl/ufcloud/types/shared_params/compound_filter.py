# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import TYPE_CHECKING, Union, Iterable
from typing_extensions import Literal, Required, TypeAlias, TypedDict, TypeAliasType

from ..._types import SequenceNotStr
from ..._compat import PYDANTIC_V1

__all__ = ["CompoundFilter", "Filter", "FilterComparisonFilter"]


class FilterComparisonFilter(TypedDict, total=False):
    """
    A filter used to compare a specified attribute key to a given value using a defined comparison operation.
    """

    key: Required[str]
    """The key to compare against the value."""

    type: Required[Literal["eq", "ne", "gt", "gte", "lt", "lte"]]
    """
    Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`,
    `nin`.
    """

    value: Required[Union[str, float, bool, SequenceNotStr[Union[str, float]]]]
    """
    The value to compare against the attribute key; supports string, number, or
    boolean types.
    """


if TYPE_CHECKING or not PYDANTIC_V1:
    Filter = TypeAliasType("Filter", Union[FilterComparisonFilter, "CompoundFilter"])
else:
    Filter: TypeAlias = Union[FilterComparisonFilter, "CompoundFilter"]


class CompoundFilter(TypedDict, total=False):
    """Combine multiple filters using `and` or `or`."""

    filters: Required[Iterable[Filter]]
    """Array of filters to combine.

    Items can be `ComparisonFilter` or `CompoundFilter`.
    """

    type: Required[Literal["and", "or"]]
    """Type of operation: `and` or `or`."""
