# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "RerankCreateResponse",
    "Result",
    "ResultDocument",
    "ResultDocumentMultiModal",
    "ResultDocumentMultiModalContent",
    "ResultDocumentMultiModalContentChatCompletionContentPartImageParam",
    "ResultDocumentMultiModalContentChatCompletionContentPartImageParamImageURL",
    "ResultDocumentMultiModalContentChatCompletionContentPartImageEmbedsParam",
    "Usage",
]


class ResultDocumentMultiModalContentChatCompletionContentPartImageParamImageURL(BaseModel):
    url: str

    detail: Optional[Literal["auto", "low", "high"]] = None


class ResultDocumentMultiModalContentChatCompletionContentPartImageParam(BaseModel):
    image_url: ResultDocumentMultiModalContentChatCompletionContentPartImageParamImageURL

    type: Literal["image_url"]


class ResultDocumentMultiModalContentChatCompletionContentPartImageEmbedsParam(BaseModel):
    type: Literal["image_embeds"]

    image_embeds: Union[str, Dict[str, str], None] = None

    uuid: Optional[str] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


ResultDocumentMultiModalContent: TypeAlias = Union[
    ResultDocumentMultiModalContentChatCompletionContentPartImageParam,
    ResultDocumentMultiModalContentChatCompletionContentPartImageEmbedsParam,
]


class ResultDocumentMultiModal(BaseModel):
    """A specialized parameter type for scoring multimodal content."""

    content: List[ResultDocumentMultiModalContent]

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class ResultDocument(BaseModel):
    """Schema for a document in reranking responses."""

    multi_modal: Optional[ResultDocumentMultiModal] = None
    """A specialized parameter type for scoring multimodal content."""

    text: Optional[str] = None
    """The content of the document."""


class Result(BaseModel):
    """Schema for a single reranking result."""

    document: ResultDocument
    """Schema for a document in reranking responses."""

    index: int
    """The original index of the document in the request."""

    relevance_score: float
    """The relevance score assigned by the reranking model."""


class Usage(BaseModel):
    """Token usage information."""

    total_tokens: int
    """Total tokens consumed."""


class RerankCreateResponse(BaseModel):
    """Response schema for reranked documents."""

    id: str
    """Unique identifier for the reranking response."""

    model: str
    """ID of the reranking model used."""

    results: List[Result]
    """A list of reranking results."""

    usage: Usage
    """Token usage information."""
