# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["RerankCreateParams"]


class RerankCreateParams(TypedDict, total=False):
    documents: Required[SequenceNotStr[str]]
    """A list of document texts to be reranked."""

    model: Required[str]
    """ID of the reranking model to use."""

    query: Required[str]
    """The query string to rerank documents against."""

    mm_processor_kwargs: Optional[Dict[str, object]]
    """Optional multi-modal processor parameters."""

    priority: Optional[int]
    """Priority of the request."""

    top_n: Optional[int]
    """The number of top results to return."""

    truncate_prompt_tokens: Optional[int]
    """Number of tokens to truncate from the prompt if it exceeds model limits."""
