# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, TypedDict

__all__ = ["EndpointUpdateParams"]


class EndpointUpdateParams(TypedDict, total=False):
    display_name: Optional[str]
    """New display name (1-64 chars, alphanumeric with spaces and hyphens).

    Only when ACTIVE.
    """

    inactive_timeout: Optional[int]
    """Minutes of inactivity before auto-shutdown. Null to disable. Only when ACTIVE."""

    state: Optional[Literal["STOPPED", "STARTED"]]
    """Lifecycle control: 'STOPPED' (from ACTIVE) or 'STARTED' (from STOPPED)."""
