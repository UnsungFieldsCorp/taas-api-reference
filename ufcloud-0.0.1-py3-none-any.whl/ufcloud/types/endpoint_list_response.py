# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .._models import BaseModel
from .dedicated_endpoint_response import DedicatedEndpointResponse

__all__ = ["EndpointListResponse"]


class EndpointListResponse(BaseModel):
    data: List[DedicatedEndpointResponse]

    has_more: bool
    """True if more pages exist"""

    limit: int
    """Items per page"""

    page: int
    """Current page number (1-based)"""

    count: Optional[int] = None
    """Count of items returned so far"""

    total: Optional[int] = None
    """Total count of items"""
