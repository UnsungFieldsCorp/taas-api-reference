# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["BatchListResponse", "Data", "DataRequestCounts"]


class DataRequestCounts(BaseModel):
    """A model to track the total, completed, and failed requests within a batch job."""

    completed: Optional[int] = None
    """Number of requests that have been completed successfully."""

    failed: Optional[int] = None
    """Number of requests that have failed."""

    total: Optional[int] = None
    """Total number of requests in the batch."""


class Data(BaseModel):
    """The batch object."""

    id: str
    """The batch ID."""

    completion_window: str
    """The time frame for the batch completion."""

    created_at: int
    """The creation timestamp in Unix format."""

    endpoint: str
    """The endpoint for the batch requests."""

    expires_at: int
    """The expiration timestamp in Unix format."""

    input_file_id: str
    """The ID of the input file."""

    request_counts: DataRequestCounts
    """A model to track the total, completed, and failed requests within a batch job."""

    status: str
    """The status of the batch job."""

    cancelled_at: Optional[int] = None

    completed_at: Optional[int] = None

    error_file_id: Optional[str] = None
    """The ID of the file containing the outputs of requests with errors."""

    failed_at: Optional[int] = None

    metadata: Optional[Dict[str, object]] = None
    """Key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard.
    """

    object: Optional[Literal["batch"]] = None
    """The object type, always 'batch'."""

    output_file_id: Optional[str] = None
    """The ID of the file containing the outputs of successfully executed requests."""


class BatchListResponse(BaseModel):
    data: List[Data]
    """The list of batches."""

    has_more: bool
    """Whether there are more batches to fetch."""

    object: Literal["list"]
    """The object type, always 'list'."""
