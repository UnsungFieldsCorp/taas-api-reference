# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["EmbeddingCreateResponse", "Data", "Usage", "UsagePromptTokensDetails"]


class Data(BaseModel):
    """Schema for a single embedding result."""

    embedding: Union[List[float], str]
    """List of embedding values or a base64 encoded string."""

    index: int
    """Index of the input chunk."""

    object: Optional[Literal["embedding"]] = None
    """The object type, which is always "embedding"."""


class UsagePromptTokensDetails(BaseModel):
    """Breakdown of tokens in the prompt."""

    cached_tokens: Optional[int] = None
    """Number of tokens that were cached and reused."""


class Usage(BaseModel):
    """Usage statistics for the completion request."""

    prompt_tokens: int
    """Number of tokens in the prompt."""

    total_tokens: int
    """Total number of tokens used in the request (prompt + completion)."""

    completion_tokens: Optional[int] = None
    """Number of tokens in the generated completion."""

    prompt_tokens_details: Optional[UsagePromptTokensDetails] = None
    """Breakdown of tokens in the prompt."""


class EmbeddingCreateResponse(BaseModel):
    """Response schema for generated embeddings."""

    id: str
    """Unique identifier for the embedding response."""

    data: List[Data]
    """List of embedding results."""

    model: str
    """ID of the embedding model used."""

    object: str
    """The object type, which is always "list"."""

    usage: Usage
    """Usage statistics for the completion request."""

    created: Optional[int] = None
    """Timestamp of when the embeddings were created."""
