# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["FineTuningCreateResponse", "Job"]


class Job(BaseModel):
    """A lean summary of a fine-tuning job, returned upon creation."""

    created_at: datetime

    job_id: str

    model: str

    status: Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"]
    """Enum for the status of a fine-tuning job."""

    type: str

    suffix: Optional[str] = None


class FineTuningCreateResponse(BaseModel):
    job: Optional[Job] = None
    """A lean summary of a fine-tuning job, returned upon creation."""
