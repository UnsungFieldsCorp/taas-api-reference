# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["EndpointCreateParams"]


class EndpointCreateParams(TypedDict, total=False):
    display_name: Required[str]
    """User-friendly identifier (1-64 chars, alphanumeric with spaces and hyphens)."""

    model: Required[str]
    """Full model name (output_model_name from a completed fine-tuning job)."""

    hardware: Optional[str]
    """
    Hardware configuration ID from GET /v1/hardware (e.g.,
    '4x_nvidia_h200_140gb_sxm'). Defaults to minimum compatible hardware if omitted.
    """

    inactive_timeout: Optional[int]
    """Minutes of inactivity before auto-shutdown. Null to disable (default: null)."""
