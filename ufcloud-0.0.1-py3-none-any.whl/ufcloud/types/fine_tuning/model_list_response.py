# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..._models import BaseModel

__all__ = ["ModelListResponse", "Model"]


class Model(BaseModel):
    """Response for a single fine-tuning model."""

    default_gpu_count: int

    default_gpu_type: str

    family: str

    max_lora_rank: int

    max_seq_len: int

    name: str

    parameters_billion: float


class ModelListResponse(BaseModel):
    models: List[Model]
