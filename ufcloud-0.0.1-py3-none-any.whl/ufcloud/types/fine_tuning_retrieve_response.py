# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "FineTuningRetrieveResponse",
    "Job",
    "JobArtifacts",
    "JobArtifactsCheckpoint",
    "JobArtifactsFinalAdapter",
    "JobErrors",
    "JobEvent",
    "JobEventMetadata",
    "JobEventMetadataFineTuneEventMetadata",
    "JobHyperparams",
    "JobMetrics",
    "JobUsage",
    "JobUsageArtifacts",
    "JobUsageDataset",
    "JobUsageErrors",
]


class JobArtifactsCheckpoint(BaseModel):
    """Schema for a checkpoint artifact."""

    artifact_type: str

    created_at: datetime

    download_url: str

    name: str


class JobArtifactsFinalAdapter(BaseModel):
    """Schema for the final adapter artifact."""

    artifact_type: Literal["adapter"]

    created_at: datetime

    download_url: str


class JobArtifacts(BaseModel):
    """Schema for the artifacts of a fine-tuning job."""

    checkpoints: Optional[List[JobArtifactsCheckpoint]] = None

    final_adapter: Optional[JobArtifactsFinalAdapter] = None
    """Schema for the final adapter artifact."""


class JobErrors(BaseModel):
    """Schema for the errors of a fine-tuning job."""

    message: Optional[str] = None

    stack: Optional[str] = None

    type: Optional[Literal["user_error", "system_error", "none"]] = None


class JobEventMetadataFineTuneEventMetadata(BaseModel):
    """Schema for the metadata of a fine-tuning event."""

    epoch: Optional[int] = None

    global_step: Optional[int] = None

    api_model_name: Optional[str] = FieldInfo(alias="model_name", default=None)


JobEventMetadata: TypeAlias = Union[JobEventMetadataFineTuneEventMetadata, Dict[str, object], None]


class JobEvent(BaseModel):
    id: str

    event_type: Literal[
        "JOB_PENDING",
        "JOB_START",
        "MODEL_DOWNLOADING",
        "MODEL_DOWNLOAD_COMPLETE",
        "TRAINING_DATA_DOWNLOADING",
        "TRAINING_DATA_READY",
        "PRECHECK_COMPLETE",
        "TRAINING_START",
        "EPOCH_COMPLETE",
        "EVAL_COMPLETE",
        "TRAINING_COMPLETE",
        "COMPRESSING_ADAPTER",
        "ADAPTER_COMPRESSION_COMPLETE",
        "MODEL_UPLOADING",
        "MODEL_UPLOAD_COMPLETE",
        "JOB_COMPLETE",
        "JOB_USER_ERROR",
        "JOB_SYSTEM_ERROR",
    ]

    job_id: str

    message: str

    org_id: str

    metadata: Optional[JobEventMetadata] = None
    """Schema for the metadata of a fine-tuning event."""

    timestamp: Optional[datetime] = None


class JobHyperparams(BaseModel):
    """Schema for the hyperparameters of a fine-tuning job."""

    batch_size: Optional[int] = None

    epochs: Optional[int] = None

    gradient_accumulation_steps: Optional[int] = None

    learning_rate: Optional[float] = None

    lora_alpha: Optional[int] = None

    lora_dropout: Optional[float] = None

    lora_rank: Optional[int] = None

    lora_target_modules: Optional[List[str]] = None

    lr_scheduler_args: Optional[Dict[str, object]] = None

    lr_scheduler_type: Optional[str] = None

    max_grad_norm: Optional[float] = None

    max_seq_len: Optional[int] = None

    n_checkpoints: Optional[int] = None

    n_evals: Optional[int] = None

    train_on_inputs: Optional[str] = None

    training_method: Optional[str] = None

    warmup_ratio: Optional[float] = None

    weight_decay: Optional[float] = None


class JobMetrics(BaseModel):
    """Schema for the metrics of a fine-tuning job."""

    epochs_completed: Optional[int] = None

    eval_loss: Optional[float] = None

    eval_tokens: Optional[int] = None

    final_train_loss: Optional[float] = None

    steps_completed: Optional[int] = None

    train_tokens: Optional[int] = None


class JobUsageArtifacts(BaseModel):
    """Schema for the artifact usage of a fine-tuning job."""

    adapter_size_bytes: Optional[int] = None

    checkpoint_sizes: Optional[List[int]] = None

    num_checkpoints: Optional[int] = None


class JobUsageDataset(BaseModel):
    """Schema for the dataset usage of a fine-tuning job."""

    line_count: Optional[int] = None

    schema_type: Optional[Literal["instruction", "messages"]] = None

    size_bytes: Optional[int] = None

    tokens_estimated: Optional[int] = None


class JobUsageErrors(BaseModel):
    """Schema for the errors in the usage block of a fine-tuning job."""

    message: Optional[str] = None

    stack: Optional[str] = None

    type: Optional[Literal["user_error", "system_error", "none"]] = None


class JobUsage(BaseModel):
    """Schema for the canonical usage telemetry block of a fine-tuning job."""

    artifacts: Optional[JobUsageArtifacts] = None
    """Schema for the artifact usage of a fine-tuning job."""

    dataset: Optional[JobUsageDataset] = None
    """Schema for the dataset usage of a fine-tuning job."""

    errors: Optional[JobUsageErrors] = None
    """Schema for the errors in the usage block of a fine-tuning job."""

    eval_tokens: Optional[int] = None

    gpu_count: Optional[int] = None

    gpu_end_at: Optional[datetime] = None

    gpu_hours: Optional[float] = None

    gpu_seconds: Optional[int] = None

    gpu_start_at: Optional[datetime] = None

    gpu_type: Optional[str] = None

    max_seq_len: Optional[int] = None

    runtime_seconds: Optional[int] = None

    tokens_per_step: Optional[int] = None

    total_steps: Optional[int] = None

    train_tokens: Optional[int] = None


class Job(BaseModel):
    """Schema representing a fine-tuning job as stored in the database.

    org_id is re-declared here as non-optional to enforce its presence in the database.
    """

    id: str

    created_at: datetime

    job_id: str

    org_id: str

    status: Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"]
    """Enum for the status of a fine-tuning job."""

    training_file_id: str

    updated_at: datetime

    artifacts: Optional[JobArtifacts] = None
    """Schema for the artifacts of a fine-tuning job."""

    error_code: Optional[str] = None

    error_message: Optional[str] = None

    error_type: Optional[Literal["user_error", "system_error"]] = None
    """Enum for the type of error in a fine-tuning job."""

    errors: Optional[JobErrors] = None
    """Schema for the errors of a fine-tuning job."""

    events: Optional[List[JobEvent]] = None
    """Schema representing a fine-tuning event as stored in the database."""

    finished_at: Optional[datetime] = None

    hyperparams: Optional[JobHyperparams] = None
    """Schema for the hyperparameters of a fine-tuning job."""

    metrics: Optional[JobMetrics] = None
    """Schema for the metrics of a fine-tuning job."""

    model: Optional[str] = None

    runtime_seconds: Optional[int] = None

    started_at: Optional[datetime] = None

    suffix: Optional[str] = None

    type: Optional[str] = None

    usage: Optional[JobUsage] = None
    """Schema for the canonical usage telemetry block of a fine-tuning job."""

    validation_file_id: Optional[str] = None


class FineTuningRetrieveResponse(BaseModel):
    job: Optional[Job] = None
    """Schema representing a fine-tuning job as stored in the database.

    org_id is re-declared here as non-optional to enforce its presence in the
    database.
    """
