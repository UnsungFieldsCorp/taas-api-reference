# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, TypedDict

__all__ = ["EndpointListParams"]


class EndpointListParams(TypedDict, total=False):
    limit: int
    """Items per page, max 100"""

    page: int
    """Page number, 1-based"""

    state: Literal["PENDING", "PROVISIONING", "ACTIVE", "FAILED", "STOPPING", "STOPPED"]
    """Filter by endpoint state"""
