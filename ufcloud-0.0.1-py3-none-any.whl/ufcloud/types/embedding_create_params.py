# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from typing_extensions import Literal, Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["EmbeddingCreateParams"]


class EmbeddingCreateParams(TypedDict, total=False):
    input: Required[Union[str, SequenceNotStr[str]]]
    """Single text chunk or a list of text chunks to embed."""

    model: Required[str]
    """ID of the embedding model to use."""

    encoding_format: Optional[Literal["float", "base64"]]
    """The format to return the embeddings in. Can be either float or base64."""

    truncate_prompt_tokens: Optional[int]
    """Number of tokens to truncate from the prompt if it exceeds model limits."""

    user: Optional[str]
    """A unique identifier representing your end-user."""
