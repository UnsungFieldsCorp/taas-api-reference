# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["EndpointUsage"]


class EndpointUsage(BaseModel):
    """Cumulative usage statistics for a dedicated endpoint."""

    gpu_hours_total: Optional[float] = None
    """Cumulative GPU hours consumed."""

    last_request_at: Optional[datetime] = None
    """Timestamp of most recent request."""

    requests_total: Optional[int] = None
    """Total inference requests."""

    tokens_in_total: Optional[int] = None
    """Total input tokens processed."""

    tokens_out_total: Optional[int] = None
    """Total output tokens generated."""
