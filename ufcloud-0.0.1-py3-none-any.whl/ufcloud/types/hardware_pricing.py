# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["HardwarePricing"]


class HardwarePricing(BaseModel):
    """Pricing for a hardware configuration."""

    cents_per_minute: float
    """Cost per minute in cents."""
