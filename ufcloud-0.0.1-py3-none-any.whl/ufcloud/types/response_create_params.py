# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Union, Iterable
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .._types import SequenceNotStr

__all__ = [
    "ResponseCreateParams",
    "InputInputItemList",
    "InputInputItemListEasyInputMessage",
    "InputInputItemListEasyInputMessageContentInputItemContentList",
    "InputInputItemListEasyInputMessageContentInputItemContentListInputTextContent",
    "InputInputItemListEasyInputMessageContentInputItemContentListInputImageContent",
    "InputInputItemListEasyInputMessageContentInputItemContentListInputFileContent",
    "InputInputItemListInputMessage",
    "InputInputItemListInputMessageContent",
    "InputInputItemListInputMessageContentInputTextContent",
    "InputInputItemListInputMessageContentInputImageContent",
    "InputInputItemListInputMessageContentInputFileContent",
    "InputInputItemListOutputMessage",
    "InputInputItemListOutputMessageContent",
    "InputInputItemListOutputMessageContentOutputTextContent",
    "InputInputItemListOutputMessageContentOutputTextContentAnnotation",
    "InputInputItemListOutputMessageContentOutputTextContentAnnotationFileCitationBody",
    "InputInputItemListOutputMessageContentOutputTextContentAnnotationURLCitationBody",
    "InputInputItemListOutputMessageContentOutputTextContentAnnotationContainerFileCitationBody",
    "InputInputItemListOutputMessageContentOutputTextContentAnnotationFilePath",
    "InputInputItemListOutputMessageContentOutputTextContentLogprob",
    "InputInputItemListOutputMessageContentOutputTextContentLogprobTopLogprob",
    "InputInputItemListOutputMessageContentRefusalContent",
    "InputInputItemListFileSearchToolCall",
    "InputInputItemListFileSearchToolCallResult",
    "InputInputItemListComputerToolCall",
    "InputInputItemListComputerToolCallAction",
    "InputInputItemListComputerToolCallActionClickParam",
    "InputInputItemListComputerToolCallActionDoubleClickAction",
    "InputInputItemListComputerToolCallActionDrag",
    "InputInputItemListComputerToolCallActionDragPath",
    "InputInputItemListComputerToolCallActionKeyPressAction",
    "InputInputItemListComputerToolCallActionMove",
    "InputInputItemListComputerToolCallActionScreenshot",
    "InputInputItemListComputerToolCallActionScroll",
    "InputInputItemListComputerToolCallActionType",
    "InputInputItemListComputerToolCallActionWait",
    "InputInputItemListComputerToolCallPendingSafetyCheck",
    "InputInputItemListComputerCallOutputItemParam",
    "InputInputItemListComputerCallOutputItemParamOutput",
    "InputInputItemListComputerCallOutputItemParamAcknowledgedSafetyCheck",
    "InputInputItemListWebSearchToolCall",
    "InputInputItemListWebSearchToolCallAction",
    "InputInputItemListWebSearchToolCallActionWebSearchActionSearch",
    "InputInputItemListWebSearchToolCallActionWebSearchActionSearchSource",
    "InputInputItemListWebSearchToolCallActionWebSearchActionOpenPage",
    "InputInputItemListWebSearchToolCallActionWebSearchActionFind",
    "InputInputItemListFunctionToolCall",
    "InputInputItemListFunctionCallOutputItemParam",
    "InputInputItemListFunctionCallOutputItemParamOutputArrayOutput",
    "InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputTextContent",
    "InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputImageContent",
    "InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputFileContent",
    "InputInputItemListReasoningItem",
    "InputInputItemListReasoningItemSummary",
    "InputInputItemListReasoningItemContent",
    "InputInputItemListCompactionSummaryItemParam",
    "InputInputItemListImageGenToolCall",
    "InputInputItemListCodeInterpreterToolCall",
    "InputInputItemListCodeInterpreterToolCallOutput",
    "InputInputItemListCodeInterpreterToolCallOutputCodeInterpreterOutputLogs",
    "InputInputItemListCodeInterpreterToolCallOutputCodeInterpreterOutputImage",
    "InputInputItemListLocalShellToolCall",
    "InputInputItemListLocalShellToolCallAction",
    "InputInputItemListLocalShellToolCallOutput",
    "InputInputItemListFunctionShellCallItemParam",
    "InputInputItemListFunctionShellCallItemParamAction",
    "InputInputItemListFunctionShellCallOutputItemParam",
    "InputInputItemListFunctionShellCallOutputItemParamOutput",
    "InputInputItemListFunctionShellCallOutputItemParamOutputOutcome",
    "InputInputItemListFunctionShellCallOutputItemParamOutputOutcomeShellCallTimeoutOutcome",
    "InputInputItemListFunctionShellCallOutputItemParamOutputOutcomeShellCallExitOutcome",
    "InputInputItemListApplyPatchToolCallItemParam",
    "InputInputItemListApplyPatchToolCallItemParamOperation",
    "InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchCreateFileOperation",
    "InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchDeleteFileOperation",
    "InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchUpdateFileOperation",
    "InputInputItemListApplyPatchToolCallOutputItemParam",
    "InputInputItemListMcpListTools",
    "InputInputItemListMcpListToolsTool",
    "InputInputItemListMcpApprovalRequest",
    "InputInputItemListMcpApprovalResponse",
    "InputInputItemListMcpToolCall",
    "InputInputItemListCustomToolCallOutput",
    "InputInputItemListCustomToolCallOutputOutputOutputContentList",
    "InputInputItemListCustomToolCallOutputOutputOutputContentListInputTextContent",
    "InputInputItemListCustomToolCallOutputOutputOutputContentListInputImageContent",
    "InputInputItemListCustomToolCallOutputOutputOutputContentListInputFileContent",
    "InputInputItemListCustomToolCall",
    "InputInputItemListItemReferenceParam",
    "Prompt",
    "PromptVariables",
    "PromptVariablesInputTextContent",
    "PromptVariablesInputImageContent",
    "PromptVariablesInputFileContent",
    "Reasoning",
    "Text",
    "TextFormat",
    "TextFormatResponseFormatText",
    "TextFormatTextResponseFormatJsonSchema",
    "TextFormatResponseFormatJsonObject",
    "ToolChoice",
    "ToolChoiceToolChoiceAllowed",
    "ToolChoiceToolChoiceTypes",
    "ToolChoiceToolChoiceFunction",
    "ToolChoiceToolChoiceMcp",
    "ToolChoiceToolChoiceCustom",
    "ToolChoiceSpecificApplyPatchParam",
    "ToolChoiceSpecificFunctionShellParam",
    "Tool",
    "ToolFunctionTool",
    "ToolFileSearchTool",
    "ToolFileSearchToolFilters",
    "ToolFileSearchToolFiltersComparisonFilter",
    "ToolFileSearchToolRankingOptions",
    "ToolFileSearchToolRankingOptionsHybridSearch",
    "ToolComputerUsePreviewTool",
    "ToolWebSearchTool",
    "ToolWebSearchToolFilters",
    "ToolWebSearchToolUserLocation",
    "ToolMcpTool",
    "ToolMcpToolAllowedTools",
    "ToolMcpToolAllowedToolsMcpToolFilter",
    "ToolMcpToolRequireApproval",
    "ToolMcpToolRequireApprovalMcpToolApprovalFilter",
    "ToolMcpToolRequireApprovalMcpToolApprovalFilterAlways",
    "ToolMcpToolRequireApprovalMcpToolApprovalFilterNever",
    "ToolCodeInterpreterTool",
    "ToolCodeInterpreterToolContainer",
    "ToolCodeInterpreterToolContainerCodeInterpreterToolAuto",
    "ToolImageGenTool",
    "ToolImageGenToolInputImageMask",
    "ToolLocalShellToolParam",
    "ToolFunctionShellToolParam",
    "ToolCustomToolParam",
    "ToolCustomToolParamFormat",
    "ToolCustomToolParamFormatGrammarFormat",
    "ToolWebSearchPreviewTool",
    "ToolWebSearchPreviewToolUserLocation",
    "ToolApplyPatchToolParam",
]


class ResponseCreateParams(TypedDict, total=False):
    input: Required[Union[str, Iterable[InputInputItemList]]]
    """Text, image, or file inputs to the model, used to generate a response."""

    model: Required[str]
    """ID of the model to use."""

    background: bool
    """Whether to run the model response in the background."""

    cache_salt: str
    """A salt value to add to the prompt cache key.

    This can be used to create a unique cache key for a request.
    """

    include: List[
        Literal[
            "code_interpreter_call.outputs",
            "computer_call_output.output.image_url",
            "file_search_call.results",
            "message.input_image.image_url",
            "message.output_text.logprobs",
            "reasoning.encrypted_content",
        ]
    ]
    """Specify additional output data to include in the model response."""

    instructions: str
    """A system (or developer) message inserted into the model's context."""

    max_output_tokens: int
    """
    An upper bound for the number of tokens that can be generated for a response,
    including visible output tokens and reasoning tokens.
    """

    max_tool_calls: int
    """
    The maximum number of total calls to built-in tools that can be processed in a
    response. This maximum number applies across all built-in tool calls, not per
    individual tool. Any further attempts to call a tool by the model will be
    ignored.
    """

    metadata: Dict[str, object]
    """Set of 16 key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard. Keys are
    strings with a maximum length of 64 characters. Values are strings with a
    maximum length of 512 characters.
    """

    mm_processor_kwargs: Dict[str, object]
    """Additional kwargs to pass to the HF processor."""

    parallel_tool_calls: bool
    """Whether to allow the model to run tool calls in parallel."""

    previous_response_id: str
    """The unique ID of the previous response to the model.

    Use this to create multi-turn conversations.
    """

    priority: int
    """The priority of the request (lower means earlier handling; default: 0).

    Any priority other than 0 will raise an error if the served model does not use
    priority scheduling.
    """

    prompt: Prompt
    """Reference to a prompt template and its variables."""

    reasoning: Reasoning
    """Configuration options for reasoning models."""

    request_id: str
    """The request_id related to this request.

    If the caller does not set it, a random_uuid will be generated. This id is used
    through out the inference process and return in response.
    """

    service_tier: Literal["auto", "default", "flex", "scale", "priority"]
    """Specifies the processing type used for serving the request."""

    store: bool
    """Whether to store the generated model response for later retrieval via API."""

    stream: bool
    """
    If set to true, the model response data will be streamed to the client as it is
    generated using server-sent events.
    """

    temperature: float
    """What sampling temperature to use, between 0 and 2.

    Higher values like 0.8 will make the output more random, while lower values like
    0.2 will make it more focused and deterministic. We generally recommend altering
    this or top_p but not both.
    """

    text: Text
    """Configuration options for a text response from the model.

    Can be plain text or structured JSON data.
    """

    tool_choice: ToolChoice
    """
    How the model should select which tool (or tools) to use when generating a
    response. See the tools parameter to see how to specify which tools the model
    can call.
    """

    tools: Iterable[Tool]
    """An array of tools the model may call while generating a response.

    You can specify which tool to use by setting the tool_choice parameter.
    """

    top_logprobs: int
    """
    An integer between 0 and 20 specifying the number of most likely tokens to
    return at each token position, each with an associated log probability.
    """

    top_p: float
    """
    An alternative to sampling with temperature, called nucleus sampling, where the
    model considers the results of the tokens with top_p probability mass. So 0.1
    means only the tokens comprising the top 10% probability mass are considered.
    """

    truncation: Literal["auto", "disabled"]
    """The truncation strategy to use for the model response."""

    user: str
    """This field is being replaced by safety_identifier and prompt_cache_key.

    Use prompt_cache_key instead to maintain caching optimizations. A stable
    identifier for your end-users. Used to boost cache hit rates by better bucketing
    similar requests and to help OpenAI detect and prevent abuse.
    """


class InputInputItemListEasyInputMessageContentInputItemContentListInputTextContent(TypedDict, total=False):
    """A text input to the model."""

    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class InputInputItemListEasyInputMessageContentInputItemContentListInputImageContent(TypedDict, total=False):
    """An image input to the model."""

    detail: Required[Literal["low", "high", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: str
    """The ID of the file to be sent to the model."""

    image_url: str
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListEasyInputMessageContentInputItemContentListInputFileContent(TypedDict, total=False):
    """A file input to the model."""

    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_url: str
    """The URL of the file to be sent to the model."""

    filename: str
    """The name of the file to be sent to the model."""


InputInputItemListEasyInputMessageContentInputItemContentList: TypeAlias = Union[
    InputInputItemListEasyInputMessageContentInputItemContentListInputTextContent,
    InputInputItemListEasyInputMessageContentInputItemContentListInputImageContent,
    InputInputItemListEasyInputMessageContentInputItemContentListInputFileContent,
]


class InputInputItemListEasyInputMessage(TypedDict, total=False):
    """
    A message input to the model with a role indicating instruction following hierarchy. Instructions given with the `developer` or `system` role take precedence over instructions given with the `user` role. Messages with the `assistant` role are presumed to have been generated by the model in previous interactions.
    """

    content: Required[Union[str, Iterable[InputInputItemListEasyInputMessageContentInputItemContentList]]]
    """Text, image, or audio input to the model, used to generate a response.

    Can also contain previous assistant responses.
    """

    role: Required[Literal["user", "assistant", "system", "developer"]]
    """The role of the message input.

    One of `user`, `assistant`, `system`, or `developer`.
    """

    type: Literal["message"]
    """The type of the message input. Always `message`."""


class InputInputItemListInputMessageContentInputTextContent(TypedDict, total=False):
    """A text input to the model."""

    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class InputInputItemListInputMessageContentInputImageContent(TypedDict, total=False):
    """An image input to the model."""

    detail: Required[Literal["low", "high", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: str
    """The ID of the file to be sent to the model."""

    image_url: str
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListInputMessageContentInputFileContent(TypedDict, total=False):
    """A file input to the model."""

    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_url: str
    """The URL of the file to be sent to the model."""

    filename: str
    """The name of the file to be sent to the model."""


InputInputItemListInputMessageContent: TypeAlias = Union[
    InputInputItemListInputMessageContentInputTextContent,
    InputInputItemListInputMessageContentInputImageContent,
    InputInputItemListInputMessageContentInputFileContent,
]


class InputInputItemListInputMessage(TypedDict, total=False):
    """
    A message input to the model with a role indicating instruction following hierarchy. Instructions given with the `developer` or `system` role take precedence over instructions given with the `user` role.
    """

    content: Required[Iterable[InputInputItemListInputMessageContent]]
    """
    A list of one or many input items to the model, containing different content
    types.
    """

    role: Required[Literal["user", "system", "developer"]]
    """The role of the message input. One of `user`, `system`, or `developer`."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """

    type: Literal["message"]
    """The type of the message input. Always set to `message`."""


class InputInputItemListOutputMessageContentOutputTextContentAnnotationFileCitationBody(TypedDict, total=False):
    """A citation to a file."""

    file_id: Required[str]
    """The ID of the file."""

    filename: Required[str]
    """The filename of the file cited."""

    index: Required[int]
    """The index of the file in the list of files."""

    type: Required[Literal["file_citation"]]
    """The type of the file citation. Always `file_citation`."""


class InputInputItemListOutputMessageContentOutputTextContentAnnotationURLCitationBody(TypedDict, total=False):
    """A citation for a web resource used to generate a model response."""

    end_index: Required[int]
    """The index of the last character of the URL citation in the message."""

    start_index: Required[int]
    """The index of the first character of the URL citation in the message."""

    title: Required[str]
    """The title of the web resource."""

    type: Required[Literal["url_citation"]]
    """The type of the URL citation. Always `url_citation`."""

    url: Required[str]
    """The URL of the web resource."""


class InputInputItemListOutputMessageContentOutputTextContentAnnotationContainerFileCitationBody(
    TypedDict, total=False
):
    """A citation for a container file used to generate a model response."""

    container_id: Required[str]
    """The ID of the container file."""

    end_index: Required[int]
    """The index of the last character of the container file citation in the message."""

    file_id: Required[str]
    """The ID of the file."""

    filename: Required[str]
    """The filename of the container file cited."""

    start_index: Required[int]
    """The index of the first character of the container file citation in the message."""

    type: Required[Literal["container_file_citation"]]
    """The type of the container file citation. Always `container_file_citation`."""


class InputInputItemListOutputMessageContentOutputTextContentAnnotationFilePath(TypedDict, total=False):
    """A path to a file."""

    file_id: Required[str]
    """The ID of the file."""

    index: Required[int]
    """The index of the file in the list of files."""

    type: Required[Literal["file_path"]]
    """The type of the file path. Always `file_path`."""


InputInputItemListOutputMessageContentOutputTextContentAnnotation: TypeAlias = Union[
    InputInputItemListOutputMessageContentOutputTextContentAnnotationFileCitationBody,
    InputInputItemListOutputMessageContentOutputTextContentAnnotationURLCitationBody,
    InputInputItemListOutputMessageContentOutputTextContentAnnotationContainerFileCitationBody,
    InputInputItemListOutputMessageContentOutputTextContentAnnotationFilePath,
]


class InputInputItemListOutputMessageContentOutputTextContentLogprobTopLogprob(TypedDict, total=False):
    """The top log probability of a token."""

    token: Required[str]

    bytes: Required[Iterable[int]]

    logprob: Required[float]


class InputInputItemListOutputMessageContentOutputTextContentLogprob(TypedDict, total=False):
    """The log probability of a token."""

    token: Required[str]

    bytes: Required[Iterable[int]]

    logprob: Required[float]

    top_logprobs: Required[Iterable[InputInputItemListOutputMessageContentOutputTextContentLogprobTopLogprob]]


class InputInputItemListOutputMessageContentOutputTextContent(TypedDict, total=False):
    """A text output from the model."""

    annotations: Required[Iterable[InputInputItemListOutputMessageContentOutputTextContentAnnotation]]
    """The annotations of the text output."""

    text: Required[str]
    """The text output from the model."""

    type: Required[Literal["output_text"]]
    """The type of the output text. Always `output_text`."""

    logprobs: Iterable[InputInputItemListOutputMessageContentOutputTextContentLogprob]
    """The log probability of a token."""


class InputInputItemListOutputMessageContentRefusalContent(TypedDict, total=False):
    """A refusal from the model."""

    refusal: Required[str]
    """The refusal explanation from the model."""

    type: Required[Literal["refusal"]]
    """The type of the refusal. Always `refusal`."""


InputInputItemListOutputMessageContent: TypeAlias = Union[
    InputInputItemListOutputMessageContentOutputTextContent, InputInputItemListOutputMessageContentRefusalContent
]


class InputInputItemListOutputMessage(TypedDict, total=False):
    """An output message from the model."""

    id: Required[str]
    """The unique ID of the output message."""

    content: Required[Iterable[InputInputItemListOutputMessageContent]]
    """
    A list of one or many output items from the model, containing different content
    types.
    """

    role: Required[Literal["assistant"]]
    """The role of the output message. Always `assistant`."""

    status: Required[Literal["in_progress", "completed", "incomplete"]]
    """The status of the message input.

    One of `in_progress`, `completed`, or `incomplete`. Populated when input items
    are returned via API.
    """

    type: Required[Literal["message"]]
    """The type of the output message. Always `message`."""


class InputInputItemListFileSearchToolCallResult(TypedDict, total=False):
    attributes: Dict[str, Union[str, float, bool]]
    """Set of 16 key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard. Keys are
    strings with a maximum length of 64 characters. Values are strings with a
    maximum length of 512 characters, booleans, or numbers.
    """

    file_id: str
    """The unique ID of the file."""

    filename: str
    """The name of the file."""

    score: float
    """The relevance score of the file - a value between 0 and 1."""

    text: str
    """The text that was retrieved from the file."""


class InputInputItemListFileSearchToolCall(TypedDict, total=False):
    """The results of a file search tool call."""

    id: Required[str]
    """The unique ID of the file search tool call."""

    queries: Required[SequenceNotStr[str]]
    """The queries used to search for files."""

    status: Required[Literal["in_progress", "searching", "completed", "incomplete", "failed"]]
    """The status of the file search tool call.

    One of `in_progress`, `searching`, `incomplete` or `failed`,
    """

    type: Required[Literal["file_search_call"]]
    """The type of the file search tool call. Always `file_search_call`."""

    results: Iterable[InputInputItemListFileSearchToolCallResult]
    """The results of the file search tool call."""


class InputInputItemListComputerToolCallActionClickParam(TypedDict, total=False):
    """A click action."""

    button: Required[Literal["left", "right", "wheel", "back", "forward"]]
    """Indicates which mouse button was pressed during the click.

    One of `left`, `right`, `wheel`, `back`, or `forward`.
    """

    type: Required[Literal["click"]]
    """Specifies the event type. For a click action, this property is always `click`."""

    x: Required[int]
    """The x-coordinate where the click occurred."""

    y: Required[int]
    """The y-coordinate where the click occurred."""


class InputInputItemListComputerToolCallActionDoubleClickAction(TypedDict, total=False):
    """A double click action."""

    type: Required[Literal["double_click"]]
    """Specifies the event type.

    For a double click action, this property is always set to `double_click`.
    """

    x: Required[int]
    """The x-coordinate where the double click occurred."""

    y: Required[int]
    """The y-coordinate where the double click occurred."""


class InputInputItemListComputerToolCallActionDragPath(TypedDict, total=False):
    """An x/y coordinate pair, e.g. `{ x: 100, y: 200 }`."""

    x: Required[int]
    """The x-coordinate."""

    y: Required[int]
    """The y-coordinate."""


class InputInputItemListComputerToolCallActionDrag(TypedDict, total=False):
    """A drag action."""

    path: Required[Iterable[InputInputItemListComputerToolCallActionDragPath]]
    """An array of coordinates representing the path of the drag action.

    Coordinates will appear as an array of objects, eg [{ x: 100, y: 200 }, { x:
    200, y: 300 }]
    """

    type: Required[Literal["drag"]]
    """Specifies the event type.

    For a drag action, this property is always set to `drag`.
    """


class InputInputItemListComputerToolCallActionKeyPressAction(TypedDict, total=False):
    """A collection of keypresses the model would like to perform."""

    keys: Required[SequenceNotStr[str]]
    """The combination of keys the model is requesting to be pressed.

    This is an array of strings, each representing a key.
    """

    type: Required[Literal["keypress"]]
    """Specifies the event type.

    For a keypress action, this property is always set to `keypress`.
    """


class InputInputItemListComputerToolCallActionMove(TypedDict, total=False):
    """A mouse move action."""

    type: Required[Literal["move"]]
    """Specifies the event type.

    For a move action, this property is always set to `move`.
    """

    x: Required[int]
    """The x-coordinate to move to."""

    y: Required[int]
    """The y-coordinate to move to."""


class InputInputItemListComputerToolCallActionScreenshot(TypedDict, total=False):
    """A screenshot action."""

    type: Required[Literal["screenshot"]]
    """Specifies the event type.

    For a screenshot action, this property is always set to `screenshot`.
    """


class InputInputItemListComputerToolCallActionScroll(TypedDict, total=False):
    """A scroll action."""

    scroll_x: Required[int]
    """The horizontal scroll distance."""

    scroll_y: Required[int]
    """The vertical scroll distance."""

    type: Required[Literal["scroll"]]
    """Specifies the event type.

    For a scroll action, this property is always set to `scroll`.
    """

    x: Required[int]
    """The x-coordinate where the scroll occurred."""

    y: Required[int]
    """The y-coordinate where the scroll occurred."""


class InputInputItemListComputerToolCallActionType(TypedDict, total=False):
    """An action to type in text."""

    text: Required[str]
    """The text to type."""

    type: Required[Literal["type"]]
    """Specifies the event type.

    For a type action, this property is always set to `type`.
    """


class InputInputItemListComputerToolCallActionWait(TypedDict, total=False):
    """A wait action."""

    type: Required[Literal["wait"]]
    """Specifies the event type.

    For a wait action, this property is always set to `wait`.
    """


InputInputItemListComputerToolCallAction: TypeAlias = Union[
    InputInputItemListComputerToolCallActionClickParam,
    InputInputItemListComputerToolCallActionDoubleClickAction,
    InputInputItemListComputerToolCallActionDrag,
    InputInputItemListComputerToolCallActionKeyPressAction,
    InputInputItemListComputerToolCallActionMove,
    InputInputItemListComputerToolCallActionScreenshot,
    InputInputItemListComputerToolCallActionScroll,
    InputInputItemListComputerToolCallActionType,
    InputInputItemListComputerToolCallActionWait,
]


class InputInputItemListComputerToolCallPendingSafetyCheck(TypedDict, total=False):
    """A pending safety check for the computer call."""

    id: Required[str]
    """The ID of the pending safety check."""

    code: str
    """The type of the pending safety check."""

    message: str
    """Details about the pending safety check."""


class InputInputItemListComputerToolCall(TypedDict, total=False):
    """A tool call to a computer use tool."""

    id: Required[str]
    """The unique ID of the computer call."""

    action: Required[InputInputItemListComputerToolCallAction]
    """A click action."""

    call_id: Required[str]
    """An identifier used when responding to the tool call with output."""

    pending_safety_checks: Required[Iterable[InputInputItemListComputerToolCallPendingSafetyCheck]]
    """The pending safety checks for the computer call."""

    status: Required[Literal["in_progress", "completed", "incomplete"]]
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """

    type: Required[Literal["computer_call"]]
    """The type of the computer call. Always `computer_call`."""


class InputInputItemListComputerCallOutputItemParamOutput(TypedDict, total=False):
    """A computer screenshot image used with the computer use tool."""

    type: Required[Literal["computer_screenshot"]]
    """Specifies the event type.

    For a computer screenshot, this property is always set to
    `computer_screenshot`.`.
    """

    file_id: str
    """The identifier of an uploaded file that contains the screenshot."""

    image_url: str
    """The URL of the screenshot image."""


class InputInputItemListComputerCallOutputItemParamAcknowledgedSafetyCheck(TypedDict, total=False):
    """A pending safety check for the computer call."""

    id: Required[str]
    """The ID of the pending safety check."""

    code: str
    """The type of the pending safety check."""

    message: str
    """Details about the pending safety check."""


class InputInputItemListComputerCallOutputItemParam(TypedDict, total=False):
    """The output of a computer tool call."""

    call_id: Required[str]
    """The ID of the computer tool call that produced the output."""

    output: Required[InputInputItemListComputerCallOutputItemParamOutput]
    """A computer screenshot image used with the computer use tool."""

    type: Required[Literal["computer_call_output"]]
    """The type of the computer tool call output. Always `computer_call_output`."""

    id: str
    """The ID of the computer tool call output."""

    acknowledged_safety_checks: Iterable[InputInputItemListComputerCallOutputItemParamAcknowledgedSafetyCheck]
    """
    The safety checks reported by the API that have been acknowledged by the
    developer.
    """

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the message input.

    One of `in_progress`, `completed`, or `incomplete`. Populated when input items
    are returned via API.
    """


class InputInputItemListWebSearchToolCallActionWebSearchActionSearchSource(TypedDict, total=False):
    type: Required[Literal["url"]]
    """The type of source. Always `url`."""

    url: Required[str]
    """The URL of the source."""


class InputInputItemListWebSearchToolCallActionWebSearchActionSearch(TypedDict, total=False):
    """Action type "search" - Performs a web search query."""

    query: Required[str]
    """The search query."""

    type: Required[Literal["search"]]
    """The action type."""

    sources: Iterable[InputInputItemListWebSearchToolCallActionWebSearchActionSearchSource]
    """The sources used in the search."""


class InputInputItemListWebSearchToolCallActionWebSearchActionOpenPage(TypedDict, total=False):
    """Action type "open_page" - Opens a specific URL from search results."""

    type: Required[Literal["open_page"]]
    """The action type."""

    url: Required[str]
    """The URL opened by the model."""


class InputInputItemListWebSearchToolCallActionWebSearchActionFind(TypedDict, total=False):
    """Action type "find": Searches for a pattern within a loaded page."""

    pattern: Required[str]
    """The pattern or text to search for within the page."""

    type: Required[Literal["find"]]
    """The action type."""

    url: Required[str]
    """The URL of the page searched for the pattern."""


InputInputItemListWebSearchToolCallAction: TypeAlias = Union[
    InputInputItemListWebSearchToolCallActionWebSearchActionSearch,
    InputInputItemListWebSearchToolCallActionWebSearchActionOpenPage,
    InputInputItemListWebSearchToolCallActionWebSearchActionFind,
]


class InputInputItemListWebSearchToolCall(TypedDict, total=False):
    """The results of a web search tool call."""

    id: Required[str]
    """The unique ID of the web search tool call."""

    action: Required[InputInputItemListWebSearchToolCallAction]
    """The action performed by the web search tool call."""

    status: Required[Literal["in_progress", "searching", "completed", "failed"]]
    """The status of the web search tool call."""

    type: Required[Literal["web_search_call"]]
    """The type of the web search tool call. Always `web_search_call`."""


class InputInputItemListFunctionToolCall(TypedDict, total=False):
    """A tool call to run a function."""

    arguments: Required[str]
    """A JSON string of the arguments to pass to the function."""

    call_id: Required[str]
    """The unique ID of the function tool call generated by the model."""

    name: Required[str]
    """The name of the function to run."""

    type: Required[Literal["function_call"]]
    """The type of the function tool call. Always `function_call`."""

    id: str
    """The unique ID of the function tool call."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """


class InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputTextContent(TypedDict, total=False):
    """A text input to the model."""

    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputImageContent(TypedDict, total=False):
    """An image input to the model."""

    detail: Required[Literal["low", "high", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: str
    """The ID of the file to be sent to the model."""

    image_url: str
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputFileContent(TypedDict, total=False):
    """A file input to the model."""

    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_url: str
    """The URL of the file to be sent to the model."""

    filename: str
    """The name of the file to be sent to the model."""


InputInputItemListFunctionCallOutputItemParamOutputArrayOutput: TypeAlias = Union[
    InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputTextContent,
    InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputImageContent,
    InputInputItemListFunctionCallOutputItemParamOutputArrayOutputInputFileContent,
]


class InputInputItemListFunctionCallOutputItemParam(TypedDict, total=False):
    """The output of a function tool call."""

    call_id: Required[str]
    """The unique ID of the function tool call generated by the model."""

    output: Required[Union[str, Iterable[InputInputItemListFunctionCallOutputItemParamOutputArrayOutput]]]
    """Text, image, or file output of the function tool call."""

    type: Required[Literal["function_call_output"]]
    """The type of the function tool call output. Always `function_call_output`."""

    id: str
    """The unique ID of the function tool call output.

    Populated when this item is returned via API.
    """

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """


class InputInputItemListReasoningItemSummary(TypedDict, total=False):
    """A summary text from the model."""

    text: Required[str]
    """A summary of the reasoning output from the model so far."""

    type: Required[Literal["summary_text"]]
    """The type of the object. Always `summary_text`."""


class InputInputItemListReasoningItemContent(TypedDict, total=False):
    """Reasoning text from the model."""

    text: Required[str]
    """The reasoning text from the model."""

    type: Required[Literal["reasoning_text"]]
    """The type of the reasoning text. Always `reasoning_text`."""


class InputInputItemListReasoningItem(TypedDict, total=False):
    """
    A description of the chain of thought used by a reasoning model while generating a response.
    """

    id: Required[str]
    """The unique identifier of the reasoning content."""

    summary: Required[Iterable[InputInputItemListReasoningItemSummary]]
    """Reasoning summary content."""

    type: Required[Literal["reasoning"]]
    """The type of the object. Always `reasoning`."""

    content: Iterable[InputInputItemListReasoningItemContent]
    """Reasoning text content."""

    encrypted_content: str
    """
    The encrypted content of the reasoning item - populated when a response is
    generated with `reasoning.encrypted_content` in the `include` parameter.
    """

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """


class InputInputItemListCompactionSummaryItemParam(TypedDict, total=False):
    """A compaction item"""

    encrypted_content: Required[str]

    type: Required[Literal["compaction"]]
    """The type of the item. Always `compaction`."""

    id: str
    """The ID of the compaction item."""


class InputInputItemListImageGenToolCall(TypedDict, total=False):
    """An image generation request made by the model."""

    id: Required[str]
    """The unique ID of the image generation call."""

    result: Required[str]
    """The generated image encoded in base64."""

    status: Required[Literal["in_progress", "completed", "generating", "failed"]]
    """The status of the image generation call."""

    type: Required[Literal["image_generation_call"]]
    """The type of the image generation call. Always `image_generation_call`."""


class InputInputItemListCodeInterpreterToolCallOutputCodeInterpreterOutputLogs(TypedDict, total=False):
    """The logs output from the code interpreter."""

    logs: Required[str]
    """The logs output from the code interpreter."""

    type: Required[Literal["logs"]]
    """The type of the output. Always `logs`."""


class InputInputItemListCodeInterpreterToolCallOutputCodeInterpreterOutputImage(TypedDict, total=False):
    """The image output from the code interpreter."""

    type: Required[Literal["image"]]
    """The type of the output. Always `image`."""

    url: Required[str]
    """The URL of the image output from the code interpreter."""


InputInputItemListCodeInterpreterToolCallOutput: TypeAlias = Union[
    InputInputItemListCodeInterpreterToolCallOutputCodeInterpreterOutputLogs,
    InputInputItemListCodeInterpreterToolCallOutputCodeInterpreterOutputImage,
]


class InputInputItemListCodeInterpreterToolCall(TypedDict, total=False):
    """A tool call to run code."""

    id: Required[str]
    """The unique ID of the code interpreter tool call."""

    code: Required[str]
    """The code to run, or null if not available."""

    container_id: Required[str]
    """The ID of the container used to run the code."""

    outputs: Required[Iterable[InputInputItemListCodeInterpreterToolCallOutput]]
    """The outputs generated by the code interpreter, such as logs or images.

    Can be null if no outputs are available.
    """

    status: Required[Literal["in_progress", "completed", "incomplete", "interpreting", "failed"]]
    """The status of the code interpreter tool call.

    Valid values are `in_progress`, `completed`, `incomplete`, `interpreting`, and
    `failed`.
    """

    type: Required[Literal["code_interpreter_call"]]
    """The type of the code interpreter tool call. Always `code_interpreter_call`."""


class InputInputItemListLocalShellToolCallAction(TypedDict, total=False):
    """Execute a shell command on the server."""

    command: Required[SequenceNotStr[str]]
    """The command to run."""

    env: Required[Dict[str, str]]
    """Environment variables to set for the command."""

    type: Required[Literal["exec"]]
    """The type of the local shell action. Always `exec`."""

    timeout_ms: int
    """Optional timeout in milliseconds for the command."""

    user: str
    """Optional user to run the command as."""

    working_directory: str
    """Optional working directory to run the command in."""


class InputInputItemListLocalShellToolCall(TypedDict, total=False):
    """A tool call to run a command on the local shell."""

    id: Required[str]
    """The unique ID of the local shell call."""

    action: Required[InputInputItemListLocalShellToolCallAction]
    """Execute a shell command on the server."""

    call_id: Required[str]
    """The unique ID of the local shell tool call generated by the model."""

    status: Required[Literal["in_progress", "completed", "incomplete"]]
    """The status of the local shell call."""

    type: Required[Literal["local_shell_call"]]
    """The type of the local shell call. Always `local_shell_call`."""


class InputInputItemListLocalShellToolCallOutput(TypedDict, total=False):
    """The output of a local shell tool call."""

    id: Required[str]
    """The unique ID of the local shell tool call generated by the model."""

    call_id: Required[str]
    """The unique ID of the local shell tool call generated by the model."""

    output: Required[str]
    """A JSON string of the output of the local shell tool call."""

    type: Required[Literal["local_shell_call_output"]]
    """The type of the local shell tool call output. Always `local_shell_call_output`."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the item. One of `in_progress`, `completed`, or `incomplete`."""


class InputInputItemListFunctionShellCallItemParamAction(TypedDict, total=False):
    """Commands and limits describing how to run the shell tool call."""

    commands: Required[SequenceNotStr[str]]
    """Ordered shell commands for the execution environment to run."""

    max_output_length: int
    """
    Maximum number of UTF-8 characters to capture from combined stdout and stderr
    output.
    """

    timeout_ms: int
    """Maximum wall-clock time in milliseconds to allow the shell commands to run."""


class InputInputItemListFunctionShellCallItemParam(TypedDict, total=False):
    """A tool representing a request to execute one or more shell commands."""

    action: Required[InputInputItemListFunctionShellCallItemParamAction]
    """Commands and limits describing how to run the shell tool call."""

    call_id: Required[str]
    """The unique ID of the shell tool call generated by the model."""

    type: Required[Literal["shell_call"]]
    """The type of the item. Always `shell_call`."""

    id: str
    """The unique ID of the shell tool call.

    Populated when this item is returned via API.
    """

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the shell call.

    One of `in_progress`, `completed`, or `incomplete`.
    """


class InputInputItemListFunctionShellCallOutputItemParamOutputOutcomeShellCallTimeoutOutcome(TypedDict, total=False):
    """Indicates that the shell call exceeded its configured time limit."""

    type: Required[Literal["timeout"]]
    """The outcome type. Always `timeout`."""


class InputInputItemListFunctionShellCallOutputItemParamOutputOutcomeShellCallExitOutcome(TypedDict, total=False):
    """Indicates that the shell commands finished and returned an exit code."""

    type: Required[Literal["exit"]]
    """The outcome type. Always `exit`."""

    exit_code: int
    """The exit code returned by the shell process."""


InputInputItemListFunctionShellCallOutputItemParamOutputOutcome: TypeAlias = Union[
    InputInputItemListFunctionShellCallOutputItemParamOutputOutcomeShellCallTimeoutOutcome,
    InputInputItemListFunctionShellCallOutputItemParamOutputOutcomeShellCallExitOutcome,
]


class InputInputItemListFunctionShellCallOutputItemParamOutput(TypedDict, total=False):
    """Captured stdout and stderr for a portion of a shell tool call output."""

    outcome: Required[InputInputItemListFunctionShellCallOutputItemParamOutputOutcome]
    """Indicates that the shell call exceeded its configured time limit."""

    stderr: Required[str]
    """Captured stderr output for the shell call."""

    stdout: Required[str]
    """Captured stdout output for the shell call."""


class InputInputItemListFunctionShellCallOutputItemParam(TypedDict, total=False):
    """The streamed output items emitted by a shell tool call."""

    call_id: Required[str]
    """The unique ID of the shell tool call generated by the model."""

    output: Required[Iterable[InputInputItemListFunctionShellCallOutputItemParamOutput]]
    """
    Captured chunks of stdout and stderr output, along with their associated
    outcomes.
    """

    type: Required[Literal["shell_call_output"]]
    """The type of the item. Always `shell_call_output`."""

    id: str
    """The unique ID of the shell tool call output.

    Populated when this item is returned via API.
    """

    max_output_length: int
    """
    The maximum number of UTF-8 characters captured for this shell call's combined
    output.
    """


class InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchCreateFileOperation(TypedDict, total=False):
    """Instruction for creating a new file via the apply_patch tool."""

    diff: Required[str]
    """Unified diff content to apply when creating the file."""

    path: Required[str]
    """Path of the file to create relative to the workspace root."""

    type: Required[Literal["create_file"]]
    """The operation type. Always `create_file`."""


class InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchDeleteFileOperation(TypedDict, total=False):
    """Instruction for deleting an existing file via the apply_patch tool."""

    path: Required[str]
    """Path of the file to delete relative to the workspace root."""

    type: Required[Literal["delete_file"]]
    """The operation type. Always `delete_file`."""


class InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchUpdateFileOperation(TypedDict, total=False):
    """Instruction for updating an existing file via the apply_patch tool."""

    diff: Required[str]
    """Unified diff content to apply to the existing file."""

    path: Required[str]
    """Path of the file to update relative to the workspace root."""

    type: Required[Literal["update_file"]]
    """The operation type. Always `update_file`."""


InputInputItemListApplyPatchToolCallItemParamOperation: TypeAlias = Union[
    InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchCreateFileOperation,
    InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchDeleteFileOperation,
    InputInputItemListApplyPatchToolCallItemParamOperationApplyPatchUpdateFileOperation,
]


class InputInputItemListApplyPatchToolCallItemParam(TypedDict, total=False):
    """
    A tool call representing a request to create, delete, or update files using diff patches.
    """

    call_id: Required[str]
    """The unique ID of the apply patch tool call generated by the model."""

    operation: Required[InputInputItemListApplyPatchToolCallItemParamOperation]
    """
    The specific create, delete, or update instruction for the apply_patch tool
    call.
    """

    status: Required[Literal["in_progress", "completed"]]
    """The status of the apply patch tool call. One of `in_progress` or `completed`."""

    type: Required[Literal["apply_patch_call"]]
    """The type of the item. Always `apply_patch_call`."""

    id: str
    """The unique ID of the apply patch tool call.

    Populated when this item is returned via API.
    """


class InputInputItemListApplyPatchToolCallOutputItemParam(TypedDict, total=False):
    """The streamed output emitted by an apply patch tool call."""

    call_id: Required[str]
    """The unique ID of the apply patch tool call generated by the model."""

    status: Required[Literal["completed", "failed"]]
    """The status of the apply patch tool call output. One of `completed` or `failed`."""

    type: Required[Literal["apply_patch_call_output"]]
    """The type of the item. Always `apply_patch_call_output`."""

    id: str
    """The unique ID of the apply patch tool call output.

    Populated when this item is returned via API.
    """

    output: str
    """
    Optional human-readable log text from the apply patch tool (e.g., patch results
    or errors).
    """


class InputInputItemListMcpListToolsTool(TypedDict, total=False):
    """A tool available on an MCP server."""

    input_schema: Required[Dict[str, object]]
    """The JSON schema describing the tool's input."""

    name: Required[str]
    """The name of the tool."""

    annotations: Dict[str, object]
    """Additional annotations about the tool."""

    description: str
    """The description of the tool."""


class InputInputItemListMcpListTools(TypedDict, total=False):
    """A list of tools available on an MCP server."""

    id: Required[str]
    """The unique ID of the list."""

    server_label: Required[str]
    """The label of the MCP server."""

    tools: Required[Iterable[InputInputItemListMcpListToolsTool]]
    """The tools available on the server."""

    type: Required[Literal["mcp_list_tools"]]
    """The type of the item. Always `mcp_list_tools`."""


class InputInputItemListMcpApprovalRequest(TypedDict, total=False):
    """A request for human approval of a tool invocation."""

    id: Required[str]
    """The unique ID of the approval request."""

    arguments: Required[str]
    """A JSON string of arguments for the tool."""

    name: Required[str]
    """The name of the tool to run."""

    server_label: Required[str]
    """The label of the MCP server making the request."""

    type: Required[Literal["mcp_approval_request"]]
    """The type of the item. Always `mcp_approval_request`."""


class InputInputItemListMcpApprovalResponse(TypedDict, total=False):
    """A response to an MCP approval request."""

    approval_request_id: Required[bool]
    """The ID of the approval request being answered."""

    approve: Required[bool]
    """Whether the request was approved."""

    type: Required[Literal["mcp_approval_response"]]
    """The type of the item. Always `mcp_approval_response`."""

    id: str
    """The unique ID of the approval response"""

    reason: str
    """Optional reason for the decision."""


class InputInputItemListMcpToolCall(TypedDict, total=False):
    """An invocation of a tool on an MCP server."""

    id: Required[str]
    """The unique ID of the tool call."""

    arguments: Required[str]
    """A JSON string of the arguments passed to the tool."""

    name: Required[str]
    """The name of the tool that was run."""

    server_label: Required[str]
    """The label of the MCP server running the tool."""

    type: Required[Literal["mcp_call"]]
    """The type of the item. Always `mcp_call`."""

    approval_request_id: str
    """Unique identifier for the MCP tool call approval request.

    Include this value in a subsequent `mcp_approval_response` input to approve or
    reject the corresponding tool call.
    """

    error: str
    """The error from the tool call, if any."""

    output: str
    """The output from the tool call."""

    status: Literal["in_progress", "completed", "incomplete", "calling", "failed"]
    """The status of the tool call.

    One of `in_progress`, `completed`, `incomplete`, `calling`, or `failed`.
    """


class InputInputItemListCustomToolCallOutputOutputOutputContentListInputTextContent(TypedDict, total=False):
    """A text input to the model."""

    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class InputInputItemListCustomToolCallOutputOutputOutputContentListInputImageContent(TypedDict, total=False):
    """An image input to the model."""

    detail: Required[Literal["low", "high", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: str
    """The ID of the file to be sent to the model."""

    image_url: str
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListCustomToolCallOutputOutputOutputContentListInputFileContent(TypedDict, total=False):
    """A file input to the model."""

    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_url: str
    """The URL of the file to be sent to the model."""

    filename: str
    """The name of the file to be sent to the model."""


InputInputItemListCustomToolCallOutputOutputOutputContentList: TypeAlias = Union[
    InputInputItemListCustomToolCallOutputOutputOutputContentListInputTextContent,
    InputInputItemListCustomToolCallOutputOutputOutputContentListInputImageContent,
    InputInputItemListCustomToolCallOutputOutputOutputContentListInputFileContent,
]


class InputInputItemListCustomToolCallOutput(TypedDict, total=False):
    """The output of a custom tool call from your code, being sent back to the model."""

    call_id: Required[str]
    """The call ID, used to map this custom tool call output to a custom tool call."""

    output: Required[Union[str, Iterable[InputInputItemListCustomToolCallOutputOutputOutputContentList]]]
    """The output from the custom tool call generated by your code.

    Can be a string or an list of output content.
    """

    type: Required[Literal["custom_tool_call_output"]]
    """The type of the custom tool call output. Always `custom_tool_call_output`."""

    id: str
    """The unique ID of the custom tool call output in the OpenAI platform."""


class InputInputItemListCustomToolCall(TypedDict, total=False):
    """A call to a custom tool created by the model."""

    call_id: Required[str]
    """An identifier used to map this custom tool call to a tool call output."""

    input: Required[str]
    """The input for the custom tool call generated by the model."""

    name: Required[str]
    """The name of the custom tool being called."""

    type: Required[Literal["custom_tool_call"]]
    """The type of the custom tool call. Always `custom_tool_call`."""

    id: str
    """The unique ID of the custom tool call in the OpenAI platform."""


class InputInputItemListItemReferenceParam(TypedDict, total=False):
    """An internal identifier for an item to reference."""

    id: Required[str]
    """The ID of the item to reference."""

    type: Literal["item_reference"]
    """The type of item to reference. Always `item_reference`."""


InputInputItemList: TypeAlias = Union[
    InputInputItemListEasyInputMessage,
    InputInputItemListInputMessage,
    InputInputItemListOutputMessage,
    InputInputItemListFileSearchToolCall,
    InputInputItemListComputerToolCall,
    InputInputItemListComputerCallOutputItemParam,
    InputInputItemListWebSearchToolCall,
    InputInputItemListFunctionToolCall,
    InputInputItemListFunctionCallOutputItemParam,
    InputInputItemListReasoningItem,
    InputInputItemListCompactionSummaryItemParam,
    InputInputItemListImageGenToolCall,
    InputInputItemListCodeInterpreterToolCall,
    InputInputItemListLocalShellToolCall,
    InputInputItemListLocalShellToolCallOutput,
    InputInputItemListFunctionShellCallItemParam,
    InputInputItemListFunctionShellCallOutputItemParam,
    InputInputItemListApplyPatchToolCallItemParam,
    InputInputItemListApplyPatchToolCallOutputItemParam,
    InputInputItemListMcpListTools,
    InputInputItemListMcpApprovalRequest,
    InputInputItemListMcpApprovalResponse,
    InputInputItemListMcpToolCall,
    InputInputItemListCustomToolCallOutput,
    InputInputItemListCustomToolCall,
    InputInputItemListItemReferenceParam,
]


class PromptVariablesInputTextContent(TypedDict, total=False):
    """A text input to the model."""

    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class PromptVariablesInputImageContent(TypedDict, total=False):
    """An image input to the model."""

    detail: Required[Literal["low", "high", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: str
    """The ID of the file to be sent to the model."""

    image_url: str
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class PromptVariablesInputFileContent(TypedDict, total=False):
    """A file input to the model."""

    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_url: str
    """The URL of the file to be sent to the model."""

    filename: str
    """The name of the file to be sent to the model."""


PromptVariables: TypeAlias = Union[
    str, PromptVariablesInputTextContent, PromptVariablesInputImageContent, PromptVariablesInputFileContent
]


class Prompt(TypedDict, total=False):
    """Reference to a prompt template and its variables."""

    id: Required[str]
    """The unique identifier of the prompt template to use."""

    variables: Dict[str, PromptVariables]
    """Optional map of values to substitute in for variables in your prompt.

    The substitution values can either be strings, or other Response input types
    like images or files.
    """

    version: str
    """Optional version of the prompt template."""


class Reasoning(TypedDict, total=False):
    """Configuration options for reasoning models."""

    effort: Literal["low", "medium", "high"]
    """Constrains effort on reasoning for reasoning models."""


class TextFormatResponseFormatText(TypedDict, total=False):
    """Default response format. Used to generate text responses."""

    type: Required[Literal["text"]]
    """The type of response format being defined. Always `text`."""


class TextFormatTextResponseFormatJsonSchema(TypedDict, total=False):
    """JSON Schema response format. Used to generate structured JSON responses."""

    name: Required[str]
    """The name of the response format.

    Must be a-z, A-Z, 0-9, or contain underscores and dashes, with a maximum length
    of 64.
    """

    schema: Required[Dict[str, object]]
    """The schema for the response format, described as a JSON Schema object."""

    type: Required[Literal["json_schema"]]
    """The type of response format being defined. Always `json_schema`."""

    description: str
    """
    A description of what the response format is for, used by the model to determine
    how to respond in the format.
    """

    strict: bool
    """Whether to enable strict schema adherence when generating the output.

    If set to true, the model will always follow the exact schema defined in the
    `schema` field. Only a subset of JSON Schema is supported when `strict` is
    `true`.
    """


class TextFormatResponseFormatJsonObject(TypedDict, total=False):
    """JSON object response format.

    An older method of generating JSON responses. Using `json_schema` is recommended for models that support it. Note that the model will not generate JSON without a system or user message instructing it to do so.
    """

    type: Required[Literal["json_object"]]
    """The type of response format being defined. Always `json_object`."""


TextFormat: TypeAlias = Union[
    TextFormatResponseFormatText, TextFormatTextResponseFormatJsonSchema, TextFormatResponseFormatJsonObject
]


class Text(TypedDict, total=False):
    """Configuration options for a text response from the model.

    Can be plain text or structured JSON data.
    """

    format: TextFormat
    """An object specifying the format that the model must output."""

    verbosity: Literal["low", "medium", "high"]
    """Constrains the verbosity of the model's response.

    Lower values will result in more concise responses, while higher values will
    result in more verbose responses.
    """


class ToolChoiceToolChoiceAllowed(TypedDict, total=False):
    """Constrains the tools available to the model to a pre-defined set."""

    mode: Required[Literal["auto", "required"]]
    """Constrains the tools available to the model to a pre-defined set."""

    tools: Required[Iterable[Dict[str, object]]]
    """A list of tool definitions that the model should be allowed to call."""

    type: Required[Literal["allowed_tools"]]
    """Allowed tool configuration type. Always `allowed_tools`."""


class ToolChoiceToolChoiceTypes(TypedDict, total=False):
    """Indicates that the model should use a built-in tool to generate a response."""

    type: Required[
        Literal[
            "file_search",
            "web_search_preview",
            "computer_use_preview",
            "web_search_preview_2025_03_11",
            "image_generation",
            "code_interpreter",
        ]
    ]
    """Types tool configuration type. Always `types`."""


class ToolChoiceToolChoiceFunction(TypedDict, total=False):
    """Use this option to force the model to call a specific function."""

    name: Required[str]
    """The name of the function to call."""

    type: Required[Literal["function"]]
    """For function calling, the type is always `function`."""


class ToolChoiceToolChoiceMcp(TypedDict, total=False):
    """
    Use this option to force the model to call a specific tool on a remote MCP server.
    """

    server_label: Required[str]
    """The label of the MCP server to use."""

    type: Required[Literal["mcp"]]
    """For MCP tools, the type is always `mcp`."""

    name: str
    """The name of the tool to call on the server."""


class ToolChoiceToolChoiceCustom(TypedDict, total=False):
    """Use this option to force the model to call a specific custom tool."""

    name: Required[str]
    """The name of the custom tool to call."""

    type: Required[Literal["custom"]]
    """For custom tool calling, the type is always `custom`."""


class ToolChoiceSpecificApplyPatchParam(TypedDict, total=False):
    """Forces the model to call the apply_patch tool when executing a tool call."""

    type: Required[Literal["apply_patch"]]
    """The tool to call. Always `apply_patch`."""


class ToolChoiceSpecificFunctionShellParam(TypedDict, total=False):
    """Forces the model to call the shell tool when a tool call is required."""

    type: Required[Literal["shell"]]
    """The tool to call. Always `shell`."""


ToolChoice: TypeAlias = Union[
    Literal["none", "auto", "required"],
    ToolChoiceToolChoiceAllowed,
    ToolChoiceToolChoiceTypes,
    ToolChoiceToolChoiceFunction,
    ToolChoiceToolChoiceMcp,
    ToolChoiceToolChoiceCustom,
    ToolChoiceSpecificApplyPatchParam,
    ToolChoiceSpecificFunctionShellParam,
]


class ToolFunctionTool(TypedDict, total=False):
    """Defines a function in your own code the model can choose to call."""

    name: Required[str]
    """The name of the function to call."""

    parameters: Required[Dict[str, object]]
    """A JSON schema object describing the parameters of the function."""

    strict: Required[bool]
    """Whether to enforce strict parameter validation. Default `true`."""

    type: Required[Literal["function"]]
    """The type of the function tool. Always `function`."""

    description: str
    """A description of the function.

    Used by the model to determine whether or not to call the function.
    """


class ToolFileSearchToolFiltersComparisonFilter(TypedDict, total=False):
    """
    A filter used to compare a specified attribute key to a given value using a defined comparison operation.
    """

    key: Required[str]
    """The key to compare against the value."""

    type: Required[Literal["eq", "ne", "gt", "gte", "lt", "lte"]]
    """
    Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`,
    `nin`.
    """

    value: Required[Union[str, float, bool, SequenceNotStr[Union[str, float]]]]
    """
    The value to compare against the attribute key; supports string, number, or
    boolean types.
    """


ToolFileSearchToolFilters: TypeAlias = Union[ToolFileSearchToolFiltersComparisonFilter, "CompoundFilter"]


class ToolFileSearchToolRankingOptionsHybridSearch(TypedDict, total=False):
    """
    Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.
    """

    embedding_weight: Required[float]
    """The weight of the embedding in the reciprocal ranking fusion."""

    text_weight: Required[float]
    """The weight of the text in the reciprocal ranking fusion."""


class ToolFileSearchToolRankingOptions(TypedDict, total=False):
    """Ranking options for search."""

    hybrid_search: ToolFileSearchToolRankingOptionsHybridSearch
    """
    Weights that control how reciprocal rank fusion balances semantic embedding
    matches versus sparse keyword matches when hybrid search is enabled.
    """

    ranker: Literal["auto", "default-2024-11-15"]
    """The ranker to use for the file search."""

    score_threshold: float
    """The score threshold for the file search, a number between 0 and 1.

    Numbers closer to 1 will attempt to return only the most relevant results, but
    may return fewer results.
    """


class ToolFileSearchTool(TypedDict, total=False):
    """A tool that searches for relevant content from uploaded files."""

    type: Required[Literal["file_search"]]
    """The type of the file search tool. Always `file_search`."""

    vector_store_ids: Required[SequenceNotStr[str]]
    """The IDs of the vector stores to search."""

    filters: ToolFileSearchToolFilters
    """A filter to apply."""

    max_num_results: int
    """The maximum number of results to return.

    This number should be between 1 and 50 inclusive.
    """

    ranking_options: ToolFileSearchToolRankingOptions
    """Ranking options for search."""


class ToolComputerUsePreviewTool(TypedDict, total=False):
    """A tool that controls a virtual computer."""

    display_height: Required[int]
    """The height of the computer display."""

    display_width: Required[int]
    """The width of the computer display."""

    environment: Required[Literal["windows", "mac", "linux", "ubuntu", "browser"]]
    """The type of computer environment to control."""

    type: Required[Literal["computer_use_preview"]]
    """The type of the computer use tool. Always `computer_use_preview`."""


class ToolWebSearchToolFilters(TypedDict, total=False):
    """Filters for the search."""

    allowed_domains: SequenceNotStr[str]
    """Allowed domains for the search.

    If not provided, all domains are allowed. Subdomains of the provided domains are
    allowed as well.
    """


class ToolWebSearchToolUserLocation(TypedDict, total=False):
    """The approximate location of the user."""

    city: str
    """Free text input for the city of the user, e.g. `San Francisco`."""

    country: str
    """
    The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of
    the user, e.g. `US`.
    """

    region: str
    """Free text input for the region of the user, e.g. `California`."""

    timezone: str
    """
    The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the
    user, e.g. `America/Los_Angeles`.
    """

    type: Literal["approximate"]
    """The type of location approximation. Always `approximate`."""


class ToolWebSearchTool(TypedDict, total=False):
    """Search the Internet for sources related to the prompt."""

    type: Required[Literal["web_search", "web_search_2025_08_26"]]
    """The type of the web search tool.

    One of `web_search` or `web_search_2025_08_26`.
    """

    filters: ToolWebSearchToolFilters
    """Filters for the search."""

    search_context_size: Literal["low", "medium", "high"]
    """High level guidance for the amount of context window space to use for the
    search.

    One of `low`, `medium`, or `high`. `medium` is the default.
    """

    user_location: ToolWebSearchToolUserLocation
    """The approximate location of the user."""


class ToolMcpToolAllowedToolsMcpToolFilter(TypedDict, total=False):
    """A filter object to specify which tools are allowed."""

    read_only: bool
    """Indicates whether or not a tool modifies data or is read-only."""

    tool_names: SequenceNotStr[str]
    """List of allowed tool names."""


ToolMcpToolAllowedTools: TypeAlias = Union[SequenceNotStr[str], ToolMcpToolAllowedToolsMcpToolFilter]


class ToolMcpToolRequireApprovalMcpToolApprovalFilterAlways(TypedDict, total=False):
    """A filter object to specify which tools are allowed."""

    read_only: bool
    """Indicates whether or not a tool modifies data or is read-only."""

    tool_names: SequenceNotStr[str]
    """List of allowed tool names."""


class ToolMcpToolRequireApprovalMcpToolApprovalFilterNever(TypedDict, total=False):
    """A filter object to specify which tools are allowed."""

    read_only: bool
    """Indicates whether or not a tool modifies data or is read-only."""

    tool_names: SequenceNotStr[str]
    """List of allowed tool names."""


class ToolMcpToolRequireApprovalMcpToolApprovalFilter(TypedDict, total=False):
    """Specify which of the MCP server's tools require approval.

    Can be `always`, `never`, or a filter object associated with tools that require approval.
    """

    always: ToolMcpToolRequireApprovalMcpToolApprovalFilterAlways
    """A filter object to specify which tools are allowed."""

    never: ToolMcpToolRequireApprovalMcpToolApprovalFilterNever
    """A filter object to specify which tools are allowed."""


ToolMcpToolRequireApproval: TypeAlias = Union[
    ToolMcpToolRequireApprovalMcpToolApprovalFilter, Literal["always", "never"]
]


class ToolMcpTool(TypedDict, total=False):
    """
    Give the model access to additional tools via remote Model Context Protocol (MCP) servers.
    """

    server_label: Required[str]
    """A label for this MCP server, used to identify it in tool calls."""

    type: Required[Literal["mcp"]]
    """The type of the MCP tool. Always `mcp`."""

    allowed_tools: ToolMcpToolAllowedTools
    """List of allowed tool names or a filter object."""

    authorization: str
    """
    An OAuth access token that can be used with a remote MCP server, either with a
    custom MCP server URL or a service connector. Your application must handle the
    OAuth authorization flow and provide the token here.
    """

    connector_id: Literal[
        "connector_dropbox",
        "connector_gmail",
        "connector_googlecalendar",
        "connector_googledrive",
        "connector_microsoftteams",
        "connector_outlookcalendar",
        "connector_outlookemail",
        "connector_sharepoint",
    ]
    """Identifier for service connectors, like those available in ChatGPT.

    One of `server_url` or `connector_id` must be provided.
    """

    headers: Dict[str, str]
    """Optional HTTP headers to send to the MCP server.

    Use for authentication or other purposes.
    """

    require_approval: ToolMcpToolRequireApproval
    """Specify which of the MCP server's tools require approval."""

    server_description: str
    """Optional description of the MCP server, used to provide more context."""

    server_url: str
    """The URL for the MCP server.

    One of `server_url` or `connector_id` must be provided.
    """


class ToolCodeInterpreterToolContainerCodeInterpreterToolAuto(TypedDict, total=False):
    """Configuration for a code interpreter container.

    Optionally specify the IDs of the files to run the code on.
    """

    type: Required[Literal["auto"]]
    """Always `auto`."""

    file_ids: SequenceNotStr[str]
    """An optional list of uploaded files to make available to your code."""

    memory_limit: Literal["1g", "4g", "16g", "64g"]


ToolCodeInterpreterToolContainer: TypeAlias = Union[str, ToolCodeInterpreterToolContainerCodeInterpreterToolAuto]


class ToolCodeInterpreterTool(TypedDict, total=False):
    """A tool that runs Python code to help generate a response to a prompt."""

    container: Required[ToolCodeInterpreterToolContainer]
    """The code interpreter container.

    Can be a container ID or an object that specifies uploaded file IDs to make
    available to your code, along with an optional `memory_limit` setting.
    """

    type: Required[Literal["code_interpreter"]]
    """The type of the code interpreter tool. Always `code_interpreter`."""


class ToolImageGenToolInputImageMask(TypedDict, total=False):
    """Optional mask for inpainting.

    Contains `image_url` (string, optional) and `file_id` (string, optional).
    """

    file_id: str
    """File ID for the mask image."""

    image_url: str
    """Base64-encoded mask image."""


class ToolImageGenTool(TypedDict, total=False):
    """A tool that generates images using the GPT image models."""

    type: Required[Literal["image_generation"]]
    """The type of the image generation tool. Always `image_generation`."""

    background: Literal["transparent", "opaque", "auto"]
    """Background type for the generated image.

    One of `transparent`, `opaque`, or `auto`.
    """

    input_fidelity: Literal["high", "low"]
    """
    Control how much effort the model will exert to match the style and features,
    especially facial features, of input images.
    """

    input_image_mask: ToolImageGenToolInputImageMask
    """Optional mask for inpainting.

    Contains `image_url` (string, optional) and `file_id` (string, optional).
    """

    model: str
    """The image generation model to use."""

    moderation: Literal["auto", "low"]
    """Moderation level for the generated image."""

    output_compression: int
    """Compression level for the output image."""

    output_format: Literal["png", "webp", "jpeg"]
    """The output format of the generated image. One of `png`, `webp`, or `jpeg`."""

    partial_images: int
    """
    Number of partial images to generate in streaming mode, from 0 (default value)
    to 3.
    """

    quality: Literal["low", "medium", "high", "auto"]
    """The quality of the generated image. One of `low`, `medium`, `high`, or `auto`."""

    size: Literal["1024x1024", "1024x1536", "1536x1024", "auto"]
    """The size of the generated image.

    One of `1024x1024`, `1024x1536`, `1536x1024`, or `auto`.
    """


class ToolLocalShellToolParam(TypedDict, total=False):
    """A tool that allows the model to execute shell commands in a local environment."""

    type: Required[Literal["local_shell"]]
    """The type of the local shell tool. Always `local_shell`."""


class ToolFunctionShellToolParam(TypedDict, total=False):
    """A tool that allows the model to execute shell commands."""

    type: Required[Literal["shell"]]
    """The type of the shell tool. Always `shell`."""


class ToolCustomToolParamFormatGrammarFormat(TypedDict, total=False):
    """A grammar defined by the user."""

    definition: Required[str]
    """The grammar definition."""

    syntax: Required[Literal["lark", "regex"]]
    """The syntax of the grammar definition. One of `lark` or `regex`."""

    type: Required[Literal["grammar"]]
    """Grammar format. Always `grammar`."""


ToolCustomToolParamFormat: TypeAlias = Union[Literal["text"], ToolCustomToolParamFormatGrammarFormat]


class ToolCustomToolParam(TypedDict, total=False):
    """A custom tool that processes input using a specified format."""

    name: Required[str]
    """The name of the custom tool, used to identify it in tool calls."""

    type: Required[Literal["custom"]]
    """The type of the custom tool. Always `custom`."""

    description: str
    """Optional description of the custom tool, used to provide more context."""

    format: ToolCustomToolParamFormat
    """The input format for the custom tool. Default is unconstrained text."""


class ToolWebSearchPreviewToolUserLocation(TypedDict, total=False):
    type: Required[Literal["approximate"]]
    """The type of location approximation. Always `approximate`."""

    city: str
    """Free text input for the city of the user, e.g. `San Francisco`."""

    country: str
    """
    The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of
    the user, e.g. `US`.
    """

    region: str
    """Free text input for the region of the user, e.g. `California`."""

    timezone: str
    """
    The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the
    user, e.g. `America/Los_Angeles`.
    """


class ToolWebSearchPreviewTool(TypedDict, total=False):
    """This tool searches the web for relevant results to use in a response."""

    type: Required[Literal["web_search_preview", "web_search_preview_2025_03_11"]]
    """The type of the web search tool.

    One of `web_search_preview` or `web_search_preview_2025_03_11`.
    """

    search_context_size: Literal["low", "medium", "high"]
    """High level guidance for the amount of context window space to use for the
    search.

    One of `low`, `medium`, or `high`. `medium` is the default.
    """

    user_location: ToolWebSearchPreviewToolUserLocation


class ToolApplyPatchToolParam(TypedDict, total=False):
    """Allows the assistant to create, delete, or update files using unified diffs."""

    type: Required[Literal["apply_patch"]]
    """The type of the tool. Always `apply_patch`."""


Tool: TypeAlias = Union[
    ToolFunctionTool,
    ToolFileSearchTool,
    ToolComputerUsePreviewTool,
    ToolWebSearchTool,
    ToolMcpTool,
    ToolCodeInterpreterTool,
    ToolImageGenTool,
    ToolLocalShellToolParam,
    ToolFunctionShellToolParam,
    ToolCustomToolParam,
    ToolWebSearchPreviewTool,
    ToolApplyPatchToolParam,
]

from .shared_params.compound_filter import CompoundFilter
