# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["EndpointHardwareConfig"]


class EndpointHardwareConfig(BaseModel):
    """Snapshot of hardware configuration parameters for the dedicated endpoint."""

    gpu_count: int
    """GPUs allocated, user-selected (snapshot from hardware.specs)."""

    gpu_count_min: int
    """Minimum GPUs required by the model for this GPU type."""

    gpu_link: str
    """Interconnect type (snapshot from hardware.specs)."""

    gpu_memory: int
    """GPU VRAM in GB (snapshot from hardware.specs)."""

    gpu_type: str
    """GPU model (snapshot from hardware.specs)."""

    max_model_len: int
    """Maximum context length for this GPU type."""

    tensor_parallel: int
    """Tensor parallelism degree for this GPU type."""
