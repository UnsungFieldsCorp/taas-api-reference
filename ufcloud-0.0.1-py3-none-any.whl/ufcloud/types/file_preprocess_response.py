# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["FilePreprocessResponse", "File"]


class File(BaseModel):
    created_at: str

    file_id: str

    filename: str

    purpose: str

    status: Literal["pending", "processed"]

    updated_at: str

    line_count: Optional[int] = None

    schema_type: Optional[Literal["messages", "instruction"]] = None

    size_bytes: Optional[int] = None


class FilePreprocessResponse(BaseModel):
    file: File
