# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["FunctionCall"]


class FunctionCall(BaseModel):
    """Deprecated function call information."""

    arguments: str

    name: str
