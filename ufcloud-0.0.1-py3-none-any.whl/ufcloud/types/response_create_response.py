# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import builtins
from typing import Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "ResponseCreateResponse",
    "Output",
    "OutputOutputMessage",
    "OutputOutputMessageContent",
    "OutputOutputMessageContentOutputTextContent",
    "OutputOutputMessageContentOutputTextContentAnnotation",
    "OutputOutputMessageContentOutputTextContentAnnotationFileCitationBody",
    "OutputOutputMessageContentOutputTextContentAnnotationURLCitationBody",
    "OutputOutputMessageContentOutputTextContentAnnotationContainerFileCitationBody",
    "OutputOutputMessageContentOutputTextContentAnnotationFilePath",
    "OutputOutputMessageContentOutputTextContentLogprob",
    "OutputOutputMessageContentOutputTextContentLogprobTopLogprob",
    "OutputOutputMessageContentRefusalContent",
    "OutputFileSearchToolCall",
    "OutputFileSearchToolCallResult",
    "OutputFunctionToolCall",
    "OutputWebSearchToolCall",
    "OutputWebSearchToolCallAction",
    "OutputWebSearchToolCallActionWebSearchActionSearch",
    "OutputWebSearchToolCallActionWebSearchActionSearchSource",
    "OutputWebSearchToolCallActionWebSearchActionOpenPage",
    "OutputWebSearchToolCallActionWebSearchActionFind",
    "OutputComputerToolCall",
    "OutputComputerToolCallAction",
    "OutputComputerToolCallActionClickParam",
    "OutputComputerToolCallActionDoubleClickAction",
    "OutputComputerToolCallActionDrag",
    "OutputComputerToolCallActionDragPath",
    "OutputComputerToolCallActionKeyPressAction",
    "OutputComputerToolCallActionMove",
    "OutputComputerToolCallActionScreenshot",
    "OutputComputerToolCallActionScroll",
    "OutputComputerToolCallActionType",
    "OutputComputerToolCallActionWait",
    "OutputComputerToolCallPendingSafetyCheck",
    "OutputReasoningItem",
    "OutputReasoningItemSummary",
    "OutputReasoningItemContent",
    "OutputCompactionBody",
    "OutputImageGenToolCall",
    "OutputCodeInterpreterToolCall",
    "OutputCodeInterpreterToolCallOutput",
    "OutputCodeInterpreterToolCallOutputCodeInterpreterOutputLogs",
    "OutputCodeInterpreterToolCallOutputCodeInterpreterOutputImage",
    "OutputLocalShellToolCall",
    "OutputLocalShellToolCallAction",
    "OutputFunctionShellCall",
    "OutputFunctionShellCallAction",
    "OutputFunctionShellCallOutput",
    "OutputFunctionShellCallOutputOutput",
    "OutputFunctionShellCallOutputOutputOutcome",
    "OutputFunctionShellCallOutputOutputOutcomeShellCallTimeoutOutcome",
    "OutputFunctionShellCallOutputOutputOutcomeShellCallExitOutcome",
    "OutputApplyPatchToolCall",
    "OutputApplyPatchToolCallOperation",
    "OutputApplyPatchToolCallOperationApplyPatchCreateFileOperation",
    "OutputApplyPatchToolCallOperationApplyPatchDeleteFileOperation",
    "OutputApplyPatchToolCallOperationApplyPatchUpdateFileOperation",
    "OutputApplyPatchToolCallOutput",
    "OutputMcpToolCall",
    "OutputMcpListTools",
    "OutputMcpListToolsTool",
    "OutputMcpApprovalRequest",
    "OutputCustomToolCall",
    "ToolChoice",
    "ToolChoiceToolChoiceAllowed",
    "ToolChoiceToolChoiceTypes",
    "ToolChoiceToolChoiceFunction",
    "ToolChoiceToolChoiceMcp",
    "ToolChoiceToolChoiceCustom",
    "ToolChoiceSpecificApplyPatchParam",
    "ToolChoiceSpecificFunctionShellParam",
    "Tool",
    "ToolFunctionTool",
    "ToolFileSearchTool",
    "ToolFileSearchToolFilters",
    "ToolFileSearchToolFiltersComparisonFilter",
    "ToolFileSearchToolRankingOptions",
    "ToolFileSearchToolRankingOptionsHybridSearch",
    "ToolComputerUsePreviewTool",
    "ToolWebSearchTool",
    "ToolWebSearchToolFilters",
    "ToolWebSearchToolUserLocation",
    "ToolMcpTool",
    "ToolMcpToolAllowedTools",
    "ToolMcpToolAllowedToolsMcpToolFilter",
    "ToolMcpToolRequireApproval",
    "ToolMcpToolRequireApprovalMcpToolApprovalFilter",
    "ToolMcpToolRequireApprovalMcpToolApprovalFilterAlways",
    "ToolMcpToolRequireApprovalMcpToolApprovalFilterNever",
    "ToolCodeInterpreterTool",
    "ToolCodeInterpreterToolContainer",
    "ToolCodeInterpreterToolContainerCodeInterpreterToolAuto",
    "ToolImageGenTool",
    "ToolImageGenToolInputImageMask",
    "ToolLocalShellToolParam",
    "ToolFunctionShellToolParam",
    "ToolCustomToolParam",
    "ToolCustomToolParamFormat",
    "ToolCustomToolParamFormatGrammarFormat",
    "ToolWebSearchPreviewTool",
    "ToolWebSearchPreviewToolUserLocation",
    "ToolApplyPatchToolParam",
    "IncompleteDetails",
    "Prompt",
    "PromptVariables",
    "PromptVariablesInputTextContent",
    "PromptVariablesInputImageContent",
    "PromptVariablesInputFileContent",
    "Reasoning",
    "Text",
    "TextFormat",
    "TextFormatResponseFormatText",
    "TextFormatTextResponseFormatJsonSchema",
    "TextFormatResponseFormatJsonObject",
    "Usage",
    "UsageInputTokensDetails",
    "UsageOutputTokensDetails",
]


class OutputOutputMessageContentOutputTextContentAnnotationFileCitationBody(BaseModel):
    """A citation to a file."""

    file_id: str
    """The ID of the file."""

    filename: str
    """The filename of the file cited."""

    index: int
    """The index of the file in the list of files."""

    type: Literal["file_citation"]
    """The type of the file citation. Always `file_citation`."""


class OutputOutputMessageContentOutputTextContentAnnotationURLCitationBody(BaseModel):
    """A citation for a web resource used to generate a model response."""

    end_index: int
    """The index of the last character of the URL citation in the message."""

    start_index: int
    """The index of the first character of the URL citation in the message."""

    title: str
    """The title of the web resource."""

    type: Literal["url_citation"]
    """The type of the URL citation. Always `url_citation`."""

    url: str
    """The URL of the web resource."""


class OutputOutputMessageContentOutputTextContentAnnotationContainerFileCitationBody(BaseModel):
    """A citation for a container file used to generate a model response."""

    container_id: str
    """The ID of the container file."""

    end_index: int
    """The index of the last character of the container file citation in the message."""

    file_id: str
    """The ID of the file."""

    filename: str
    """The filename of the container file cited."""

    start_index: int
    """The index of the first character of the container file citation in the message."""

    type: Literal["container_file_citation"]
    """The type of the container file citation. Always `container_file_citation`."""


class OutputOutputMessageContentOutputTextContentAnnotationFilePath(BaseModel):
    """A path to a file."""

    file_id: str
    """The ID of the file."""

    index: int
    """The index of the file in the list of files."""

    type: Literal["file_path"]
    """The type of the file path. Always `file_path`."""


OutputOutputMessageContentOutputTextContentAnnotation: TypeAlias = Union[
    OutputOutputMessageContentOutputTextContentAnnotationFileCitationBody,
    OutputOutputMessageContentOutputTextContentAnnotationURLCitationBody,
    OutputOutputMessageContentOutputTextContentAnnotationContainerFileCitationBody,
    OutputOutputMessageContentOutputTextContentAnnotationFilePath,
]


class OutputOutputMessageContentOutputTextContentLogprobTopLogprob(BaseModel):
    """The top log probability of a token."""

    token: str

    bytes: List[int]

    logprob: float


class OutputOutputMessageContentOutputTextContentLogprob(BaseModel):
    """The log probability of a token."""

    token: str

    bytes: List[int]

    logprob: float

    top_logprobs: List[OutputOutputMessageContentOutputTextContentLogprobTopLogprob]


class OutputOutputMessageContentOutputTextContent(BaseModel):
    """A text output from the model."""

    annotations: List[OutputOutputMessageContentOutputTextContentAnnotation]
    """The annotations of the text output."""

    text: str
    """The text output from the model."""

    type: Literal["output_text"]
    """The type of the output text. Always `output_text`."""

    logprobs: Optional[List[OutputOutputMessageContentOutputTextContentLogprob]] = None
    """The log probability of a token."""


class OutputOutputMessageContentRefusalContent(BaseModel):
    """A refusal from the model."""

    refusal: str
    """The refusal explanation from the model."""

    type: Literal["refusal"]
    """The type of the refusal. Always `refusal`."""


OutputOutputMessageContent: TypeAlias = Union[
    OutputOutputMessageContentOutputTextContent, OutputOutputMessageContentRefusalContent
]


class OutputOutputMessage(BaseModel):
    """An output message from the model."""

    id: str
    """The unique ID of the output message."""

    content: List[OutputOutputMessageContent]
    """
    A list of one or many output items from the model, containing different content
    types.
    """

    role: Literal["assistant"]
    """The role of the output message. Always `assistant`."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the message input.

    One of `in_progress`, `completed`, or `incomplete`. Populated when input items
    are returned via API.
    """

    type: Literal["message"]
    """The type of the output message. Always `message`."""


class OutputFileSearchToolCallResult(BaseModel):
    attributes: Optional[Dict[str, Union[str, float, bool]]] = None
    """Set of 16 key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard. Keys are
    strings with a maximum length of 64 characters. Values are strings with a
    maximum length of 512 characters, booleans, or numbers.
    """

    file_id: Optional[str] = None
    """The unique ID of the file."""

    filename: Optional[str] = None
    """The name of the file."""

    score: Optional[float] = None
    """The relevance score of the file - a value between 0 and 1."""

    text: Optional[str] = None
    """The text that was retrieved from the file."""


class OutputFileSearchToolCall(BaseModel):
    """The results of a file search tool call."""

    id: str
    """The unique ID of the file search tool call."""

    queries: List[str]
    """The queries used to search for files."""

    status: Literal["in_progress", "searching", "completed", "incomplete", "failed"]
    """The status of the file search tool call.

    One of `in_progress`, `searching`, `incomplete` or `failed`,
    """

    type: Literal["file_search_call"]
    """The type of the file search tool call. Always `file_search_call`."""

    results: Optional[List[OutputFileSearchToolCallResult]] = None
    """The results of the file search tool call."""


class OutputFunctionToolCall(BaseModel):
    """A tool call to run a function."""

    arguments: str
    """A JSON string of the arguments to pass to the function."""

    call_id: str
    """The unique ID of the function tool call generated by the model."""

    name: str
    """The name of the function to run."""

    type: Literal["function_call"]
    """The type of the function tool call. Always `function_call`."""

    id: Optional[str] = None
    """The unique ID of the function tool call."""

    status: Optional[Literal["in_progress", "completed", "incomplete"]] = None
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """


class OutputWebSearchToolCallActionWebSearchActionSearchSource(BaseModel):
    type: Literal["url"]
    """The type of source. Always `url`."""

    url: str
    """The URL of the source."""


class OutputWebSearchToolCallActionWebSearchActionSearch(BaseModel):
    """Action type "search" - Performs a web search query."""

    query: str
    """The search query."""

    type: Literal["search"]
    """The action type."""

    sources: Optional[List[OutputWebSearchToolCallActionWebSearchActionSearchSource]] = None
    """The sources used in the search."""


class OutputWebSearchToolCallActionWebSearchActionOpenPage(BaseModel):
    """Action type "open_page" - Opens a specific URL from search results."""

    type: Literal["open_page"]
    """The action type."""

    url: str
    """The URL opened by the model."""


class OutputWebSearchToolCallActionWebSearchActionFind(BaseModel):
    """Action type "find": Searches for a pattern within a loaded page."""

    pattern: str
    """The pattern or text to search for within the page."""

    type: Literal["find"]
    """The action type."""

    url: str
    """The URL of the page searched for the pattern."""


OutputWebSearchToolCallAction: TypeAlias = Union[
    OutputWebSearchToolCallActionWebSearchActionSearch,
    OutputWebSearchToolCallActionWebSearchActionOpenPage,
    OutputWebSearchToolCallActionWebSearchActionFind,
]


class OutputWebSearchToolCall(BaseModel):
    """The results of a web search tool call."""

    id: str
    """The unique ID of the web search tool call."""

    action: OutputWebSearchToolCallAction
    """The action performed by the web search tool call."""

    status: Literal["in_progress", "searching", "completed", "failed"]
    """The status of the web search tool call."""

    type: Literal["web_search_call"]
    """The type of the web search tool call. Always `web_search_call`."""


class OutputComputerToolCallActionClickParam(BaseModel):
    """A click action."""

    button: Literal["left", "right", "wheel", "back", "forward"]
    """Indicates which mouse button was pressed during the click.

    One of `left`, `right`, `wheel`, `back`, or `forward`.
    """

    type: Literal["click"]
    """Specifies the event type. For a click action, this property is always `click`."""

    x: int
    """The x-coordinate where the click occurred."""

    y: int
    """The y-coordinate where the click occurred."""


class OutputComputerToolCallActionDoubleClickAction(BaseModel):
    """A double click action."""

    type: Literal["double_click"]
    """Specifies the event type.

    For a double click action, this property is always set to `double_click`.
    """

    x: int
    """The x-coordinate where the double click occurred."""

    y: int
    """The y-coordinate where the double click occurred."""


class OutputComputerToolCallActionDragPath(BaseModel):
    """An x/y coordinate pair, e.g. `{ x: 100, y: 200 }`."""

    x: int
    """The x-coordinate."""

    y: int
    """The y-coordinate."""


class OutputComputerToolCallActionDrag(BaseModel):
    """A drag action."""

    path: List[OutputComputerToolCallActionDragPath]
    """An array of coordinates representing the path of the drag action.

    Coordinates will appear as an array of objects, eg [{ x: 100, y: 200 }, { x:
    200, y: 300 }]
    """

    type: Literal["drag"]
    """Specifies the event type.

    For a drag action, this property is always set to `drag`.
    """


class OutputComputerToolCallActionKeyPressAction(BaseModel):
    """A collection of keypresses the model would like to perform."""

    keys: List[str]
    """The combination of keys the model is requesting to be pressed.

    This is an array of strings, each representing a key.
    """

    type: Literal["keypress"]
    """Specifies the event type.

    For a keypress action, this property is always set to `keypress`.
    """


class OutputComputerToolCallActionMove(BaseModel):
    """A mouse move action."""

    type: Literal["move"]
    """Specifies the event type.

    For a move action, this property is always set to `move`.
    """

    x: int
    """The x-coordinate to move to."""

    y: int
    """The y-coordinate to move to."""


class OutputComputerToolCallActionScreenshot(BaseModel):
    """A screenshot action."""

    type: Literal["screenshot"]
    """Specifies the event type.

    For a screenshot action, this property is always set to `screenshot`.
    """


class OutputComputerToolCallActionScroll(BaseModel):
    """A scroll action."""

    scroll_x: int
    """The horizontal scroll distance."""

    scroll_y: int
    """The vertical scroll distance."""

    type: Literal["scroll"]
    """Specifies the event type.

    For a scroll action, this property is always set to `scroll`.
    """

    x: int
    """The x-coordinate where the scroll occurred."""

    y: int
    """The y-coordinate where the scroll occurred."""


class OutputComputerToolCallActionType(BaseModel):
    """An action to type in text."""

    text: str
    """The text to type."""

    type: Literal["type"]
    """Specifies the event type.

    For a type action, this property is always set to `type`.
    """


class OutputComputerToolCallActionWait(BaseModel):
    """A wait action."""

    type: Literal["wait"]
    """Specifies the event type.

    For a wait action, this property is always set to `wait`.
    """


OutputComputerToolCallAction: TypeAlias = Union[
    OutputComputerToolCallActionClickParam,
    OutputComputerToolCallActionDoubleClickAction,
    OutputComputerToolCallActionDrag,
    OutputComputerToolCallActionKeyPressAction,
    OutputComputerToolCallActionMove,
    OutputComputerToolCallActionScreenshot,
    OutputComputerToolCallActionScroll,
    OutputComputerToolCallActionType,
    OutputComputerToolCallActionWait,
]


class OutputComputerToolCallPendingSafetyCheck(BaseModel):
    """A pending safety check for the computer call."""

    id: str
    """The ID of the pending safety check."""

    code: Optional[str] = None
    """The type of the pending safety check."""

    message: Optional[str] = None
    """Details about the pending safety check."""


class OutputComputerToolCall(BaseModel):
    """A tool call to a computer use tool."""

    id: str
    """The unique ID of the computer call."""

    action: OutputComputerToolCallAction
    """A click action."""

    call_id: str
    """An identifier used when responding to the tool call with output."""

    pending_safety_checks: List[OutputComputerToolCallPendingSafetyCheck]
    """The pending safety checks for the computer call."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """

    type: Literal["computer_call"]
    """The type of the computer call. Always `computer_call`."""


class OutputReasoningItemSummary(BaseModel):
    """A summary text from the model."""

    text: str
    """A summary of the reasoning output from the model so far."""

    type: Literal["summary_text"]
    """The type of the object. Always `summary_text`."""


class OutputReasoningItemContent(BaseModel):
    """Reasoning text from the model."""

    text: str
    """The reasoning text from the model."""

    type: Literal["reasoning_text"]
    """The type of the reasoning text. Always `reasoning_text`."""


class OutputReasoningItem(BaseModel):
    """
    A description of the chain of thought used by a reasoning model while generating a response.
    """

    id: str
    """The unique identifier of the reasoning content."""

    summary: List[OutputReasoningItemSummary]
    """Reasoning summary content."""

    type: Literal["reasoning"]
    """The type of the object. Always `reasoning`."""

    content: Optional[List[OutputReasoningItemContent]] = None
    """Reasoning text content."""

    encrypted_content: Optional[str] = None
    """
    The encrypted content of the reasoning item - populated when a response is
    generated with `reasoning.encrypted_content` in the `include` parameter.
    """

    status: Optional[Literal["in_progress", "completed", "incomplete"]] = None
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """


class OutputCompactionBody(BaseModel):
    """A compaction item for a response."""

    id: str
    """The unique ID of the compaction item."""

    encrypted_content: str

    type: Literal["compaction"]
    """The type of the item. Always `compaction`."""

    created_by: Optional[str] = None


class OutputImageGenToolCall(BaseModel):
    """An image generation request made by the model."""

    id: str
    """The unique ID of the image generation call."""

    result: str
    """The generated image encoded in base64."""

    status: Literal["in_progress", "completed", "generating", "failed"]
    """The status of the image generation call."""

    type: Literal["image_generation_call"]
    """The type of the image generation call. Always `image_generation_call`."""


class OutputCodeInterpreterToolCallOutputCodeInterpreterOutputLogs(BaseModel):
    """The logs output from the code interpreter."""

    logs: str
    """The logs output from the code interpreter."""

    type: Literal["logs"]
    """The type of the output. Always `logs`."""


class OutputCodeInterpreterToolCallOutputCodeInterpreterOutputImage(BaseModel):
    """The image output from the code interpreter."""

    type: Literal["image"]
    """The type of the output. Always `image`."""

    url: str
    """The URL of the image output from the code interpreter."""


OutputCodeInterpreterToolCallOutput: TypeAlias = Union[
    OutputCodeInterpreterToolCallOutputCodeInterpreterOutputLogs,
    OutputCodeInterpreterToolCallOutputCodeInterpreterOutputImage,
]


class OutputCodeInterpreterToolCall(BaseModel):
    """A tool call to run code."""

    id: str
    """The unique ID of the code interpreter tool call."""

    code: str
    """The code to run, or null if not available."""

    container_id: str
    """The ID of the container used to run the code."""

    outputs: List[OutputCodeInterpreterToolCallOutput]
    """The outputs generated by the code interpreter, such as logs or images.

    Can be null if no outputs are available.
    """

    status: Literal["in_progress", "completed", "incomplete", "interpreting", "failed"]
    """The status of the code interpreter tool call.

    Valid values are `in_progress`, `completed`, `incomplete`, `interpreting`, and
    `failed`.
    """

    type: Literal["code_interpreter_call"]
    """The type of the code interpreter tool call. Always `code_interpreter_call`."""


class OutputLocalShellToolCallAction(BaseModel):
    """Execute a shell command on the server."""

    command: List[str]
    """The command to run."""

    env: Dict[str, str]
    """Environment variables to set for the command."""

    type: Literal["exec"]
    """The type of the local shell action. Always `exec`."""

    timeout_ms: Optional[int] = None
    """Optional timeout in milliseconds for the command."""

    user: Optional[str] = None
    """Optional user to run the command as."""

    working_directory: Optional[str] = None
    """Optional working directory to run the command in."""


class OutputLocalShellToolCall(BaseModel):
    """A tool call to run a command on the local shell."""

    id: str
    """The unique ID of the local shell call."""

    action: OutputLocalShellToolCallAction
    """Execute a shell command on the server."""

    call_id: str
    """The unique ID of the local shell tool call generated by the model."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the local shell call."""

    type: Literal["local_shell_call"]
    """The type of the local shell call. Always `local_shell_call`."""


class OutputFunctionShellCallAction(BaseModel):
    """Execute a shell command."""

    command: List[str]

    max_output_length: int
    """Optional maximum number of characters to return from each command."""

    timeout_ms: int
    """Optional timeout in milliseconds for the commands."""


class OutputFunctionShellCall(BaseModel):
    """A tool call that executes one or more shell commands in a managed environment."""

    id: str
    """The unique ID of the shell tool call.

    Populated when this item is returned via API.
    """

    action: OutputFunctionShellCallAction
    """Execute a shell command."""

    call_id: str
    """The unique ID of the shell tool call generated by the model."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the shell call.

    One of `in_progress`, `completed`, or `incomplete`.
    """

    type: Literal["shell_call"]
    """The type of the item. Always `shell_call`."""

    created_by: Optional[str] = None
    """The ID of the entity that created this tool call."""


class OutputFunctionShellCallOutputOutputOutcomeShellCallTimeoutOutcome(BaseModel):
    """Indicates that the shell call exceeded its configured time limit."""

    type: Literal["timeout"]
    """The outcome type. Always `timeout`."""


class OutputFunctionShellCallOutputOutputOutcomeShellCallExitOutcome(BaseModel):
    """Indicates that the shell commands finished and returned an exit code."""

    exit_code: int
    """Exit code from the shell process."""

    type: Literal["exit"]
    """The outcome type. Always `exit`."""


OutputFunctionShellCallOutputOutputOutcome: TypeAlias = Union[
    OutputFunctionShellCallOutputOutputOutcomeShellCallTimeoutOutcome,
    OutputFunctionShellCallOutputOutputOutcomeShellCallExitOutcome,
]


class OutputFunctionShellCallOutputOutput(BaseModel):
    """The content of a shell call output."""

    outcome: OutputFunctionShellCallOutputOutputOutcome
    """
    Represents either an exit outcome (with an exit code) or a timeout outcome for a
    shell call output chunk.
    """

    stderr: str

    stdout: str

    created_by: Optional[str] = None


class OutputFunctionShellCallOutput(BaseModel):
    """The output of a shell tool call."""

    id: str
    """The unique ID of the shell call output.

    Populated when this item is returned via API.
    """

    call_id: str
    """The unique ID of the shell tool call generated by the model."""

    max_output_length: int
    """The maximum length of the shell command output.

    This is generated by the model and should be passed back with the raw output.
    """

    output: List[OutputFunctionShellCallOutputOutput]
    """An array of shell call output contents"""

    type: Literal["shell_call_output"]
    """The type of the shell call output. Always `shell_call_output`."""

    created_by: Optional[str] = None


class OutputApplyPatchToolCallOperationApplyPatchCreateFileOperation(BaseModel):
    """Instruction describing how to create a file via the apply_patch tool."""

    diff: str
    """Diff to apply."""

    path: str
    """Path of the file to create."""

    type: Literal["create_file"]
    """Create a new file with the provided diff."""


class OutputApplyPatchToolCallOperationApplyPatchDeleteFileOperation(BaseModel):
    """Instruction describing how to delete a file via the apply_patch tool."""

    path: str
    """Path of the file to delete."""

    type: Literal["delete_file"]
    """Delete the specified file."""


class OutputApplyPatchToolCallOperationApplyPatchUpdateFileOperation(BaseModel):
    """Instruction describing how to update a file via the apply_patch tool."""

    diff: str
    """Diff to apply."""

    path: str
    """Path of the file to update."""

    type: Literal["update_file"]
    """Update an existing file with the provided diff."""


OutputApplyPatchToolCallOperation: TypeAlias = Union[
    OutputApplyPatchToolCallOperationApplyPatchCreateFileOperation,
    OutputApplyPatchToolCallOperationApplyPatchDeleteFileOperation,
    OutputApplyPatchToolCallOperationApplyPatchUpdateFileOperation,
]


class OutputApplyPatchToolCall(BaseModel):
    """A tool call that applies file diffs by creating, deleting, or updating files."""

    id: str
    """The unique ID of the apply patch tool call.

    Populated when this item is returned via API.
    """

    call_id: str
    """The unique ID of the apply patch tool call generated by the model."""

    operation: OutputApplyPatchToolCallOperation
    """
    One of the create_file, delete_file, or update_file operations applied via
    apply_patch.
    """

    status: Literal["in_progress", "completed"]
    """The status of the apply patch tool call. One of `in_progress` or `completed`."""

    type: Literal["apply_patch_call"]
    """The type of the item. Always `apply_patch_call`."""

    created_by: Optional[str] = None
    """The ID of the entity that created this tool call."""


class OutputApplyPatchToolCallOutput(BaseModel):
    """The output emitted by an apply patch tool call."""

    id: str
    """The unique ID of the apply patch tool call output.

    Populated when this item is returned via API.
    """

    call_id: str
    """The unique ID of the apply patch tool call generated by the model."""

    status: Literal["completed", "failed"]
    """The status of the apply patch tool call output. One of `completed` or `failed`."""

    type: Literal["apply_patch_call_output"]
    """The type of the item. Always `apply_patch_call_output`."""

    created_by: Optional[str] = None
    """The ID of the entity that created this tool call output."""

    output: Optional[str] = None
    """Optional textual output returned by the apply patch tool."""


class OutputMcpToolCall(BaseModel):
    """An invocation of a tool on an MCP server."""

    id: str
    """The unique ID of the tool call."""

    arguments: str
    """A JSON string of the arguments passed to the tool."""

    name: str
    """The name of the tool that was run."""

    server_label: str
    """The label of the MCP server running the tool."""

    type: Literal["mcp_call"]
    """The type of the item. Always `mcp_call`."""

    approval_request_id: Optional[str] = None
    """Unique identifier for the MCP tool call approval request.

    Include this value in a subsequent `mcp_approval_response` input to approve or
    reject the corresponding tool call.
    """

    error: Optional[str] = None
    """The error from the tool call, if any."""

    output: Optional[str] = None
    """The output from the tool call."""

    status: Optional[Literal["in_progress", "completed", "incomplete", "calling", "failed"]] = None
    """The status of the tool call.

    One of `in_progress`, `completed`, `incomplete`, `calling`, or `failed`.
    """


class OutputMcpListToolsTool(BaseModel):
    """A tool available on an MCP server."""

    input_schema: Dict[str, object]
    """The JSON schema describing the tool's input."""

    name: str
    """The name of the tool."""

    annotations: Optional[Dict[str, object]] = None
    """Additional annotations about the tool."""

    description: Optional[str] = None
    """The description of the tool."""


class OutputMcpListTools(BaseModel):
    """A list of tools available on an MCP server."""

    id: str
    """The unique ID of the list."""

    server_label: str
    """The label of the MCP server."""

    tools: List[OutputMcpListToolsTool]
    """The tools available on the server."""

    type: Literal["mcp_list_tools"]
    """The type of the item. Always `mcp_list_tools`."""


class OutputMcpApprovalRequest(BaseModel):
    """A request for human approval of a tool invocation."""

    id: str
    """The unique ID of the approval request."""

    arguments: str
    """A JSON string of arguments for the tool."""

    name: str
    """The name of the tool to run."""

    server_label: str
    """The label of the MCP server making the request."""

    type: Literal["mcp_approval_request"]
    """The type of the item. Always `mcp_approval_request`."""


class OutputCustomToolCall(BaseModel):
    """A call to a custom tool created by the model."""

    call_id: str
    """An identifier used to map this custom tool call to a tool call output."""

    input: str
    """The input for the custom tool call generated by the model."""

    name: str
    """The name of the custom tool being called."""

    type: Literal["custom_tool_call"]
    """The type of the custom tool call. Always `custom_tool_call`."""

    id: Optional[str] = None
    """The unique ID of the custom tool call in the OpenAI platform."""


Output: TypeAlias = Union[
    OutputOutputMessage,
    OutputFileSearchToolCall,
    OutputFunctionToolCall,
    OutputWebSearchToolCall,
    OutputComputerToolCall,
    OutputReasoningItem,
    OutputCompactionBody,
    OutputImageGenToolCall,
    OutputCodeInterpreterToolCall,
    OutputLocalShellToolCall,
    OutputFunctionShellCall,
    OutputFunctionShellCallOutput,
    OutputApplyPatchToolCall,
    OutputApplyPatchToolCallOutput,
    OutputMcpToolCall,
    OutputMcpListTools,
    OutputMcpApprovalRequest,
    OutputCustomToolCall,
]


class ToolChoiceToolChoiceAllowed(BaseModel):
    """Constrains the tools available to the model to a pre-defined set."""

    mode: Literal["auto", "required"]
    """Constrains the tools available to the model to a pre-defined set."""

    tools: List[Dict[str, object]]
    """A list of tool definitions that the model should be allowed to call."""

    type: Literal["allowed_tools"]
    """Allowed tool configuration type. Always `allowed_tools`."""


class ToolChoiceToolChoiceTypes(BaseModel):
    """Indicates that the model should use a built-in tool to generate a response."""

    type: Literal[
        "file_search",
        "web_search_preview",
        "computer_use_preview",
        "web_search_preview_2025_03_11",
        "image_generation",
        "code_interpreter",
    ]
    """Types tool configuration type. Always `types`."""


class ToolChoiceToolChoiceFunction(BaseModel):
    """Use this option to force the model to call a specific function."""

    name: str
    """The name of the function to call."""

    type: Literal["function"]
    """For function calling, the type is always `function`."""


class ToolChoiceToolChoiceMcp(BaseModel):
    """
    Use this option to force the model to call a specific tool on a remote MCP server.
    """

    server_label: str
    """The label of the MCP server to use."""

    type: Literal["mcp"]
    """For MCP tools, the type is always `mcp`."""

    name: Optional[str] = None
    """The name of the tool to call on the server."""


class ToolChoiceToolChoiceCustom(BaseModel):
    """Use this option to force the model to call a specific custom tool."""

    name: str
    """The name of the custom tool to call."""

    type: Literal["custom"]
    """For custom tool calling, the type is always `custom`."""


class ToolChoiceSpecificApplyPatchParam(BaseModel):
    """Forces the model to call the apply_patch tool when executing a tool call."""

    type: Literal["apply_patch"]
    """The tool to call. Always `apply_patch`."""


class ToolChoiceSpecificFunctionShellParam(BaseModel):
    """Forces the model to call the shell tool when a tool call is required."""

    type: Literal["shell"]
    """The tool to call. Always `shell`."""


ToolChoice: TypeAlias = Union[
    Literal["none", "auto", "required"],
    ToolChoiceToolChoiceAllowed,
    ToolChoiceToolChoiceTypes,
    ToolChoiceToolChoiceFunction,
    ToolChoiceToolChoiceMcp,
    ToolChoiceToolChoiceCustom,
    ToolChoiceSpecificApplyPatchParam,
    ToolChoiceSpecificFunctionShellParam,
]


class ToolFunctionTool(BaseModel):
    """Defines a function in your own code the model can choose to call."""

    name: str
    """The name of the function to call."""

    parameters: Dict[str, object]
    """A JSON schema object describing the parameters of the function."""

    strict: bool
    """Whether to enforce strict parameter validation. Default `true`."""

    type: Literal["function"]
    """The type of the function tool. Always `function`."""

    description: Optional[str] = None
    """A description of the function.

    Used by the model to determine whether or not to call the function.
    """


class ToolFileSearchToolFiltersComparisonFilter(BaseModel):
    """
    A filter used to compare a specified attribute key to a given value using a defined comparison operation.
    """

    key: str
    """The key to compare against the value."""

    type: Literal["eq", "ne", "gt", "gte", "lt", "lte"]
    """
    Specifies the comparison operator: `eq`, `ne`, `gt`, `gte`, `lt`, `lte`, `in`,
    `nin`.
    """

    value: Union[str, float, bool, List[Union[str, float]]]
    """
    The value to compare against the attribute key; supports string, number, or
    boolean types.
    """


ToolFileSearchToolFilters: TypeAlias = Union[ToolFileSearchToolFiltersComparisonFilter, "CompoundFilter"]


class ToolFileSearchToolRankingOptionsHybridSearch(BaseModel):
    """
    Weights that control how reciprocal rank fusion balances semantic embedding matches versus sparse keyword matches when hybrid search is enabled.
    """

    embedding_weight: float
    """The weight of the embedding in the reciprocal ranking fusion."""

    text_weight: float
    """The weight of the text in the reciprocal ranking fusion."""


class ToolFileSearchToolRankingOptions(BaseModel):
    """Ranking options for search."""

    hybrid_search: Optional[ToolFileSearchToolRankingOptionsHybridSearch] = None
    """
    Weights that control how reciprocal rank fusion balances semantic embedding
    matches versus sparse keyword matches when hybrid search is enabled.
    """

    ranker: Optional[Literal["auto", "default-2024-11-15"]] = None
    """The ranker to use for the file search."""

    score_threshold: Optional[float] = None
    """The score threshold for the file search, a number between 0 and 1.

    Numbers closer to 1 will attempt to return only the most relevant results, but
    may return fewer results.
    """


class ToolFileSearchTool(BaseModel):
    """A tool that searches for relevant content from uploaded files."""

    type: Literal["file_search"]
    """The type of the file search tool. Always `file_search`."""

    vector_store_ids: List[str]
    """The IDs of the vector stores to search."""

    filters: Optional[ToolFileSearchToolFilters] = None
    """A filter to apply."""

    max_num_results: Optional[int] = None
    """The maximum number of results to return.

    This number should be between 1 and 50 inclusive.
    """

    ranking_options: Optional[ToolFileSearchToolRankingOptions] = None
    """Ranking options for search."""


class ToolComputerUsePreviewTool(BaseModel):
    """A tool that controls a virtual computer."""

    display_height: int
    """The height of the computer display."""

    display_width: int
    """The width of the computer display."""

    environment: Literal["windows", "mac", "linux", "ubuntu", "browser"]
    """The type of computer environment to control."""

    type: Literal["computer_use_preview"]
    """The type of the computer use tool. Always `computer_use_preview`."""


class ToolWebSearchToolFilters(BaseModel):
    """Filters for the search."""

    allowed_domains: Optional[List[str]] = None
    """Allowed domains for the search.

    If not provided, all domains are allowed. Subdomains of the provided domains are
    allowed as well.
    """


class ToolWebSearchToolUserLocation(BaseModel):
    """The approximate location of the user."""

    city: Optional[str] = None
    """Free text input for the city of the user, e.g. `San Francisco`."""

    country: Optional[str] = None
    """
    The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of
    the user, e.g. `US`.
    """

    region: Optional[str] = None
    """Free text input for the region of the user, e.g. `California`."""

    timezone: Optional[str] = None
    """
    The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the
    user, e.g. `America/Los_Angeles`.
    """

    type: Optional[Literal["approximate"]] = None
    """The type of location approximation. Always `approximate`."""


class ToolWebSearchTool(BaseModel):
    """Search the Internet for sources related to the prompt."""

    type: Literal["web_search", "web_search_2025_08_26"]
    """The type of the web search tool.

    One of `web_search` or `web_search_2025_08_26`.
    """

    filters: Optional[ToolWebSearchToolFilters] = None
    """Filters for the search."""

    search_context_size: Optional[Literal["low", "medium", "high"]] = None
    """High level guidance for the amount of context window space to use for the
    search.

    One of `low`, `medium`, or `high`. `medium` is the default.
    """

    user_location: Optional[ToolWebSearchToolUserLocation] = None
    """The approximate location of the user."""


class ToolMcpToolAllowedToolsMcpToolFilter(BaseModel):
    """A filter object to specify which tools are allowed."""

    read_only: Optional[bool] = None
    """Indicates whether or not a tool modifies data or is read-only."""

    tool_names: Optional[List[str]] = None
    """List of allowed tool names."""


ToolMcpToolAllowedTools: TypeAlias = Union[List[str], ToolMcpToolAllowedToolsMcpToolFilter]


class ToolMcpToolRequireApprovalMcpToolApprovalFilterAlways(BaseModel):
    """A filter object to specify which tools are allowed."""

    read_only: Optional[bool] = None
    """Indicates whether or not a tool modifies data or is read-only."""

    tool_names: Optional[List[str]] = None
    """List of allowed tool names."""


class ToolMcpToolRequireApprovalMcpToolApprovalFilterNever(BaseModel):
    """A filter object to specify which tools are allowed."""

    read_only: Optional[bool] = None
    """Indicates whether or not a tool modifies data or is read-only."""

    tool_names: Optional[List[str]] = None
    """List of allowed tool names."""


class ToolMcpToolRequireApprovalMcpToolApprovalFilter(BaseModel):
    """Specify which of the MCP server's tools require approval.

    Can be `always`, `never`, or a filter object associated with tools that require approval.
    """

    always: Optional[ToolMcpToolRequireApprovalMcpToolApprovalFilterAlways] = None
    """A filter object to specify which tools are allowed."""

    never: Optional[ToolMcpToolRequireApprovalMcpToolApprovalFilterNever] = None
    """A filter object to specify which tools are allowed."""


ToolMcpToolRequireApproval: TypeAlias = Union[
    ToolMcpToolRequireApprovalMcpToolApprovalFilter, Literal["always", "never"]
]


class ToolMcpTool(BaseModel):
    """
    Give the model access to additional tools via remote Model Context Protocol (MCP) servers.
    """

    server_label: str
    """A label for this MCP server, used to identify it in tool calls."""

    type: Literal["mcp"]
    """The type of the MCP tool. Always `mcp`."""

    allowed_tools: Optional[ToolMcpToolAllowedTools] = None
    """List of allowed tool names or a filter object."""

    authorization: Optional[str] = None
    """
    An OAuth access token that can be used with a remote MCP server, either with a
    custom MCP server URL or a service connector. Your application must handle the
    OAuth authorization flow and provide the token here.
    """

    connector_id: Optional[
        Literal[
            "connector_dropbox",
            "connector_gmail",
            "connector_googlecalendar",
            "connector_googledrive",
            "connector_microsoftteams",
            "connector_outlookcalendar",
            "connector_outlookemail",
            "connector_sharepoint",
        ]
    ] = None
    """Identifier for service connectors, like those available in ChatGPT.

    One of `server_url` or `connector_id` must be provided.
    """

    headers: Optional[Dict[str, str]] = None
    """Optional HTTP headers to send to the MCP server.

    Use for authentication or other purposes.
    """

    require_approval: Optional[ToolMcpToolRequireApproval] = None
    """Specify which of the MCP server's tools require approval."""

    server_description: Optional[str] = None
    """Optional description of the MCP server, used to provide more context."""

    server_url: Optional[str] = None
    """The URL for the MCP server.

    One of `server_url` or `connector_id` must be provided.
    """


class ToolCodeInterpreterToolContainerCodeInterpreterToolAuto(BaseModel):
    """Configuration for a code interpreter container.

    Optionally specify the IDs of the files to run the code on.
    """

    type: Literal["auto"]
    """Always `auto`."""

    file_ids: Optional[List[str]] = None
    """An optional list of uploaded files to make available to your code."""

    memory_limit: Optional[Literal["1g", "4g", "16g", "64g"]] = None


ToolCodeInterpreterToolContainer: TypeAlias = Union[str, ToolCodeInterpreterToolContainerCodeInterpreterToolAuto]


class ToolCodeInterpreterTool(BaseModel):
    """A tool that runs Python code to help generate a response to a prompt."""

    container: ToolCodeInterpreterToolContainer
    """The code interpreter container.

    Can be a container ID or an object that specifies uploaded file IDs to make
    available to your code, along with an optional `memory_limit` setting.
    """

    type: Literal["code_interpreter"]
    """The type of the code interpreter tool. Always `code_interpreter`."""


class ToolImageGenToolInputImageMask(BaseModel):
    """Optional mask for inpainting.

    Contains `image_url` (string, optional) and `file_id` (string, optional).
    """

    file_id: Optional[str] = None
    """File ID for the mask image."""

    image_url: Optional[str] = None
    """Base64-encoded mask image."""


class ToolImageGenTool(BaseModel):
    """A tool that generates images using the GPT image models."""

    type: Literal["image_generation"]
    """The type of the image generation tool. Always `image_generation`."""

    background: Optional[Literal["transparent", "opaque", "auto"]] = None
    """Background type for the generated image.

    One of `transparent`, `opaque`, or `auto`.
    """

    input_fidelity: Optional[Literal["high", "low"]] = None
    """
    Control how much effort the model will exert to match the style and features,
    especially facial features, of input images.
    """

    input_image_mask: Optional[ToolImageGenToolInputImageMask] = None
    """Optional mask for inpainting.

    Contains `image_url` (string, optional) and `file_id` (string, optional).
    """

    model: Optional[str] = None
    """The image generation model to use."""

    moderation: Optional[Literal["auto", "low"]] = None
    """Moderation level for the generated image."""

    output_compression: Optional[int] = None
    """Compression level for the output image."""

    output_format: Optional[Literal["png", "webp", "jpeg"]] = None
    """The output format of the generated image. One of `png`, `webp`, or `jpeg`."""

    partial_images: Optional[int] = None
    """
    Number of partial images to generate in streaming mode, from 0 (default value)
    to 3.
    """

    quality: Optional[Literal["low", "medium", "high", "auto"]] = None
    """The quality of the generated image. One of `low`, `medium`, `high`, or `auto`."""

    size: Optional[Literal["1024x1024", "1024x1536", "1536x1024", "auto"]] = None
    """The size of the generated image.

    One of `1024x1024`, `1024x1536`, `1536x1024`, or `auto`.
    """


class ToolLocalShellToolParam(BaseModel):
    """A tool that allows the model to execute shell commands in a local environment."""

    type: Literal["local_shell"]
    """The type of the local shell tool. Always `local_shell`."""


class ToolFunctionShellToolParam(BaseModel):
    """A tool that allows the model to execute shell commands."""

    type: Literal["shell"]
    """The type of the shell tool. Always `shell`."""


class ToolCustomToolParamFormatGrammarFormat(BaseModel):
    """A grammar defined by the user."""

    definition: str
    """The grammar definition."""

    syntax: Literal["lark", "regex"]
    """The syntax of the grammar definition. One of `lark` or `regex`."""

    type: Literal["grammar"]
    """Grammar format. Always `grammar`."""


ToolCustomToolParamFormat: TypeAlias = Union[Literal["text"], ToolCustomToolParamFormatGrammarFormat]


class ToolCustomToolParam(BaseModel):
    """A custom tool that processes input using a specified format."""

    name: str
    """The name of the custom tool, used to identify it in tool calls."""

    type: Literal["custom"]
    """The type of the custom tool. Always `custom`."""

    description: Optional[str] = None
    """Optional description of the custom tool, used to provide more context."""

    format: Optional[ToolCustomToolParamFormat] = None
    """The input format for the custom tool. Default is unconstrained text."""


class ToolWebSearchPreviewToolUserLocation(BaseModel):
    type: Literal["approximate"]
    """The type of location approximation. Always `approximate`."""

    city: Optional[str] = None
    """Free text input for the city of the user, e.g. `San Francisco`."""

    country: Optional[str] = None
    """
    The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of
    the user, e.g. `US`.
    """

    region: Optional[str] = None
    """Free text input for the region of the user, e.g. `California`."""

    timezone: Optional[str] = None
    """
    The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the
    user, e.g. `America/Los_Angeles`.
    """


class ToolWebSearchPreviewTool(BaseModel):
    """This tool searches the web for relevant results to use in a response."""

    type: Literal["web_search_preview", "web_search_preview_2025_03_11"]
    """The type of the web search tool.

    One of `web_search_preview` or `web_search_preview_2025_03_11`.
    """

    search_context_size: Optional[Literal["low", "medium", "high"]] = None
    """High level guidance for the amount of context window space to use for the
    search.

    One of `low`, `medium`, or `high`. `medium` is the default.
    """

    user_location: Optional[ToolWebSearchPreviewToolUserLocation] = None


class ToolApplyPatchToolParam(BaseModel):
    """Allows the assistant to create, delete, or update files using unified diffs."""

    type: Literal["apply_patch"]
    """The type of the tool. Always `apply_patch`."""


Tool: TypeAlias = Union[
    ToolFunctionTool,
    ToolFileSearchTool,
    ToolComputerUsePreviewTool,
    ToolWebSearchTool,
    ToolMcpTool,
    ToolCodeInterpreterTool,
    ToolImageGenTool,
    ToolLocalShellToolParam,
    ToolFunctionShellToolParam,
    ToolCustomToolParam,
    ToolWebSearchPreviewTool,
    ToolApplyPatchToolParam,
]


class IncompleteDetails(BaseModel):
    """Details about why the response is incomplete."""

    reason: Optional[Literal["max_output_tokens", "content_filter"]] = None
    """The reason why the response is incomplete."""


class PromptVariablesInputTextContent(BaseModel):
    """A text input to the model."""

    text: str
    """The text input to the model."""

    type: Literal["input_text"]
    """The type of the input item. Always `input_text`."""


class PromptVariablesInputImageContent(BaseModel):
    """An image input to the model."""

    detail: Literal["low", "high", "auto"]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`.
    """

    type: Literal["input_image"]
    """The type of the input item. Always `input_image`."""

    file_id: Optional[str] = None
    """The ID of the file to be sent to the model."""

    image_url: Optional[str] = None
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class PromptVariablesInputFileContent(BaseModel):
    """A file input to the model."""

    type: Literal["input_file"]
    """The type of the input item. Always `input_file`."""

    file_data: Optional[str] = None
    """The content of the file to be sent to the model."""

    file_id: Optional[str] = None
    """The ID of the file to be sent to the model."""

    file_url: Optional[str] = None
    """The URL of the file to be sent to the model."""

    filename: Optional[str] = None
    """The name of the file to be sent to the model."""


PromptVariables: TypeAlias = Union[
    str, PromptVariablesInputTextContent, PromptVariablesInputImageContent, PromptVariablesInputFileContent
]


class Prompt(BaseModel):
    """Reference to a prompt template and its variables."""

    id: str
    """The unique identifier of the prompt template to use."""

    variables: Optional[Dict[str, PromptVariables]] = None
    """Optional map of values to substitute in for variables in your prompt.

    The substitution values can either be strings, or other Response input types
    like images or files.
    """

    version: Optional[str] = None
    """Optional version of the prompt template."""


class Reasoning(BaseModel):
    """Configuration options for reasoning models."""

    effort: Optional[Literal["low", "medium", "high"]] = None
    """Constrains effort on reasoning for reasoning models."""


class TextFormatResponseFormatText(BaseModel):
    """Default response format. Used to generate text responses."""

    type: Literal["text"]
    """The type of response format being defined. Always `text`."""


class TextFormatTextResponseFormatJsonSchema(BaseModel):
    """JSON Schema response format. Used to generate structured JSON responses."""

    name: str
    """The name of the response format.

    Must be a-z, A-Z, 0-9, or contain underscores and dashes, with a maximum length
    of 64.
    """

    schema_: Dict[str, object] = FieldInfo(alias="schema")
    """The schema for the response format, described as a JSON Schema object."""

    type: Literal["json_schema"]
    """The type of response format being defined. Always `json_schema`."""

    description: Optional[str] = None
    """
    A description of what the response format is for, used by the model to determine
    how to respond in the format.
    """

    strict: Optional[bool] = None
    """Whether to enable strict schema adherence when generating the output.

    If set to true, the model will always follow the exact schema defined in the
    `schema` field. Only a subset of JSON Schema is supported when `strict` is
    `true`.
    """


class TextFormatResponseFormatJsonObject(BaseModel):
    """JSON object response format.

    An older method of generating JSON responses. Using `json_schema` is recommended for models that support it. Note that the model will not generate JSON without a system or user message instructing it to do so.
    """

    type: Literal["json_object"]
    """The type of response format being defined. Always `json_object`."""


TextFormat: TypeAlias = Union[
    TextFormatResponseFormatText, TextFormatTextResponseFormatJsonSchema, TextFormatResponseFormatJsonObject
]


class Text(BaseModel):
    """Configuration options for a text response from the model.

    Can be plain text or structured JSON data.
    """

    format: Optional[TextFormat] = None
    """An object specifying the format that the model must output."""

    verbosity: Optional[Literal["low", "medium", "high"]] = None
    """Constrains the verbosity of the model's response.

    Lower values will result in more concise responses, while higher values will
    result in more verbose responses.
    """


class UsageInputTokensDetails(BaseModel):
    """A detailed breakdown of the input tokens."""

    cached_tokens: int
    """The number of tokens that were retrieved from the cache."""


class UsageOutputTokensDetails(BaseModel):
    """A detailed breakdown of the output tokens."""

    reasoning_tokens: int
    """The number of reasoning tokens."""

    tool_output_tokens: int
    """The number of tokens that were used for tool output."""


class Usage(BaseModel):
    """
    Represents token usage details including input tokens, output tokens, a breakdown of output tokens, and the total tokens used.
    """

    input_tokens: int
    """The number of input tokens."""

    input_tokens_details: UsageInputTokensDetails
    """A detailed breakdown of the input tokens."""

    output_tokens: int
    """The number of output tokens."""

    output_tokens_details: UsageOutputTokensDetails
    """A detailed breakdown of the output tokens."""

    total_tokens: int
    """The total number of tokens used."""


class ResponseCreateResponse(BaseModel):
    id: str
    """Unique identifier for this Response."""

    background: bool
    """Whether to run the model response in the background."""

    created_at: int
    """Unix timestamp (in seconds) of when this Response was created."""

    max_output_tokens: int
    """
    An upper bound for the number of tokens that can be generated for a response,
    including visible output tokens and reasoning tokens.
    """

    model: str
    """ID of the model to use."""

    object: Literal["response"]
    """The object type of this resource - always set to `response`."""

    output: List[Output]
    """An array of content items generated by the model."""

    parallel_tool_calls: bool
    """Whether to allow the model to run tool calls in parallel."""

    service_tier: Literal["auto", "default", "flex", "scale", "priority"]
    """Specifies the processing type used for serving the request."""

    status: Literal["completed", "failed", "in_progress", "cancelled", "queued", "incomplete"]
    """The status of the response generation.

    One of `completed`, `failed`, `in_progress`, `cancelled`, `queued`, or
    `incomplete`.
    """

    temperature: float
    """What sampling temperature to use, between 0 and 2.

    Higher values like 0.8 will make the output more random, while lower values like
    0.2 will make it more focused and deterministic. We generally recommend altering
    this or top_p but not both.
    """

    tool_choice: ToolChoice
    """
    How the model should select which tool (or tools) to use when generating a
    response. See the tools parameter to see how to specify which tools the model
    can call.
    """

    tools: List[Tool]
    """An array of tools the model may call while generating a response.

    You can specify which tool to use by setting the tool_choice parameter.
    """

    top_p: float
    """
    An alternative to sampling with temperature, called nucleus sampling, where the
    model considers the results of the tokens with top_p probability mass. So 0.1
    means only the tokens comprising the top 10% probability mass are considered.
    """

    truncation: Literal["auto", "disabled"]
    """The truncation strategy to use for the model response."""

    incomplete_details: Optional[IncompleteDetails] = None
    """Details about why the response is incomplete."""

    instructions: Optional[str] = None
    """A system (or developer) message inserted into the model's context."""

    max_tool_calls: Optional[int] = None
    """
    The maximum number of total calls to built-in tools that can be processed in a
    response. This maximum number applies across all built-in tool calls, not per
    individual tool. Any further attempts to call a tool by the model will be
    ignored.
    """

    metadata: Optional[Dict[str, builtins.object]] = None
    """Set of 16 key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard. Keys are
    strings with a maximum length of 64 characters. Values are strings with a
    maximum length of 512 characters.
    """

    previous_response_id: Optional[str] = None
    """The unique ID of the previous response to the model.

    Use this to create multi-turn conversations.
    """

    prompt: Optional[Prompt] = None
    """Reference to a prompt template and its variables."""

    reasoning: Optional[Reasoning] = None
    """Configuration options for reasoning models."""

    text: Optional[Text] = None
    """Configuration options for a text response from the model.

    Can be plain text or structured JSON data.
    """

    top_logprobs: Optional[int] = None
    """
    An integer between 0 and 20 specifying the number of most likely tokens to
    return at each token position, each with an associated log probability.
    """

    usage: Optional[Usage] = None
    """
    Represents token usage details including input tokens, output tokens, a
    breakdown of output tokens, and the total tokens used.
    """

    user: Optional[str] = None
    """This field is being replaced by safety_identifier and prompt_cache_key.

    Use prompt_cache_key instead to maintain caching optimizations. A stable
    identifier for your end-users. Used to boost cache hit rates by better bucketing
    similar requests and to help OpenAI detect and prevent abuse.
    """


from .shared.compound_filter import CompoundFilter
