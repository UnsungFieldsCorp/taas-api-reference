# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["EndpointError"]


class EndpointError(BaseModel):
    """Error details, present only when endpoint state is FAILED."""

    code: str
    """Error code (e.g., 'ADAPTER_NOT_FOUND', 'K8S_API_ERROR', 'DEPLOYMENT_TIMEOUT')."""

    message: str
    """Human-readable error description."""

    type: str
    """Error type (e.g., 'provision_error', 'adapter_error', 'k8s_error')."""
