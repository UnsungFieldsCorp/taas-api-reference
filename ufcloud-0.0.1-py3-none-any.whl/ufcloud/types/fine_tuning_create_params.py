# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["FineTuningCreateParams", "Hyperparams"]


class FineTuningCreateParams(TypedDict, total=False):
    model: Required[str]

    training_file_id: Required[str]

    hyperparams: Hyperparams
    """Schema for the hyperparameters of a fine-tuning job."""

    org_id: Optional[str]

    status: Optional[Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"]]
    """Enum for the status of a fine-tuning job."""

    suffix: Optional[str]

    type: Optional[str]

    validation_file_id: Optional[str]

    idempotency_key: Annotated[str, PropertyInfo(alias="Idempotency-Key")]


class Hyperparams(TypedDict, total=False):
    """Schema for the hyperparameters of a fine-tuning job."""

    batch_size: int

    epochs: int

    gradient_accumulation_steps: int

    learning_rate: float

    lora_alpha: int

    lora_dropout: float

    lora_rank: int

    lora_target_modules: SequenceNotStr[str]

    lr_scheduler_args: Dict[str, object]

    lr_scheduler_type: str

    max_grad_norm: float

    max_seq_len: int

    n_checkpoints: int

    n_evals: int

    train_on_inputs: str

    training_method: str

    warmup_ratio: float

    weight_decay: float
