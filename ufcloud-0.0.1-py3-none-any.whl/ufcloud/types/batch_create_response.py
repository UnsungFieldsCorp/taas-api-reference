# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["BatchCreateResponse", "RequestCounts"]


class RequestCounts(BaseModel):
    """A model to track the total, completed, and failed requests within a batch job."""

    completed: Optional[int] = None
    """Number of requests that have been completed successfully."""

    failed: Optional[int] = None
    """Number of requests that have failed."""

    total: Optional[int] = None
    """Total number of requests in the batch."""


class BatchCreateResponse(BaseModel):
    id: str
    """The batch ID."""

    completion_window: str
    """The time frame for the batch completion."""

    created_at: int
    """The creation timestamp in Unix format."""

    endpoint: str
    """The endpoint for the batch requests."""

    expires_at: int
    """The expiration timestamp in Unix format."""

    input_file_id: str
    """The ID of the input file."""

    cancelled_at: Optional[str] = None

    cancelling_at: Optional[str] = None

    completed_at: Optional[str] = None

    error_file_id: Optional[str] = None
    """The ID of the file containing the outputs of requests with errors."""

    errors: Optional[str] = None

    expired_at: Optional[str] = None

    failed_at: Optional[str] = None

    finalizing_at: Optional[str] = None

    in_progress_at: Optional[str] = None

    metadata: Optional[Dict[str, object]] = None
    """Key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard.
    """

    object: Optional[Literal["batch"]] = None
    """The object type, always 'batch'."""

    output_file_id: Optional[str] = None
    """The ID of the file containing the outputs of successfully executed requests."""

    request_counts: Optional[RequestCounts] = None
    """A model to track the total, completed, and failed requests within a batch job."""

    status: Optional[str] = None
    """The status of the batch job."""
