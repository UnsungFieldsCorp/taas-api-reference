# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, TypedDict

__all__ = ["BatchCreateParams"]


class BatchCreateParams(TypedDict, total=False):
    completion_window: Required[str]
    """The time frame within which the batch should be processed, e.g., '24h'."""

    endpoint: Required[str]
    """The endpoint to be used for all requests in the batch.

    Currently /v1/chat/completions is supported.
    """

    input_file_id: Required[str]
    """The ID of an uploaded file that contains requests for the new batch."""

    metadata: Dict[str, object]
    """Key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard.
    """
