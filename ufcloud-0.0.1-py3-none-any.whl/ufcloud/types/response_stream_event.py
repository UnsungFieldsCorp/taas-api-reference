# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from .._utils import PropertyInfo
from .._models import BaseModel
from .response_create_response import (
    OutputMcpToolCall,
    OutputMcpListTools,
    OutputOutputMessage,
    OutputReasoningItem,
    OutputCompactionBody,
    OutputCustomToolCall,
    OutputComputerToolCall,
    OutputFunctionToolCall,
    OutputImageGenToolCall,
    ResponseCreateResponse,
    OutputFunctionShellCall,
    OutputWebSearchToolCall,
    OutputApplyPatchToolCall,
    OutputFileSearchToolCall,
    OutputLocalShellToolCall,
    OutputMcpApprovalRequest,
    OutputReasoningItemContent,
    OutputCodeInterpreterToolCall,
    OutputFunctionShellCallOutput,
    OutputApplyPatchToolCallOutput,
    OutputOutputMessageContentRefusalContent,
    OutputOutputMessageContentOutputTextContent,
)

__all__ = [
    "ResponseCreatedEvent",
    "ResponseInProgressEvent",
    "ResponseCompletedEvent",
    "ResponseOutputItemAddedEvent",
    "ResponseOutputItemDoneEvent",
    "ResponseContentPartAddedEvent",
    "ResponseContentPartDoneEvent",
    "ResponseReasoningTextDeltaEvent",
    "ResponseReasoningTextDoneEvent",
    "ResponseReasoningPartAddedEvent",
    "ResponseReasoningPartDoneEvent",
    "ResponseCodeInterpreterCallInProgressEvent",
    "ResponseCodeInterpreterCallCodeDeltaEvent",
    "ResponseWebSearchCallInProgressEvent",
    "ResponseWebSearchCallSearchingEvent",
    "ResponseWebSearchCallCompletedEvent",
    "ResponseCodeInterpreterCallCodeDoneEvent",
    "ResponseCodeInterpreterCallInterpretingEvent",
    "ResponseCodeInterpreterCallCompletedEvent",
    "ResponseMcpCallArgumentsDeltaEvent",
    "ResponseMcpCallArgumentsDoneEvent",
    "ResponseMcpCallInProgressEvent",
    "ResponseMcpCallCompletedEvent",
    "ResponseStreamEvent",
    "ResponseOutputItem",
    "Part",
    "Logprob",
    "LogprobTopLogprob",
    "ResponseAudioDeltaEvent",
    "ResponseAudioDoneEvent",
    "ResponseAudioTranscriptDeltaEvent",
    "ResponseAudioTranscriptDoneEvent",
    "ResponseErrorEvent",
    "ResponseFileSearchCallCompletedEvent",
    "ResponseFileSearchCallInProgressEvent",
    "ResponseFileSearchCallSearchingEvent",
    "ResponseFunctionCallArgumentsDeltaEvent",
    "ResponseFunctionCallArgumentsDoneEvent",
    "ResponseFailedEvent",
    "ResponseIncompleteEvent",
    "ResponseReasoningSummaryPartAddedEvent",
    "ResponseReasoningSummaryPartDoneEvent",
    "ResponseReasoningSummaryTextDeltaEvent",
    "ResponseReasoningSummaryTextDoneEvent",
    "ResponseRefusalDeltaEvent",
    "ResponseRefusalDoneEvent",
    "ResponseTextDeltaEvent",
    "ResponseTextDoneEvent",
    "ResponseImageGenCallCompletedEvent",
    "ResponseImageGenCallGeneratingEvent",
    "ResponseImageGenCallInProgressEvent",
    "ResponseImageGenCallPartialImageEvent",
    "ResponseMcpCallFailedEvent",
    "ResponseMcpListToolsCompletedEvent",
    "ResponseMcpListToolsFailedEvent",
    "ResponseMcpListToolsInProgressEvent",
    "ResponseOutputTextAnnotationAddedEvent",
    "ResponseQueuedEvent",
    "ResponseCustomToolCallInputDeltaEvent",
    "ResponseCustomToolCallInputDoneEvent",
]


class ResponseCreatedEvent(BaseModel):
    """An event that is emitted when a response is created."""

    response: ResponseCreateResponse
    """The response that was created."""

    sequence_number: int
    """The sequence number for this event."""

    type: Literal["response.created"]
    """The type of the event. Always `response.created`."""


class ResponseInProgressEvent(BaseModel):
    """Emitted when the response is in progress."""

    response: ResponseCreateResponse
    """The response that is in progress."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.in_progress"]
    """The type of the event. Always `response.in_progress`."""


class ResponseCompletedEvent(BaseModel):
    """Emitted when the model response is complete."""

    response: ResponseCreateResponse
    """Properties of the completed response."""

    sequence_number: int
    """The sequence number for this event."""

    type: Literal["response.completed"]
    """The type of the event. Always `response.completed`."""


ResponseOutputItem: TypeAlias = Annotated[
    Union[
        OutputOutputMessage,
        OutputFileSearchToolCall,
        OutputFunctionToolCall,
        OutputWebSearchToolCall,
        OutputComputerToolCall,
        OutputReasoningItem,
        OutputCompactionBody,
        OutputImageGenToolCall,
        OutputCodeInterpreterToolCall,
        OutputLocalShellToolCall,
        OutputFunctionShellCall,
        OutputFunctionShellCallOutput,
        OutputApplyPatchToolCall,
        OutputApplyPatchToolCallOutput,
        OutputMcpToolCall,
        OutputMcpListTools,
        OutputMcpApprovalRequest,
        OutputCustomToolCall,
    ],
    PropertyInfo(discriminator="type"),
]


class ResponseOutputItemAddedEvent(BaseModel):
    """Emitted when a new output item is added."""

    item: ResponseOutputItem
    """The output item that was added."""

    output_index: int
    """The index of the output item that was added."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.output_item.added"]
    """The type of the event. Always `response.output_item.added`."""


class ResponseOutputItemDoneEvent(BaseModel):
    """Emitted when an output item is marked done."""

    item: ResponseOutputItem
    """The output item that was marked done."""

    output_index: int
    """The index of the output item that was marked done."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.output_item.done"]
    """The type of the event. Always `response.output_item.done`."""


Part: TypeAlias = Annotated[
    Union[
        OutputOutputMessageContentOutputTextContent,
        OutputOutputMessageContentRefusalContent,
        OutputReasoningItemContent,
    ],
    PropertyInfo(discriminator="type"),
]


class ResponseContentPartAddedEvent(BaseModel):
    """Emitted when a new content part is added."""

    content_index: int
    """The index of the content part that was added."""

    item_id: str
    """The ID of the output item that the content part was added to."""

    output_index: int
    """The index of the output item that the content part was added to."""

    part: Part
    """The content part that was added."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.content_part.added"]
    """The type of the event. Always `response.content_part.added`."""


class ResponseContentPartDoneEvent(BaseModel):
    """Emitted when a content part is done."""

    content_index: int
    """The index of the content part that is done."""

    item_id: str
    """The ID of the output item that the content part was added to."""

    output_index: int
    """The index of the output item that the content part was added to."""

    part: Part
    """The content part that is done."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.content_part.done"]
    """The type of the event. Always `response.content_part.done`."""


class ResponseReasoningTextDeltaEvent(BaseModel):
    """Emitted when a delta is added to a reasoning text."""

    content_index: int
    """The index of the reasoning content part this delta is associated with."""

    delta: str
    """The text delta that was added to the reasoning content."""

    item_id: str
    """The ID of the item this reasoning text delta is associated with."""

    output_index: int
    """The index of the output item this reasoning text delta is associated with."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.reasoning_text.delta"]
    """The type of the event. Always `response.reasoning_text.delta`."""


class ResponseReasoningTextDoneEvent(BaseModel):
    """Emitted when a reasoning text is completed."""

    content_index: int
    """The index of the reasoning content part."""

    item_id: str
    """The ID of the item this reasoning text is associated with."""

    output_index: int
    """The index of the output item this reasoning text is associated with."""

    sequence_number: int
    """The sequence number of this event."""

    text: str
    """The full text of the completed reasoning content."""

    type: Literal["response.reasoning_text.done"]
    """The type of the event. Always `response.reasoning_text.done`."""


class ResponseReasoningPartAddedEvent(BaseModel):
    content_index: int
    """The index of the content part that is done."""

    item_id: str
    """The ID of the output item that the content part was added to."""

    output_index: int
    """The index of the output item that the content part was added to."""

    part: Part
    """The content part that is done."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.reasoning_part.added"]
    """The type of the event. Always `response.reasoning_part.added`."""


class ResponseReasoningPartDoneEvent(BaseModel):
    content_index: int
    """The index of the content part that is done."""

    item_id: str
    """The ID of the output item that the content part was added to."""

    output_index: int
    """The index of the output item that the content part was added to."""

    part: Part
    """The content part that is done."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.reasoning_part.done"]
    """The type of the event. Always `response.reasoning_part.done`."""


class ResponseCodeInterpreterCallInProgressEvent(BaseModel):
    """Emitted when a code interpreter call is in progress."""

    item_id: str
    """The unique identifier of the code interpreter tool call item."""

    output_index: int
    """
    The index of the output item in the response for which the code interpreter call
    is in progress.
    """

    sequence_number: int
    """The sequence number of this event, used to order streaming events."""

    type: Literal["response.code_interpreter_call.in_progress"]
    """The type of the event. Always `response.code_interpreter_call.in_progress`."""


class ResponseCodeInterpreterCallCodeDeltaEvent(BaseModel):
    """Emitted when a partial code snippet is streamed by the code interpreter."""

    delta: str
    """The partial code snippet being streamed by the code interpreter."""

    item_id: str
    """The unique identifier of the code interpreter tool call item."""

    output_index: int
    """
    The index of the output item in the response for which the code is being
    streamed.
    """

    sequence_number: int
    """The sequence number of this event, used to order streaming events."""

    type: Literal["response.code_interpreter_call_code.delta"]
    """The type of the event. Always `response.code_interpreter_call_code.delta`."""


class ResponseWebSearchCallInProgressEvent(BaseModel):
    """Emitted when a web search call is initiated."""

    item_id: str
    """Unique ID for the output item associated with the web search call."""

    output_index: int
    """The index of the output item that the web search call is associated with."""

    sequence_number: int
    """The sequence number of the web search call being processed."""

    type: Literal["response.web_search_call.in_progress"]
    """The type of the event. Always `response.web_search_call.in_progress`."""


class ResponseWebSearchCallSearchingEvent(BaseModel):
    """Emitted when a web search call is executing."""

    item_id: str
    """Unique ID for the output item associated with the web search call."""

    output_index: int
    """The index of the output item that the web search call is associated with."""

    sequence_number: int
    """The sequence number of the web search call being processed."""

    type: Literal["response.web_search_call.searching"]
    """The type of the event. Always `response.web_search_call.searching`."""


class ResponseWebSearchCallCompletedEvent(BaseModel):
    """Emitted when a web search call is completed."""

    item_id: str
    """Unique ID for the output item associated with the web search call."""

    output_index: int
    """The index of the output item that the web search call is associated with."""

    sequence_number: int
    """The sequence number of the web search call being processed."""

    type: Literal["response.web_search_call.completed"]
    """The type of the event. Always `response.web_search_call.completed`."""


class ResponseCodeInterpreterCallCodeDoneEvent(BaseModel):
    """Emitted when the code snippet is finalized by the code interpreter."""

    code: str
    """The final code snippet output by the code interpreter."""

    item_id: str
    """The unique identifier of the code interpreter tool call item."""

    output_index: int
    """The index of the output item in the response for which the code is finalized."""

    sequence_number: int
    """The sequence number of this event, used to order streaming events."""

    type: Literal["response.code_interpreter_call_code.done"]
    """The type of the event. Always `response.code_interpreter_call_code.done`."""


class ResponseCodeInterpreterCallInterpretingEvent(BaseModel):
    """Emitted when the code interpreter is actively interpreting the code snippet."""

    item_id: str
    """The unique identifier of the code interpreter tool call item."""

    output_index: int
    """
    The index of the output item in the response for which the code interpreter is
    interpreting code.
    """

    sequence_number: int
    """The sequence number of this event, used to order streaming events."""

    type: Literal["response.code_interpreter_call.interpreting"]
    """The type of the event. Always `response.code_interpreter_call.interpreting`."""


class ResponseCodeInterpreterCallCompletedEvent(BaseModel):
    """Emitted when the code interpreter call is completed."""

    item_id: str
    """The unique identifier of the code interpreter tool call item."""

    output_index: int
    """
    The index of the output item in the response for which the code interpreter call
    is completed.
    """

    sequence_number: int
    """The sequence number of this event, used to order streaming events."""

    type: Literal["response.code_interpreter_call.completed"]
    """The type of the event. Always `response.code_interpreter_call.completed`."""


class ResponseMcpCallArgumentsDeltaEvent(BaseModel):
    """
    Emitted when there is a delta (partial update) to the arguments of an MCP tool call.
    """

    delta: str
    """
    A JSON string containing the partial update to the arguments for the MCP tool
    call.
    """

    item_id: str
    """The unique identifier of the MCP tool call item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_call_arguments.delta"]
    """The type of the event. Always 'response.mcp_call_arguments.delta'."""


class ResponseMcpCallArgumentsDoneEvent(BaseModel):
    """Emitted when the arguments for an MCP tool call are finalized."""

    arguments: str
    """A JSON string containing the finalized arguments for the MCP tool call."""

    item_id: str
    """The unique identifier of the MCP tool call item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_call_arguments.done"]
    """The type of the event. Always 'response.mcp_call_arguments.done'."""


class ResponseMcpCallInProgressEvent(BaseModel):
    """Emitted when an MCP  tool call is in progress."""

    item_id: str
    """The unique identifier of the MCP tool call item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_call.in_progress"]
    """The type of the event. Always 'response.mcp_call.in_progress'."""


class ResponseMcpCallCompletedEvent(BaseModel):
    """Emitted when an MCP  tool call has completed successfully."""

    item_id: str
    """The ID of the MCP tool call item that completed."""

    output_index: int
    """The index of the output item that completed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_call.completed"]
    """The type of the event. Always 'response.mcp_call.completed'."""


class ResponseAudioDeltaEvent(BaseModel):
    """Emitted when there is a partial audio response."""

    delta: str
    """A chunk of Base64 encoded response audio bytes."""

    sequence_number: int
    """A sequence number for this chunk of the stream response."""

    type: Literal["response.audio.delta"]
    """The type of the event. Always `response.audio.delta`."""


class ResponseAudioDoneEvent(BaseModel):
    """Emitted when the audio response is complete."""

    sequence_number: int
    """The sequence number of the delta."""

    type: Literal["response.audio.done"]
    """The type of the event. Always `response.audio.done`."""


class ResponseAudioTranscriptDeltaEvent(BaseModel):
    """Emitted when there is a partial transcript of audio."""

    delta: str
    """The partial transcript of the audio response."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.audio.transcript.delta"]
    """The type of the event. Always `response.audio.transcript.delta`."""


class ResponseAudioTranscriptDoneEvent(BaseModel):
    """Emitted when the full audio transcript is completed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.audio.transcript.done"]
    """The type of the event. Always `response.audio.transcript.done`."""


class ResponseErrorEvent(BaseModel):
    """Emitted when an error occurs."""

    code: Optional[str] = None
    """The error code."""

    message: str
    """The error message."""

    param: Optional[str] = None
    """The error parameter."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["error"]
    """The type of the event. Always `error`."""


class ResponseFileSearchCallCompletedEvent(BaseModel):
    """Emitted when a file search call is completed (results found)."""

    item_id: str
    """The ID of the output item that the file search call is initiated."""

    output_index: int
    """The index of the output item that the file search call is initiated."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.file_search_call.completed"]
    """The type of the event. Always `response.file_search_call.completed`."""


class ResponseFileSearchCallInProgressEvent(BaseModel):
    """Emitted when a file search call is initiated."""

    item_id: str
    """The ID of the output item that the file search call is initiated."""

    output_index: int
    """The index of the output item that the file search call is initiated."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.file_search_call.in_progress"]
    """The type of the event. Always `response.file_search_call.in_progress`."""


class ResponseFileSearchCallSearchingEvent(BaseModel):
    """Emitted when a file search is currently searching."""

    item_id: str
    """The ID of the output item that the file search call is initiated."""

    output_index: int
    """The index of the output item that the file search call is searching."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.file_search_call.searching"]
    """The type of the event. Always `response.file_search_call.searching`."""


class ResponseFunctionCallArgumentsDeltaEvent(BaseModel):
    """Emitted when there is a partial function-call arguments delta."""

    delta: str
    """The function-call arguments delta that is added."""

    item_id: str
    """The ID of the output item that the function-call arguments delta is added to."""

    output_index: int
    """
    The index of the output item that the function-call arguments delta is added to.
    """

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.function_call_arguments.delta"]
    """The type of the event. Always `response.function_call_arguments.delta`."""


class ResponseFunctionCallArgumentsDoneEvent(BaseModel):
    """Emitted when function-call arguments are finalized."""

    arguments: str
    """The function-call arguments."""

    item_id: str
    """The ID of the item."""

    name: str
    """The name of the function that was called."""

    output_index: int
    """The index of the output item."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.function_call_arguments.done"]


class ResponseFailedEvent(BaseModel):
    """An event that is emitted when a response fails."""

    response: ResponseCreateResponse
    """The response that failed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.failed"]
    """The type of the event. Always `response.failed`."""


class ResponseIncompleteEvent(BaseModel):
    """An event that is emitted when a response finishes as incomplete."""

    response: ResponseCreateResponse
    """The response that was incomplete."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.incomplete"]
    """The type of the event. Always `response.incomplete`."""


class ResponseReasoningSummaryPartAddedEvent(BaseModel):
    """Emitted when a new reasoning summary part is added."""

    item_id: str
    """The ID of the item this summary part is associated with."""

    output_index: int
    """The index of the output item this summary part is associated with."""

    part: Part
    """The summary part that was added."""

    sequence_number: int
    """The sequence number of this event."""

    summary_index: int
    """The index of the summary part within the reasoning summary."""

    type: Literal["response.reasoning_summary_part.added"]
    """The type of the event. Always `response.reasoning_summary_part.added`."""


class ResponseReasoningSummaryPartDoneEvent(BaseModel):
    """Emitted when a reasoning summary part is completed."""

    item_id: str
    """The ID of the item this summary part is associated with."""

    output_index: int
    """The index of the output item this summary part is associated with."""

    part: Part
    """The completed summary part."""

    sequence_number: int
    """The sequence number of this event."""

    summary_index: int
    """The index of the summary part within the reasoning summary."""

    type: Literal["response.reasoning_summary_part.done"]
    """The type of the event. Always `response.reasoning_summary_part.done`."""


class ResponseReasoningSummaryTextDeltaEvent(BaseModel):
    """Emitted when a delta is added to a reasoning summary text."""

    delta: str
    """The text delta that was added to the summary."""

    item_id: str
    """The ID of the item this summary text delta is associated with."""

    output_index: int
    """The index of the output item this summary text delta is associated with."""

    sequence_number: int
    """The sequence number of this event."""

    summary_index: int
    """The index of the summary part within the reasoning summary."""

    type: Literal["response.reasoning_summary_text.delta"]
    """The type of the event. Always `response.reasoning_summary_text.delta`."""


class ResponseReasoningSummaryTextDoneEvent(BaseModel):
    """Emitted when a reasoning summary text is completed."""

    item_id: str
    """The ID of the item this summary text is associated with."""

    output_index: int
    """The index of the output item this summary text is associated with."""

    sequence_number: int
    """The sequence number of this event."""

    summary_index: int
    """The index of the summary part within the reasoning summary."""

    text: str
    """The full text of the completed reasoning summary."""

    type: Literal["response.reasoning_summary_text.done"]
    """The type of the event. Always `response.reasoning_summary_text.done`."""


class ResponseRefusalDeltaEvent(BaseModel):
    """Emitted when there is a partial refusal text."""

    content_index: int
    """The index of the content part that the refusal text is added to."""

    delta: str
    """The refusal text that is added."""

    item_id: str
    """The ID of the output item that the refusal text is added to."""

    output_index: int
    """The index of the output item that the refusal text is added to."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.refusal.delta"]
    """The type of the event. Always `response.refusal.delta`."""


class ResponseRefusalDoneEvent(BaseModel):
    """Emitted when refusal text is finalized."""

    content_index: int
    """The index of the content part that the refusal text is finalized."""

    item_id: str
    """The ID of the output item that the refusal text is finalized."""

    output_index: int
    """The index of the output item that the refusal text is finalized."""

    refusal: str
    """The refusal text that is finalized."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.refusal.done"]
    """The type of the event. Always `response.refusal.done`."""


class LogprobTopLogprob(BaseModel):
    token: Optional[str] = None
    """A possible text token."""

    logprob: Optional[float] = None
    """The log probability of this token."""


class Logprob(BaseModel):
    """
    A logprob is the logarithmic probability that the model assigns to producing
    a particular token at a given position in the sequence. Less-negative (higher)
    logprob values indicate greater model confidence in that token choice.
    """

    token: str
    """A possible text token."""

    logprob: float
    """The log probability of this token."""

    top_logprobs: Optional[List[LogprobTopLogprob]] = None
    """The log probability of the top 20 most likely tokens."""


class ResponseTextDeltaEvent(BaseModel):
    """Emitted when there is an additional text delta."""

    content_index: int
    """The index of the content part that the text delta was added to."""

    delta: str
    """The text delta that was added."""

    item_id: str
    """The ID of the output item that the text delta was added to."""

    logprobs: List[Logprob]
    """The log probabilities of the tokens in the delta."""

    output_index: int
    """The index of the output item that the text delta was added to."""

    sequence_number: int
    """The sequence number for this event."""

    type: Literal["response.output_text.delta"]
    """The type of the event. Always `response.output_text.delta`."""


class ResponseTextDoneEvent(BaseModel):
    """Emitted when text content is finalized."""

    content_index: int
    """The index of the content part that the text content is finalized."""

    item_id: str
    """The ID of the output item that the text content is finalized."""

    logprobs: List[Logprob]
    """The log probabilities of the tokens in the delta."""

    output_index: int
    """The index of the output item that the text content is finalized."""

    sequence_number: int
    """The sequence number for this event."""

    text: str
    """The text content that is finalized."""

    type: Literal["response.output_text.done"]
    """The type of the event. Always `response.output_text.done`."""


class ResponseImageGenCallCompletedEvent(BaseModel):
    """
    Emitted when an image generation tool call has completed and the final image is available.
    """

    item_id: str
    """The unique identifier of the image generation item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.image_generation_call.completed"]
    """The type of the event. Always 'response.image_generation_call.completed'."""


class ResponseImageGenCallGeneratingEvent(BaseModel):
    """
    Emitted when an image generation tool call is actively generating an image (intermediate state).
    """

    item_id: str
    """The unique identifier of the image generation item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of the image generation item being processed."""

    type: Literal["response.image_generation_call.generating"]
    """The type of the event. Always 'response.image_generation_call.generating'."""


class ResponseImageGenCallInProgressEvent(BaseModel):
    """Emitted when an image generation tool call is in progress."""

    item_id: str
    """The unique identifier of the image generation item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of the image generation item being processed."""

    type: Literal["response.image_generation_call.in_progress"]
    """The type of the event. Always 'response.image_generation_call.in_progress'."""


class ResponseImageGenCallPartialImageEvent(BaseModel):
    """Emitted when a partial image is available during image generation streaming."""

    item_id: str
    """The unique identifier of the image generation item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    partial_image_b64: str
    """Base64-encoded partial image data, suitable for rendering as an image."""

    partial_image_index: int
    """
    0-based index for the partial image (backend is 1-based, but this is 0-based for
    the user).
    """

    sequence_number: int
    """The sequence number of the image generation item being processed."""

    type: Literal["response.image_generation_call.partial_image"]
    """The type of the event. Always 'response.image_generation_call.partial_image'."""


class ResponseMcpCallFailedEvent(BaseModel):
    """Emitted when an MCP  tool call has failed."""

    item_id: str
    """The ID of the MCP tool call item that failed."""

    output_index: int
    """The index of the output item that failed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_call.failed"]
    """The type of the event. Always 'response.mcp_call.failed'."""


class ResponseMcpListToolsCompletedEvent(BaseModel):
    """Emitted when the list of available MCP tools has been successfully retrieved."""

    item_id: str
    """The ID of the MCP tool call item that produced this output."""

    output_index: int
    """The index of the output item that was processed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_list_tools.completed"]
    """The type of the event. Always 'response.mcp_list_tools.completed'."""


class ResponseMcpListToolsFailedEvent(BaseModel):
    """Emitted when the attempt to list available MCP tools has failed."""

    item_id: str
    """The ID of the MCP tool call item that failed."""

    output_index: int
    """The index of the output item that failed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_list_tools.failed"]
    """The type of the event. Always 'response.mcp_list_tools.failed'."""


class ResponseMcpListToolsInProgressEvent(BaseModel):
    """
    Emitted when the system is in the process of retrieving the list of available MCP tools.
    """

    item_id: str
    """The ID of the MCP tool call item that is being processed."""

    output_index: int
    """The index of the output item that is being processed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_list_tools.in_progress"]
    """The type of the event. Always 'response.mcp_list_tools.in_progress'."""


class ResponseOutputTextAnnotationAddedEvent(BaseModel):
    """Emitted when an annotation is added to output text content."""

    annotation: object
    """The annotation object being added. (See annotation schema for details.)"""

    annotation_index: int
    """The index of the annotation within the content part."""

    content_index: int
    """The index of the content part within the output item."""

    item_id: str
    """The unique identifier of the item to which the annotation is being added."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.output_text.annotation.added"]
    """The type of the event. Always 'response.output_text.annotation.added'."""


class ResponseQueuedEvent(BaseModel):
    """Emitted when a response is queued and waiting to be processed."""

    response: ResponseCreateResponse
    """The full response object that is queued."""

    sequence_number: int
    """The sequence number for this event."""

    type: Literal["response.queued"]
    """The type of the event. Always 'response.queued'."""


class ResponseCustomToolCallInputDeltaEvent(BaseModel):
    """Event representing a delta (partial update) to the input of a custom tool call."""

    delta: str
    """The incremental input data (delta) for the custom tool call."""

    item_id: str
    """Unique identifier for the API item associated with this event."""

    output_index: int
    """The index of the output this delta applies to."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.custom_tool_call_input.delta"]
    """The event type identifier."""


class ResponseCustomToolCallInputDoneEvent(BaseModel):
    """Event indicating that input for a custom tool call is complete."""

    input: str
    """The complete input data for the custom tool call."""

    item_id: str
    """Unique identifier for the API item associated with this event."""

    output_index: int
    """The index of the output this event applies to."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.custom_tool_call_input.done"]
    """The event type identifier."""


ResponseStreamEvent: TypeAlias = Annotated[
    Union[
        ResponseCreatedEvent,
        ResponseInProgressEvent,
        ResponseCompletedEvent,
        ResponseOutputItemAddedEvent,
        ResponseOutputItemDoneEvent,
        ResponseContentPartAddedEvent,
        ResponseContentPartDoneEvent,
        ResponseReasoningTextDeltaEvent,
        ResponseReasoningTextDoneEvent,
        ResponseReasoningPartAddedEvent,
        ResponseReasoningPartDoneEvent,
        ResponseCodeInterpreterCallInProgressEvent,
        ResponseCodeInterpreterCallCodeDeltaEvent,
        ResponseWebSearchCallInProgressEvent,
        ResponseWebSearchCallSearchingEvent,
        ResponseWebSearchCallCompletedEvent,
        ResponseCodeInterpreterCallCodeDoneEvent,
        ResponseCodeInterpreterCallInterpretingEvent,
        ResponseCodeInterpreterCallCompletedEvent,
        ResponseMcpCallArgumentsDeltaEvent,
        ResponseMcpCallArgumentsDoneEvent,
        ResponseMcpCallInProgressEvent,
        ResponseMcpCallCompletedEvent,
        ResponseAudioDeltaEvent,
        ResponseAudioDoneEvent,
        ResponseAudioTranscriptDeltaEvent,
        ResponseAudioTranscriptDoneEvent,
        ResponseErrorEvent,
        ResponseFileSearchCallCompletedEvent,
        ResponseFileSearchCallInProgressEvent,
        ResponseFileSearchCallSearchingEvent,
        ResponseFunctionCallArgumentsDeltaEvent,
        ResponseFunctionCallArgumentsDoneEvent,
        ResponseFailedEvent,
        ResponseIncompleteEvent,
        ResponseReasoningSummaryPartAddedEvent,
        ResponseReasoningSummaryPartDoneEvent,
        ResponseReasoningSummaryTextDeltaEvent,
        ResponseReasoningSummaryTextDoneEvent,
        ResponseRefusalDeltaEvent,
        ResponseRefusalDoneEvent,
        ResponseTextDeltaEvent,
        ResponseTextDoneEvent,
        ResponseImageGenCallCompletedEvent,
        ResponseImageGenCallGeneratingEvent,
        ResponseImageGenCallInProgressEvent,
        ResponseImageGenCallPartialImageEvent,
        ResponseMcpCallFailedEvent,
        ResponseMcpListToolsCompletedEvent,
        ResponseMcpListToolsFailedEvent,
        ResponseMcpListToolsInProgressEvent,
        ResponseOutputTextAnnotationAddedEvent,
        ResponseQueuedEvent,
        ResponseCustomToolCallInputDeltaEvent,
        ResponseCustomToolCallInputDoneEvent,
    ],
    PropertyInfo(discriminator="type"),
]
