# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "FilePresignedPostResponse",
    "FineTunePresignedPostResponse",
    "FineTunePresignedPostResponseFile",
    "FineTunePresignedPostResponseUpload",
    "FineTunePresignedPostResponseUploadFields",
    "FineTunePresignedPostResponseUploadHeaders",
    "GenericPresignedPostResponse",
]


class FineTunePresignedPostResponseFile(BaseModel):
    created_at: str

    file_id: str

    filename: str

    purpose: str

    status: Literal["pending", "processed"]

    updated_at: str

    line_count: Optional[int] = None

    schema_type: Optional[Literal["messages", "instruction"]] = None

    size_bytes: Optional[int] = None


class FineTunePresignedPostResponseUploadFields(BaseModel):
    aws_access_key_id: Optional[str] = FieldInfo(alias="AWSAccessKeyId", default=None)

    content_type: Optional[str] = FieldInfo(alias="Content-Type", default=None)

    key: Optional[str] = None

    policy: Optional[str] = None

    signature: Optional[str] = None

    x_amz_security_token: Optional[str] = FieldInfo(alias="x-amz-security-token", default=None)

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, object] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> object: ...
    else:
        __pydantic_extra__: Dict[str, object]


class FineTunePresignedPostResponseUploadHeaders(BaseModel):
    content_type: Optional[str] = FieldInfo(alias="Content-Type", default=None)


class FineTunePresignedPostResponseUpload(BaseModel):
    fields: FineTunePresignedPostResponseUploadFields

    headers: FineTunePresignedPostResponseUploadHeaders

    method: Literal["POST"]

    url: str


class FineTunePresignedPostResponse(BaseModel):
    file: FineTunePresignedPostResponseFile

    upload: FineTunePresignedPostResponseUpload


class GenericPresignedPostResponse(BaseModel):
    content_type: str

    expires_in: Literal[3600]

    fields: Dict[str, object]

    filename: str

    requested_at: str

    status: Literal["PresignedPostGenerated"]

    purpose: Optional[str] = None


FilePresignedPostResponse: TypeAlias = Union[FineTunePresignedPostResponse, GenericPresignedPostResponse]
