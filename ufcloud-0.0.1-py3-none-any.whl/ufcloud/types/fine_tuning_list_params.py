# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, TypedDict

__all__ = ["FineTuningListParams"]


class FineTuningListParams(TypedDict, total=False):
    limit: int
    """Items per page, max 100"""

    model: str
    """Filter by model name"""

    page: int
    """Page number, 1-based"""

    status: Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"]
    """Filter by job status"""
