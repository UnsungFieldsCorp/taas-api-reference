# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["FineTuningListResponse"]


class FineTuningListResponse(BaseModel):
    """A concise summary of a fine-tuning job, used for list views."""

    created_at: datetime

    job_id: str

    model: str

    status: Literal["PENDING", "QUEUED", "RUNNING", "COMPLETED", "FAILED", "INVALID_INPUT"]
    """Enum for the status of a fine-tuning job."""

    type: str

    updated_at: datetime

    runtime_seconds: Optional[int] = None

    suffix: Optional[str] = None
