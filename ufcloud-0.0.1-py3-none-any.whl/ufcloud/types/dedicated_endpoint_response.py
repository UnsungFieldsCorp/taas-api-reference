# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel
from .endpoint_error import EndpointError
from .endpoint_usage import EndpointUsage
from .endpoint_hardware_config import EndpointHardwareConfig

__all__ = ["DedicatedEndpointResponse"]


class DedicatedEndpointResponse(BaseModel):
    """Full dedicated endpoint object as returned by the API."""

    adapter_s3_uri: str
    """S3 location of LoRA adapter archive."""

    created_at: datetime
    """Endpoint creation timestamp."""

    created_by: str
    """User ID or API key ID that created this endpoint."""

    display_name: str
    """User-provided descriptive name."""

    endpoint_id: str
    """Unique public identifier, format: dep-{nanoid(11)}."""

    hardware: str
    """Hardware configuration ID (e.g., '4x_nvidia_h200_140gb_sxm')."""

    hardware_config: EndpointHardwareConfig
    """Snapshot of hardware configuration parameters for the dedicated endpoint."""

    job_id: str
    """Source fine-tuning job identifier."""

    model: str
    """Full model name."""

    object: str
    """Object type identifier."""

    org_id: str
    """Owner organization identifier."""

    parent_model: str
    """Base model identifier (references inference_base_models.model_id)."""

    state: Literal["PENDING", "PROVISIONING", "ACTIVE", "FAILED", "STOPPING", "STOPPED"]
    """Lifecycle state of the endpoint."""

    type: str
    """Endpoint type."""

    updated_at: datetime
    """Last modification timestamp."""

    usage: EndpointUsage
    """Cumulative usage statistics for a dedicated endpoint."""

    activated_at: Optional[datetime] = None
    """First ACTIVE state timestamp."""

    dedicated_pool_id: Optional[str] = None
    """Reference to dedicated pool in inference_pools collection."""

    error: Optional[EndpointError] = None
    """Error details, present only when endpoint state is FAILED."""

    inactive_timeout: Optional[int] = None
    """Minutes of inactivity before auto-shutdown. Null if disabled."""
