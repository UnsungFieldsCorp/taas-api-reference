# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime

from .._models import BaseModel
from .hardware_specs import HardwareSpecs
from .hardware_pricing import HardwarePricing

__all__ = ["PublicHardwareResponse"]


class PublicHardwareResponse(BaseModel):
    """Hardware configuration as returned by the public API."""

    id: str
    """Public identifier, format: {gpu*count}x_nvidia*{gpu*type}*{gpu_link}."""

    object: str
    """Object type identifier."""

    pricing: HardwarePricing
    """Pricing for a hardware configuration."""

    specs: HardwareSpecs
    """GPU hardware specifications."""

    updated_at: datetime
    """Last modification timestamp."""

    availability: Optional[Dict[str, str]] = None
    """Availability status for model-specific queries.

    Present only when model query param is used.
    """
