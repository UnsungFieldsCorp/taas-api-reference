# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel

__all__ = ["ModelListResponse", "Data"]


class Data(BaseModel):
    """A model object."""

    id: str
    """The model ID."""

    active: bool
    """Whether the model is active."""

    capabilities: List[str]
    """The capabilities of the model."""

    object: str
    """The object type, which is always model."""


class ModelListResponse(BaseModel):
    data: List[Data]

    object: str
    """The object type, which is always list."""
