# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["HardwareSpecs"]


class HardwareSpecs(BaseModel):
    """GPU hardware specifications."""

    gpu_count: Literal[1, 2, 4, 8]
    """Number of GPUs (1, 2, 4, or 8)."""

    gpu_link: Literal["sxm", "pcie"]
    """Interconnect type: sxm or pcie."""

    gpu_memory: int
    """GPU VRAM in GB."""

    gpu_type: str
    """GPU model identifier (e.g. h200-140gb)."""
